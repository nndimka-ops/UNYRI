/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation
@testable import LiveKit
import Testing
#if canImport(LiveKitTestSupport)
import LiveKitTestSupport
#endif

/// One-shot latch: `wait()` suspends until `open()`; waiters after `open()` pass through.
private actor TestGate {
    private var isOpen = false
    private var waiters: [CheckedContinuation<Void, Never>] = []

    func wait() async {
        guard !isOpen else { return }
        await withCheckedContinuation { waiters.append($0) }
    }

    func open() {
        isOpen = true
        let continuations = waiters
        waiters = []
        for continuation in continuations {
            continuation.resume()
        }
    }
}

// MARK: - Ordered topics

/// The `ordered` text-stream contract is still implemented in Swift (``DataStreams`` chains handler
/// tasks off the FFI's stream-open and stream-closed callbacks); only chunk assembly moved to the
/// Rust core. These are the v1 behavioral specs, re-pointed at the coordinator.
extension IncomingStreamManagerTests {
    private func isAbnormalEnd(_ error: StreamError) -> Bool {
        if case .abnormalEnd = error { return true }
        return false
    }

    /// `handleIncoming` only enqueues onto the core's run loop, so a test that drives the abort
    /// paths directly must first wait for the stream's descriptor to register.
    private func waitForOpenStreams(_ count: UInt64) async {
        let deadline = Date().addingTimeInterval(10)
        while await coordinator.openStreamCount() < count, Date() < deadline {
            try? await Task.sleep(nanoseconds: 10_000_000)
        }
    }

    /// Short pause used only where the assertion is that something has *not* happened, and so has
    /// no condition to poll on.
    private func settle() async {
        try? await Task.sleep(nanoseconds: 200_000_000)
    }

    /// Stream callbacks reach the coordinator in wire order. Once a stream sent after the others has
    /// reached its handler, the coordinator has processed every open and close before it.
    private func waitForCallbacks() async throws {
        let reached = AsyncCompleter<Void>(label: "Callbacks processed", defaultTimeout: 10)
        let barrierTopic = "barrier-\(UUID().uuidString)"
        try coordinator.registerTextStreamHandler(for: barrierTopic) { _, _ in reached.resume(returning: ()) }
        defer { coordinator.unregisterTextStreamHandler(for: barrierTopic) }

        let streamID = UUID().uuidString
        feedHeader(streamID: streamID, byte: false, topic: barrierTopic)
        feedTrailer(streamID: streamID, reason: "")
        try await reached.wait()
    }

    private func waitUntil(_ condition: @Sendable () -> Bool, timeout: TimeInterval = 10) async {
        let deadline = Date().addingTimeInterval(timeout)
        while !condition(), Date() < deadline {
            try? await Task.sleep(nanoseconds: 10_000_000)
        }
    }

    /// Handlers for an `ordered` topic must observe streams in wire order, not the scheduling order
    /// of independently spawned handler tasks.
    @Test func orderedTopicDeliversStreamsInOrder() async throws {
        let count = 16
        let received = StateSync<[String]>([])

        try coordinator.registerTextStreamHandler(for: topicName, ordered: true) { reader, _ in
            let payload = try await reader.readAll()
            received.mutate { $0.append(payload) }
        }

        for index in 0 ..< count {
            await feedTextStream(chunks: ["payload-\(index)"])
        }

        await waitUntil { received.copy().count >= count }
        #expect(received.copy() == (0 ..< count).map { "payload-\($0)" })
        coordinator.unregisterTextStreamHandler(for: topicName)
    }

    /// Ordering must compose transitively: C waits on B even while B is itself still waiting on A.
    /// If the chain breaks, B and C complete while A's handler is gated and the order comes out wrong.
    @Test func orderedTopicChainsAcrossFinishingHandlers() async throws {
        let received = StateSync<[String]>([])
        let gate = TestGate()
        let aStalled = AsyncCompleter<Void>(label: "a stalled", defaultTimeout: 10)

        try coordinator.registerTextStreamHandler(for: topicName, ordered: true) { reader, _ in
            let payload = try await reader.readAll()
            // First handler stalls after its stream closed, becoming a still-finishing predecessor
            // for the streams sent after it.
            if payload == "a" {
                aStalled.resume(returning: ())
                await gate.wait()
            }
            received.mutate { $0.append(payload) }
        }

        for payload in ["a", "b", "c"] {
            await feedTextStream(chunks: [payload])
        }
        // The chain under test forms only once "a" holds the gate and "b" and "c" have opened
        // behind it. Opening the gate earlier lets the test pass without one.
        try await aStalled.wait()
        try await waitForCallbacks()
        await gate.open()

        await waitUntil { received.copy().count >= 3 }
        #expect(received.copy() == ["a", "b", "c"])
        coordinator.unregisterTextStreamHandler(for: topicName)
    }

    /// A still-open stream must not delay streams that overlap with it on the wire (e.g. a live
    /// transcript arriving while an earlier message stream is still open). Ordering is a wire
    /// happens-before relation — it applies between streams that don't overlap, so it must be keyed
    /// on streams that have *closed*, not merely on the order streams opened in.
    ///
    /// Restored: the FFI now reports stream closes (`onStreamClosed`), so ``DataStreams`` chains a
    /// newly opened stream behind handlers whose streams have already *closed* — matching v1 — rather
    /// than behind whatever opened before it. Without that signal an open stream head-of-line-blocked
    /// every later stream from the same sender on the topic.
    @Test func orderedTopicDoesNotDelayOverlappingStreams() async throws {
        let received = StateSync<[String]>([])

        try coordinator.registerTextStreamHandler(for: topicName, ordered: true) { reader, _ in
            let payload = try await reader.readAll()
            received.mutate { $0.append(payload) }
        }

        // Stream A opens and stays open; stream B opens, delivers and closes while A is still open —
        // B's handler must complete without waiting for A.
        feedTextHeader(streamID: "open-a")
        feedTextChunk(streamID: "open-a", content: "a")
        await feedTextStream(chunks: ["b"], streamID: "b")

        await waitUntil { !received.copy().isEmpty }
        #expect(received.copy() == ["b"])

        // A still completes normally once its trailer arrives.
        feedTextTrailer(streamID: "open-a")
        await waitUntil { received.copy().count >= 2 }
        #expect(received.copy() == ["b", "a"])
        coordinator.unregisterTextStreamHandler(for: topicName)
    }

    /// Nothing stops a sender from reusing a stream id once the first stream has closed. v1 kept a
    /// per-stream generation so a finished handler's cleanup could not erase its successor's entry;
    /// the FFI-backed coordinator has to keep that property, or the successor silently stops gating
    /// the streams that open after it.
    @Test func orderedTopicSurvivesReusedStreamID() async throws {
        let received = StateSync<[String]>([])
        let gateA = TestGate()
        let gateB = TestGate()
        let bEntered = AsyncCompleter<Void>(label: "b entered", defaultTimeout: 10)

        try coordinator.registerTextStreamHandler(for: topicName, ordered: true) { reader, _ in
            let payload = try await reader.readAll()
            if payload == "a" { await gateA.wait() }
            if payload == "b" {
                bEntered.resume(returning: ())
                await gateB.wait()
            }
            received.mutate { $0.append(payload) }
        }

        // Both streams carry the same id; the second opens only after the first has closed.
        await feedTextStream(chunks: ["a"], streamID: "reused")
        await feedTextStream(chunks: ["b"], streamID: "reused")
        // The hazard is the first handler's completion racing the second stream's *close*, so let
        // the coordinator process both closes before releasing "a".
        try await waitForCallbacks()

        await gateA.open()
        // The erasure this guards against happens in the coordinator *after* "a"'s handler returns.
        // "b" waits for "a"'s whole handler task, bookkeeping included, so its entry proves it.
        try await bEntered.wait()

        // "c" opened after the reused-id stream and so must stay gated behind it. This is the
        // assertion that fails when the first handler's cleanup drops its successor's entry: "c"
        // runs straight away and lands before "b".
        await feedTextStream(chunks: ["c"], streamID: "later")
        try await waitForCallbacks()
        await settle()
        #expect(received.copy() == ["a"])

        await gateB.open()
        await waitUntil { received.copy().count >= 3 }
        #expect(received.copy() == ["a", "b", "c"])
        coordinator.unregisterTextStreamHandler(for: topicName)
    }

    /// A sender disconnecting before its trailer leaves the stream open forever; `closeStreams(from:)`
    /// must fail it so an ordered topic's queue drains.
    @Test func closeStreamsUnblocksOrderedTopic() async throws {
        let received = StateSync<[String]>([])
        let errors = StateSync<[StreamError]>([])

        try coordinator.registerTextStreamHandler(for: topicName, ordered: true) { reader, _ in
            do {
                let payload = try await reader.readAll()
                received.mutate { $0.append(payload) }
            } catch let error as StreamError {
                errors.mutate { $0.append(error) }
                throw error
            }
        }

        // Header only — no trailer ever arrives, so the handler blocks in `readAll` and, at the head
        // of the ordered queue, would block every later stream.
        feedTextHeader(streamID: "orphan")
        await waitForOpenStreams(1)

        coordinator.closeStreams(from: participant)
        await feedTextStream(chunks: ["after"])

        await waitUntil { !received.copy().isEmpty }
        #expect(received.copy() == ["after"])
        // The FFI core terminates aborted streams with an abnormal-end reason naming the sender, so
        // match the case rather than the message.
        let observed = try #require(errors.copy().first)
        #expect(errors.copy().count == 1)
        #expect(isAbnormalEnd(observed), "expected .abnormalEnd, got \(observed)")
        coordinator.unregisterTextStreamHandler(for: topicName)
    }

    /// Same shape as above via the room-lifecycle path: `reset()` fails all open streams but keeps
    /// handlers registered for after a reconnect.
    @Test func resetUnblocksOrderedTopicAndKeepsHandler() async throws {
        let received = StateSync<[String]>([])

        try coordinator.registerTextStreamHandler(for: topicName, ordered: true) { reader, _ in
            let payload = try await reader.readAll()
            received.mutate { $0.append(payload) }
        }

        feedTextHeader(streamID: "orphan")
        await waitForOpenStreams(1)

        coordinator.reset()
        await feedTextStream(chunks: ["after-reset"])

        await waitUntil { !received.copy().isEmpty }
        #expect(received.copy() == ["after-reset"])
        coordinator.unregisterTextStreamHandler(for: topicName)
    }
}
