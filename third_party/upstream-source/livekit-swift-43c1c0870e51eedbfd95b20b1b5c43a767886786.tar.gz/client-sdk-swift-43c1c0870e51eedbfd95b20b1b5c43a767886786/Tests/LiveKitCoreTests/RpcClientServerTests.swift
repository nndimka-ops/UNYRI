/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation
@testable import LiveKit
import Testing
#if canImport(LiveKitTestSupport)
import LiveKitTestSupport
#endif

// swiftlint:disable file_length type_body_length

// MARK: - RpcClientTests

/// Unit-level coverage of ``RpcClientManager``: caller-side state machine,
/// pending bookkeeping, timeout codes, cancellation, and sender validation.
@Suite(.serialized, .tags(.e2e, .rpc), TestLimits.e2e)
struct RpcClientTests {
    // MARK: - v1 caller-side state machine

    @Test func performRpc() async throws {
        try await TestEnvironment.withRoom { room in
            // Assert the wire format from the mock, but inject the ack/response from
            // the `afterPublish` hook, which `performRpc` awaits — an unstructured
            // `Task` here would race the response timeout.
            let observed = StateSync<Livekit_RpcRequest?>(nil)
            room.publisherDataChannel = MockDataChannelPair { packet in
                guard case let .rpcRequest(request) = packet.value else { return }
                observed.mutate { $0 = request }
            }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                await room.rpcClient.handleIncomingResponse(
                    requestId: requestId,
                    payload: "response-payload",
                    error: nil,
                )
            }

            let response = try await room.localParticipant.performRpc(
                destinationIdentity: Participant.Identity(from: "test-destination"),
                method: "test-method",
                payload: "test-payload",
            )
            #expect(response == "response-payload")
            #expect(await room.rpcClient.pendingCount == 0)

            let request = try #require(observed.copy())
            #expect(request.method == "test-method")
            #expect(request.payload == "test-payload")
            #expect(request.responseTimeoutMs == 15000)
        }
    }

    /// Regression test: a fast remote that responds immediately after publish must not
    /// race the caller's pending-state registration. With pre-publish registration in
    /// `RpcClientManager.performRpc`, the response arriving synchronously after
    /// `publishRequest` finds a pending entry and resolves the call. Pre-fix,
    /// registration was deferred to an inner Task that ran after publish, so a
    /// synchronously-injected response logged "received for unexpected RPC request" and
    /// the call hung to the outer timeout.
    @Test func performRpcFastRemoteResponseRace() async throws {
        try await TestEnvironment.withRoom { room in
            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                await room.rpcClient.handleIncomingResponse(
                    requestId: requestId,
                    payload: "fast-response",
                    error: nil,
                )
            }

            let response = try await room.localParticipant.performRpc(
                destinationIdentity: Participant.Identity(from: "test-destination"),
                method: "test-method",
                payload: "test-payload",
                responseTimeout: 1,
            )
            #expect(response == "fast-response")
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// Regression test: when an RPC response arrives at roughly the same time as the
    /// 7-second ack-timeout watchdog fires, both paths attempt to resolve the same
    /// completer — the response Task with `.resume(returning:)` and the watchdog with
    /// `.resume(throwing: connectionTimeout)`. With the old `CheckedContinuation` this
    /// fatalError'd on the second resume; with `AsyncCompleter` the second resume is a
    /// silent no-op and the first resolution wins.
    ///
    /// Uses `fireAckTimeoutIfPending(requestId:)` to fire the watchdog synchronously
    /// instead of waiting 7 seconds. The test injects a response first, then forces
    /// the watchdog — the call must still resolve to the response payload, not
    /// `connectionTimeout`.
    @Test func performRpcResponseAndAckTimeoutDoubleResolve() async throws {
        try await TestEnvironment.withRoom { room in
            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                // Step 1: deliver the response, resolving the completer with "real-response".
                await room.rpcClient.handleIncomingResponse(
                    requestId: requestId,
                    payload: "real-response",
                    error: nil,
                )
                // Step 2: force the ack-timeout watchdog. `pendingAcks` still contains
                // `requestId` (handleIncomingResponse intentionally leaves it set), so the
                // watchdog gate passes and it tries to resume the completer a second time
                // with `connectionTimeout`. Pre-fix this crashed; post-fix it's a no-op.
                await room.rpcClient.fireAckTimeoutIfPending(requestId: requestId)
            }

            let response = try await room.localParticipant.performRpc(
                destinationIdentity: Participant.Identity(from: "test-destination"),
                method: "test-method",
                payload: "test-payload",
                responseTimeout: 1,
            )
            #expect(response == "real-response")
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// Regression test: when the destination participant disconnects mid-call, the
    /// caller receives `recipientDisconnected` (1503) immediately rather than the
    /// generic `connectionTimeout` (1501) after the user-supplied `responseTimeout`.
    /// This v2→v1 variant uses an uninstalled destination so the caller picks the
    /// v1 packet transport.
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L302"))
    func performRpcRejectsOnRecipientDisconnect() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "test-destination")
            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] _ in
                guard let room else { return }
                await room.rpcClient.handleParticipantDisconnected(destination)
            }

            do {
                _ = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 1,
                )
                Issue.record("Expected RpcError, got success")
            } catch let error as RpcError {
                #expect(error.code == RpcError.BuiltInError.recipientDisconnected.code)
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// v2→v2 variant of the disconnect-mid-call regression: with a v2-capable
    /// destination installed the caller picks the v2 stream transport, but the
    /// disconnect-reaping path is transport-agnostic so the result is still
    /// `recipientDisconnected` (1503).
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L258"))
    func performRpcRejectsOnV2RecipientDisconnect() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v1)
            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] _ in
                guard let room else { return }
                await room.rpcClient.handleParticipantDisconnected(destination)
            }

            do {
                _ = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 1,
                )
                Issue.record("Expected RpcError, got success")
            } catch let error as RpcError {
                #expect(error.code == RpcError.BuiltInError.recipientDisconnected.code)
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// Five concurrent `performRpc` calls to the same destination must each get a
    /// distinct `requestId`, and after all resolve, the manager's pending maps must
    /// be empty (no leaks).
    @Test func performRpcConcurrentRequestsHaveDistinctIds() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "test-destination")
            let collector = TestStringCollector()

            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await collector.append(requestId)
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                await room.rpcClient.handleIncomingResponse(
                    requestId: requestId,
                    payload: "response-\(requestId)",
                    error: nil,
                )
            }

            let responses = try await withThrowingTaskGroup { group in
                for _ in 0 ..< 5 {
                    group.addTask {
                        try await room.localParticipant.performRpc(
                            destinationIdentity: destination,
                            method: "method",
                            payload: "x",
                        )
                    }
                }
                var results: [String] = []
                for try await result in group {
                    results.append(result)
                }
                return results
            }

            #expect(responses.count == 5)
            let observedIds = await collector.values
            #expect(observedIds.count == 5)
            #expect(Set(observedIds).count == 5) // distinct
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    // MARK: - Cancellation

    enum RpcWait: CaseIterable {
        case ack, response
    }

    /// A call in flight, and a completer that receives what it returns.
    struct WaitingCall {
        let requestId: String
        let completer: AsyncCompleter<String>
        let task: AnyTaskCancellable
        let result: AsyncCompleter<Result<String, Error>>
    }

    private static let destination = Participant.Identity(from: "test-destination")

    /// Starts a v1 call that no remote answers and returns once the call waits on its completer.
    /// With `acked`, the ack arrives first, so the call waits for the response only.
    private func startWaitingCall(in room: Room, acked: Bool) async throws -> WaitingCall {
        room.publisherDataChannel = MockDataChannelPair { _ in }
        let published = AsyncCompleter<String>(label: "RPC published", defaultTimeout: 5)
        await room.rpcClient.setAfterPublish { requestId in
            if acked { await room.rpcClient.handleIncomingAck(requestId: requestId) }
            published.resume(returning: requestId)
        }

        let result = AsyncCompleter<Result<String, Error>>(label: "RPC returned", defaultTimeout: 5)
        let task = Task {
            do {
                let response = try await room.localParticipant.performRpc(
                    destinationIdentity: Self.destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 30,
                )
                result.resume(returning: .success(response))
            } catch {
                result.resume(returning: .failure(error))
            }
        }.cancellable()

        let requestId = try await published.wait()
        let completer = try #require(await room.rpcClient.pendingResponses[requestId]?.completer)
        await completer.waitForRegistration(timeout: 5)
        // The hook captures the room, which holds the hook.
        await room.rpcClient.setAfterPublish(nil)
        #expect(await room.rpcClient.pendingAcks.contains(requestId) == !acked)
        return WaitingCall(requestId: requestId, completer: completer, task: task, result: result)
    }

    /// Expects that the manager holds no pending ack, pending response, or ack watchdog.
    private func expectNothingPending(in room: Room, sourceLocation: SourceLocation = #_sourceLocation) async {
        #expect(await room.rpcClient.pendingAcks.isEmpty, sourceLocation: sourceLocation)
        #expect(await room.rpcClient.pendingResponses.isEmpty, sourceLocation: sourceLocation)
        #expect(await room.rpcClient.ackWatchdogs.isEmpty, sourceLocation: sourceLocation)
    }

    /// Cancelling the task that awaits `performRpc` while the call waits for the ack or the
    /// response throws `CancellationError` at once and leaves no pending state.
    @Test(arguments: RpcWait.allCases)
    func performRpcThrowsCancellationErrorWhenCancelled(waitingFor wait: RpcWait) async throws {
        try await TestEnvironment.withRoom { room in
            let call = try await startWaitingCall(in: room, acked: wait == .response)
            call.task.cancel()

            await #expect(throws: CancellationError.self) { try await call.result.wait().get() }
            await expectNothingPending(in: room)
        }
    }

    /// An ack, a response packet, or a response stream that arrives after its call was cancelled
    /// finds nothing to resolve and leaves no pending state.
    @Test func performRpcDropsLateResponseAfterCancel() async throws {
        try await TestEnvironment.withRoom { room in
            let call = try await startWaitingCall(in: room, acked: false)
            call.task.cancel()
            await #expect(throws: CancellationError.self) { try await call.result.wait().get() }

            await room.rpcClient.handleIncomingAck(requestId: call.requestId)
            await room.rpcClient.handleIncomingResponse(requestId: call.requestId, payload: "late", error: nil)
            await room.rpcClient.handleIncomingResponseStream(
                reader: RpcTestSupport.makeResponseReader(requestId: call.requestId, payload: "late"),
                senderIdentity: Self.destination,
            )

            await expectNothingPending(in: room)
        }
    }

    /// A response stream for a call that is no longer pending is dropped unread, so a stream that
    /// fails to read cannot report its failure as an error.
    @Test func performRpcDropsLateResponseStreamUnread() async throws {
        try await TestEnvironment.withRoom { room in
            let call = try await startWaitingCall(in: room, acked: true)
            call.task.cancel()
            await #expect(throws: CancellationError.self) { try await call.result.wait().get() }

            let reader = RpcTestSupport.makeResponseReader(requestId: call.requestId, error: StreamError.terminated)
            await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: Self.destination)

            #expect(reader.reads.copy() == 0)
            await expectNothingPending(in: room)
        }
    }

    /// A call whose task is already cancelled when it starts throws `CancellationError`, sends no
    /// request, and leaves nothing pending, by the packet (`.v0`) or the stream (`.v1`) transport.
    @Test(arguments: [ClientProtocol.v0, .v1])
    func performRpcCancelledBeforeStartSendsNothing(remoteProtocol: ClientProtocol) async throws {
        try await TestEnvironment.withRoom { room in
            try await RpcTestSupport.installRemote(in: room, identity: Self.destination, clientProtocol: remoteProtocol)
            let sent = StateSync(0)
            room.publisherDataChannel = MockDataChannelPair { _ in sent.mutate { $0 += 1 } }

            let result = AsyncCompleter<Result<String, Error>>(label: "RPC returned", defaultTimeout: 5)
            Task {
                withUnsafeCurrentTask { $0?.cancel() }
                do {
                    let response = try await room.localParticipant.performRpc(
                        destinationIdentity: Self.destination,
                        method: "method",
                        payload: "x",
                    )
                    result.resume(returning: .success(response))
                } catch {
                    result.resume(returning: .failure(error))
                }
            }

            await #expect(throws: CancellationError.self) { try await result.wait().get() }
            #expect(sent.copy() == 0)
            await expectNothingPending(in: room)
        }
    }

    /// A cancel while a v1 request waits for the data channel to open throws `CancellationError`,
    /// not the channel's `LiveKitError(.cancelled)`, and leaves nothing pending.
    @Test func performRpcCancelledDuringPublishThrowsCancellationError() async throws {
        try await TestEnvironment.withRoom { room in
            let channel = UnopenedDataChannelPair { _ in }
            room.publisherDataChannel = channel

            let result = AsyncCompleter<Result<String, Error>>(label: "RPC returned", defaultTimeout: 5)
            let task = Task {
                do {
                    let response = try await room.localParticipant.performRpc(
                        destinationIdentity: Self.destination,
                        method: "method",
                        payload: "x",
                    )
                    result.resume(returning: .success(response))
                } catch {
                    result.resume(returning: .failure(error))
                }
            }
            await channel.opened.waitForRegistration(timeout: 5)
            #expect(await room.rpcClient.pendingResponses.count == 1)
            task.cancel()

            await #expect(throws: CancellationError.self) { try await result.wait().get() }
            await expectNothingPending(in: room)
        }
    }

    /// A response stream whose read fails after its call was cancelled finds the call gone. The
    /// handler returns without resuming the call's completer again, and nothing is left pending.
    @Test func performRpcIgnoresReadFailureAfterCancel() async throws {
        try await TestEnvironment.withRoom { room in
            let call = try await startWaitingCall(in: room, acked: true)
            let reader = GatedFailingReader(requestId: call.requestId)
            let handled = AsyncCompleter<Void>(label: "Response stream handled", defaultTimeout: 5)
            Task {
                await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: Self.destination)
                handled.resume(returning: ())
            }
            try await reader.entered.wait()

            call.task.cancel()
            await #expect(throws: CancellationError.self) { try await call.result.wait().get() }
            await expectNothingPending(in: room)

            reader.release.resume(returning: ())
            try await handled.wait()

            #expect(reader.reads.copy() == 1)
            await expectNothingPending(in: room)
            // A wait with no time left returns a cached result at once, so it shows whether
            // anything resumed the cancelled call's completer.
            let error = await #expect(throws: LiveKitError.self) { try await call.completer.wait(timeout: 0) }
            #expect(error?.type == .timedOut)
        }
    }

    /// The same waiting call, left uncancelled, still returns the response that ends its wait.
    @Test func performRpcReturnsResponseAfterWaiting() async throws {
        try await TestEnvironment.withRoom { room in
            let call = try await startWaitingCall(in: room, acked: true)
            await room.rpcClient.handleIncomingResponse(requestId: call.requestId, payload: "response", error: nil)

            #expect(try await call.result.wait().get() == "response")
            await expectNothingPending(in: room)
        }
    }

    // MARK: - v2 caller timing

    /// A v2 remote that acks and responds the moment the request is published resolves the call
    /// and leaves nothing pending, so a second call works and gets a fresh request ID.
    @Test func v2ResponseImmediatelyAfterPublish() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v2)
            room.publisherDataChannel = MockDataChannelPair { _ in }
            let requestIds = TestStringCollector()

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await requestIds.append(requestId)
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                let reader = RpcTestSupport.makeResponseReader(requestId: requestId, payload: "response-\(requestId)")
                await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: destination)
            }

            let first = try await room.localParticipant.performRpc(destinationIdentity: destination, method: "fast", payload: "p1")
            let second = try await room.localParticipant.performRpc(destinationIdentity: destination, method: "fast", payload: "p2")

            let ids = await requestIds.values
            #expect(ids.count == 2)
            #expect(Set(ids).count == 2)
            #expect([first, second] == ids.map { "response-\($0)" })
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// The ack and the response arrive while the request stream is still being published: the
    /// mocked channel handles them before the header's send returns. The pending call is registered
    /// before the publish starts, so it still matches.
    @Test func v2ResponseArrivesDuringPublish() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v2)
            let responded = StateSync(false)

            room.publisherDataChannel = AwaitingDataChannelPair { [weak room] packet in
                guard let room, case let .streamHeader(header) = packet.value, header.topic == RpcStreamTopic.request,
                      let requestId = header.attributes[RpcStreamAttribute.requestId] else { return }
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                let reader = RpcTestSupport.makeResponseReader(requestId: requestId, payload: "during")
                await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: destination)
                responded.mutate { $0 = true }
            }
            // Runs once the publish has returned.
            let respondedBeforePublishEnded = StateSync<Bool?>(nil)
            await room.rpcClient.setAfterPublish { _ in
                respondedBeforePublishEnded.mutate { $0 = responded.copy() }
            }

            let response = try await room.localParticipant.performRpc(destinationIdentity: destination, method: "midflight", payload: "p")
            #expect(response == "during")
            #expect(respondedBeforePublishEnded.copy() == true)
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// An ack and response that arrive after the ack watchdog failed the call with
    /// `connectionTimeout` change nothing: the call keeps that error and nothing is left pending.
    @Test func v2LateAckAfterConnectionTimeoutIsIgnored() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v2)
            room.publisherDataChannel = MockDataChannelPair { _ in }
            let requestIds = TestStringCollector()

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await requestIds.append(requestId)
                await room.rpcClient.fireAckTimeoutIfPending(requestId: requestId)
            }

            let error = try #require(await #expect(throws: RpcError.self) {
                _ = try await room.localParticipant.performRpc(destinationIdentity: destination, method: "late", payload: "p")
            })
            #expect(error.code == RpcError.BuiltInError.connectionTimeout.code)

            let requestId = try #require(await requestIds.values.first)
            await room.rpcClient.handleIncomingAck(requestId: requestId)
            let reader = RpcTestSupport.makeResponseReader(requestId: requestId, payload: "too-late")
            await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: destination)
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// Five concurrent calls to a v2 remote each get the response to their own request: the remote
    /// answers each request stream with its own payload.
    @Test func v2ConcurrentCallsGetTheirOwnResponses() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v2)
            let requestIdsByStream = StateSync<[String: String]>([:])
            let payloadsByRequest = StateSync<[String: String]>([:])

            room.publisherDataChannel = MockDataChannelPair { packet in
                switch packet.value {
                case let .streamHeader(header) where header.topic == RpcStreamTopic.request:
                    guard let requestId = header.attributes[RpcStreamAttribute.requestId] else { return }
                    requestIdsByStream.mutate { $0[header.streamID] = requestId }
                case let .streamChunk(chunk):
                    guard let requestId = requestIdsByStream.copy()[chunk.streamID] else { return }
                    payloadsByRequest.mutate { $0[requestId, default: ""] += String(bytes: chunk.content, encoding: .utf8) ?? "" }
                default:
                    break
                }
            }

            // Runs once the request stream has been published, so its whole payload is recorded.
            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                let payload = payloadsByRequest.copy()[requestId] ?? ""
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                let reader = RpcTestSupport.makeResponseReader(requestId: requestId, payload: "response-\(payload)")
                await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: destination)
            }

            let responses = try await withThrowingTaskGroup(of: (Int, String).self) { group in
                for index in 1 ... 5 {
                    group.addTask {
                        try await (index, room.localParticipant.performRpc(destinationIdentity: destination, method: "echo", payload: "request-\(index)"))
                    }
                }
                var responses: [Int: String] = [:]
                for try await (index, response) in group {
                    responses[index] = response
                }
                return responses
            }

            #expect(responses == Dictionary(uniqueKeysWithValues: (1 ... 5).map { ($0, "response-request-\($0)") }))
            #expect(Set(payloadsByRequest.copy().keys).count == 5)
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    // MARK: - v2 caller-side wire-format & state-machine internals

    /// Caller times out waiting for the response. With `responseTimeout < maxRoundTripLatency`,
    /// the completer's `defaultTimeout` fires before the ack-watchdog and surfaces as
    /// `responseTimeout` (1502) — `connectionTimeout` (1501) is reserved for the
    /// ack-watchdog path.
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L247"))
    func v2CallerResponseTimeout() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v1)

            room.publisherDataChannel = MockDataChannelPair { _ in }

            do {
                _ = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 0.05,
                )
                Issue.record("Expected RpcError to be thrown")
            } catch let error as RpcError {
                #expect(error.code == RpcError.BuiltInError.responseTimeout.code)
            } catch {
                Issue.record("Unexpected error type: \(error)")
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// v2→v1 variant of response timeout: with a v0 destination installed the
    /// caller picks the v1 packet transport. No ack/response arrives, completer
    /// `defaultTimeout` expires → `responseTimeout` (1502).
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L289"))
    func v2CallerV1FallbackResponseTimeout() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v1-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v0)

            room.publisherDataChannel = MockDataChannelPair { _ in }

            do {
                _ = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 0.05,
                )
                Issue.record("Expected RpcError to be thrown")
            } catch let error as RpcError {
                #expect(error.code == RpcError.BuiltInError.responseTimeout.code)
            } catch {
                Issue.record("Unexpected error type: \(error)")
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// v2→v1 variant of the typed-error round-trip: v0 destination → v1 packet
    /// transport, mocked channel injects ack + error `RpcResponse` packet. The
    /// caller rejects with the original error code/message.
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L295"))
    func v2CallerV1FallbackErrorResponse() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v1-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v0)

            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                await room.rpcClient.handleIncomingResponse(
                    requestId: requestId,
                    payload: nil,
                    error: RpcError(code: 101, message: "Test error message", data: ""),
                )
            }

            do {
                _ = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "fails",
                    payload: "x",
                )
                Issue.record("Expected error not thrown")
            } catch let error as RpcError {
                #expect(error.code == 101)
                #expect(error.message == "Test error message")
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// `handleIncomingResponse` with a `requestId` that isn't in `pendingResponses`
    /// must log and no-op (e.g. a late response after the call already resolved or
    /// was reaped). Verifies it doesn't crash or mutate state.
    @Test func responsePacketForUnknownRequestIdIsIgnored() async throws {
        try await TestEnvironment.withRoom { room in
            await room.rpcClient.handleIncomingResponse(
                requestId: "no-such-request",
                payload: "ignored",
                error: nil,
            )
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// A v2 response stream without an `lk.rpc_request_id` attribute can't be
    /// correlated to any pending call. `handleIncomingResponseStream` must log
    /// and bail without mutating state.
    @Test func responseStreamMissingRequestIdIsIgnored() async throws {
        try await TestEnvironment.withRoom { room in
            let reader = RpcTestSupport.makeResponseReader(requestId: nil, payload: "ignored")
            await room.rpcClient.handleIncomingResponseStream(
                reader: reader,
                senderIdentity: Participant.Identity(from: "anyone"),
            )
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// When the v2 response-stream reader fails partway through (e.g. peer-closed
    /// transport mid-stream), the pending call must be failed fast with
    /// `APPLICATION_ERROR` instead of hanging to `responseTimeout`. Matches the
    /// JS-parity fix in `RpcClientManager.handleIncomingResponseStream`.
    @Test func v2ResponseStreamReaderFailureFailsPending() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v1)

            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                let reader = RpcTestSupport.makeResponseReader(requestId: requestId, error: StreamError.terminated)
                await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: destination)
            }

            do {
                _ = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 10,
                )
                Issue.record("Expected APPLICATION_ERROR from failed response reader")
            } catch let error as RpcError {
                #expect(error.code == RpcError.BuiltInError.applicationError.code)
                #expect(error.message == "Error reading RPC response payload")
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }

    /// A v2 response stream from any peer other than the original RPC destination must
    /// NOT resolve the pending call — otherwise any participant could spoof responses
    /// for someone else's in-flight RPC. Pre-fix, `handleIncomingResponseStream` ignored
    /// the `senderIdentity` argument entirely and resolved on requestId match alone.
    @Test func v2ResponseStreamFromWrongSenderIsIgnored() async throws {
        try await TestEnvironment.withRoom { room in
            let destination = Participant.Identity(from: "v2-destination")
            let imposter = Participant.Identity(from: "v2-imposter")
            try await RpcTestSupport.installRemote(in: room, identity: destination, clientProtocol: .v1)

            room.publisherDataChannel = MockDataChannelPair { _ in }

            await room.rpcClient.setAfterPublish { [weak room] requestId in
                guard let room else { return }
                await room.rpcClient.handleIncomingAck(requestId: requestId)
                // Inject a response stream from the imposter — must be ignored.
                let reader = RpcTestSupport.makeResponseReader(requestId: requestId, payload: "spoofed")
                await room.rpcClient.handleIncomingResponseStream(reader: reader, senderIdentity: imposter)
            }

            do {
                let response = try await room.localParticipant.performRpc(
                    destinationIdentity: destination,
                    method: "method",
                    payload: "x",
                    responseTimeout: 1,
                )
                Issue.record("Spoofed response from wrong sender should not have resolved the call (got \(response))")
            } catch let error as RpcError {
                // Ack arrived (legitimately) but the spoofed response was ignored, so the
                // completer's user-supplied `responseTimeout` (1s) elapses → 1502.
                #expect(error.code == RpcError.BuiltInError.responseTimeout.code)
            }
            #expect(await room.rpcClient.pendingCount == 0)
        }
    }
}

// MARK: - RpcServerTests

/// Unit-level coverage of ``RpcServerManager``: handler registry, v1 dispatch,
/// v2 stream dispatch error paths.
@Suite(.serialized, .tags(.e2e, .rpc), TestLimits.e2e)
struct RpcServerTests {
    // MARK: - v1 server-side handler dispatch

    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L274"))
    func handleIncomingRpcRequest() async throws {
        try await TestEnvironment.withRoom { room in
            try await confirmation("Should send RPC response packet") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          case let .payload(payload) = response.value,
                          response.requestID == "test-request-1",
                          payload == "Hello, test-caller!"
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                try await room.registerRpcMethod("greet") { data in
                    "Hello, \(data.callerIdentity)!"
                }

                let isRegistered = await room.isRpcMethodRegistered("greet")
                #expect(isRegistered)

                await #expect(throws: LiveKitError.self) {
                    try await room.registerRpcMethod("greet") { _ in "" }
                }

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: Participant.Identity(from: "test-caller"),
                    requestId: "test-request-1",
                    method: "greet",
                    payload: "Hi there!",
                    responseTimeout: 8,
                    version: 1,
                )
            }
        }
    }

    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L324"))
    func rpcErrorHandling() async throws {
        try await TestEnvironment.withRoom { room in
            try await confirmation("Should send error response packet") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          case let .error(error) = response.value,
                          error.code == 2000,
                          error.message == "Custom error",
                          error.data == "Additional data"
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                try await room.registerRpcMethod("failingMethod") { _ in
                    throw RpcError(code: 2000, message: "Custom error", data: "Additional data")
                }

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: Participant.Identity(from: "test-caller"),
                    requestId: "test-request-1",
                    method: "failingMethod",
                    payload: "test",
                    responseTimeout: 8,
                    version: 1,
                )
            }
        }
    }

    /// v1 caller → v2 handler, unhandled error variant: a registered method throws
    /// a non-`RpcError` exception. The handler wraps it as `APPLICATION_ERROR`
    /// (1500) and publishes a v1 `RpcResponse` packet (caller is `clientProtocol = 0`
    /// per the default, so `publishResult` picks the v1 packet response transport).
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L318"))
    func v1HandlerUnhandledErrorReturnsPacket() async throws {
        try await TestEnvironment.withRoom { room in
            try await confirmation("Sends APPLICATION_ERROR packet") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          response.requestID == "v1-unhandled",
                          case let .error(error) = response.value,
                          error.code == RpcError.BuiltInError.applicationError.code
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                try await room.registerRpcMethod("error-method") { _ in
                    throw GenericTestError()
                }

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: Participant.Identity(from: "v1-caller"),
                    requestId: "v1-unhandled",
                    method: "error-method",
                    payload: "",
                    responseTimeout: 8,
                    version: 1,
                )
            }
        }
    }

    @Test func unregisterRpcMethod() async throws {
        try await TestEnvironment.withRoom { room in
            try await confirmation("Should send unsupported method error packet") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          case let .error(error) = response.value,
                          error.code == RpcError.BuiltInError.unsupportedMethod.code
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                try await room.registerRpcMethod("test") { _ in "test response" }
                await room.unregisterRpcMethod("test")
                let isRegistered = await room.isRpcMethodRegistered("test")
                #expect(!isRegistered)

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: Participant.Identity(from: "test-caller"),
                    requestId: "test-request-1",
                    method: "test",
                    payload: "test",
                    responseTimeout: 10,
                    version: 1,
                )
            }
        }
    }

    /// A v1 handler returning a payload above `MAX_RPC_PAYLOAD_BYTES` (15 KB)
    /// must publish a `responsePayloadTooLarge` (1504) error packet instead of
    /// emitting an oversize payload over the v1 wire. The v2 stream path has
    /// no such cap (`v2HandlerCanReturnLargeResponse` covers that side).
    @Test func v1HandlerOversizeResponseReturnsTooLargePacket() async throws {
        try await TestEnvironment.withRoom { room in
            try await confirmation("Sends responsePayloadTooLarge error packet") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          response.requestID == "v1-oversize",
                          case let .error(error) = response.value,
                          error.code == RpcError.BuiltInError.responsePayloadTooLarge.code
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                let oversize = String(repeating: "y", count: MAX_RPC_PAYLOAD_BYTES + 1)
                try await room.registerRpcMethod("big") { _ in oversize }

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: Participant.Identity(from: "v1-caller"),
                    requestId: "v1-oversize",
                    method: "big",
                    payload: "",
                    responseTimeout: 8,
                    version: 1,
                )
            }
        }
    }

    /// Spec test case #16 (v1 → v2 handler response fallback): a legacy v1 caller
    /// (`clientProtocol = .v0`) sends a v1 `RpcRequest` packet to a v2-capable
    /// handler. Even though the handler supports v2 streams, it must respond
    /// with a v1 `RpcResponse` packet — not a stream — because the caller
    /// doesn't subscribe to `lk.rpc_response`. Pins the per-caller transport
    /// selection in `publishResult`.
    @Test(.spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L310"))
    func v1CallerToV2HandlerResponseUsesV1Packet() async throws {
        try await TestEnvironment.withRoom { room in
            let v1Caller = Participant.Identity(from: "legacy-v1-caller")
            try await RpcTestSupport.installRemote(in: room, identity: v1Caller, clientProtocol: .v0)

            try await confirmation("Response arrives as v1 RpcResponse packet, not a stream") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    if case let .streamHeader(header) = packet.value, header.topic == RpcStreamTopic.response {
                        Issue.record("v2 stream response opened for v1 caller (\(header.attributes))")
                        return
                    }
                    guard case let .rpcResponse(response) = packet.value,
                          response.requestID == "v1-to-v2",
                          case let .payload(payload) = response.value,
                          payload == "v1-response"
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                try await room.registerRpcMethod("ping") { _ in "v1-response" }

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: v1Caller,
                    requestId: "v1-to-v2",
                    method: "ping",
                    payload: "",
                    responseTimeout: 8,
                    version: 1,
                )
            }
        }
    }

    /// A v1 `RpcRequest` packet with `version != 1` must respond with
    /// `unsupportedVersion` (1404) — pinning the JS-parity behavior in the v1
    /// path of `RpcServerManager.handleIncomingRequest`.
    @Test func v1HandleIncomingRequestUnsupportedVersion() async throws {
        try await TestEnvironment.withRoom { room in
            await confirmation("Sends unsupportedVersion error packet") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          case let .error(error) = response.value,
                          error.code == RpcError.BuiltInError.unsupportedVersion.code
                    else { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                await room.rpcServer.handleIncomingRequest(
                    callerIdentity: Participant.Identity(from: "v1-caller"),
                    requestId: "v1-bad-version",
                    method: "anything",
                    payload: "",
                    responseTimeout: 8,
                    version: 2,
                )
            }
        }
    }

    // MARK: - v2 server-side wire-format & state-machine internals

    enum HandlerErrorScenario: CaseIterable, CustomTestStringConvertible {
        case genericError
        case rpcErrorPassthrough

        var testDescription: String {
            switch self {
            case .genericError: "generic Error → APPLICATION_ERROR"
            case .rpcErrorPassthrough: "RpcError → preserved code/message"
            }
        }

        var expectedCode: Int {
            switch self {
            case .genericError: RpcError.BuiltInError.applicationError.code
            case .rpcErrorPassthrough: 101
            }
        }

        /// `nil` means "don't assert on message" (generic errors don't carry through).
        var expectedMessage: String? {
            switch self {
            case .genericError: nil
            case .rpcErrorPassthrough: "Test error message"
            }
        }
    }

    private struct GenericTestError: Error {}

    /// v2 handler errors are always returned as v1 `RpcResponse` packets per spec,
    /// regardless of caller transport. Generic `Error` → `APPLICATION_ERROR` (1500);
    /// thrown `RpcError` → original code/message preserved.
    /// v2 stream missing the `lk.rpc_request_id` attribute can't be correlated to a
    /// reply, so the handler must log and bail — never publish a packet.
    @Test func v2RequestStreamMissingRequestIdIsSilent() async throws {
        try await TestEnvironment.withRoom { room in
            await confirmation("No packet sent", expectedCount: 0) { confirm in
                room.publisherDataChannel = MockDataChannelPair { _ in confirm() }

                let reader = RpcTestSupport.makeRequestReader(
                    requestId: nil,
                    method: "anything",
                    payload: "",
                    timeoutMs: 8000,
                )
                await room.rpcServer.handleIncomingRequestStream(
                    reader: reader,
                    callerIdentity: Participant.Identity(from: "v2-caller"),
                )
            }
        }
    }

    enum V2RequestErrorScenario: CaseIterable, CustomTestStringConvertible {
        case missingMethod
        case wrongVersion
        case readerFailure

        var testDescription: String {
            switch self {
            case .missingMethod: "missing `method` attr → APPLICATION_ERROR/malformed"
            case .wrongVersion: "version='3' → unsupportedVersion"
            case .readerFailure: "reader.readAll() throws → APPLICATION_ERROR/read-failure"
            }
        }

        var requestId: String {
            switch self {
            case .missingMethod: "v2-req-incomplete"
            case .wrongVersion: "v2-req-badver"
            case .readerFailure: "v2-req-readfail"
            }
        }

        func makeReader() -> StubTextStreamReader {
            switch self {
            case .missingMethod:
                RpcTestSupport.makeRequestReader(
                    requestId: requestId, method: nil, payload: "", timeoutMs: 8000,
                )
            case .wrongVersion:
                RpcTestSupport.makeRequestReader(
                    requestId: requestId, method: "anything", payload: "", timeoutMs: 8000, version: "3",
                )
            case .readerFailure:
                RpcTestSupport.makeRequestReader(
                    requestId: requestId, method: "anything", timeoutMs: 8000, error: StreamError.terminated,
                )
            }
        }

        var expectedCode: Int {
            switch self {
            case .missingMethod, .readerFailure: RpcError.BuiltInError.applicationError.code
            case .wrongVersion: RpcError.BuiltInError.unsupportedVersion.code
            }
        }

        /// `nil` means "don't assert on message" — `wrongVersion` uses the
        /// built-in default message, the others carry specific text.
        var expectedMessage: String? {
            switch self {
            case .missingMethod: "RPC data stream malformed"
            case .wrongVersion: nil
            case .readerFailure: "Error reading RPC request payload"
            }
        }
    }

    /// `RpcServerManager.handleIncomingRequestStream` error fan-out. For each
    /// malformed-input shape the server must publish a matching error packet
    /// on the v1 wire so the caller fails fast instead of hanging to its own
    /// response timeout. Matches JS.
    @Test(arguments: V2RequestErrorScenario.allCases)
    func v2RequestStreamErrorReturnsPacket(_ scenario: V2RequestErrorScenario) async throws {
        try await TestEnvironment.withRoom { room in
            await confirmation("Sends matching error packet (\(scenario.testDescription))") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          response.requestID == scenario.requestId,
                          case let .error(error) = response.value,
                          error.code == scenario.expectedCode
                    else { return }
                    if let expected = scenario.expectedMessage, error.message != expected { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                await room.rpcServer.handleIncomingRequestStream(
                    reader: scenario.makeReader(),
                    callerIdentity: Participant.Identity(from: "v2-caller"),
                )
            }
        }
    }

    @Test(
        .spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L232"),
        .spec("https://github.com/livekit/client-sdk-js/blob/92c72f06/RPC_SPEC.md?plain=1#L240"),
        arguments: HandlerErrorScenario.allCases,
    )
    func v2HandlerErrorReturnsPacket(_ scenario: HandlerErrorScenario) async throws {
        try await TestEnvironment.withRoom { room in
            try await confirmation("Sends v1 RpcResponse error packet (\(scenario.testDescription))") { confirm in
                let mockDataChannel = MockDataChannelPair { packet in
                    guard case let .rpcResponse(response) = packet.value,
                          case let .error(error) = response.value,
                          error.code == scenario.expectedCode
                    else { return }
                    if let expected = scenario.expectedMessage, error.message != expected { return }
                    confirm()
                }
                room.publisherDataChannel = mockDataChannel

                try await room.registerRpcMethod("error-method") { _ in
                    switch scenario {
                    case .genericError: throw GenericTestError()
                    case .rpcErrorPassthrough: throw RpcError(code: 101, message: "Test error message", data: "")
                    }
                }

                let reader = RpcTestSupport.makeRequestReader(
                    requestId: "v2-req-error",
                    method: "error-method",
                    payload: "",
                    timeoutMs: 8000,
                )
                await room.rpcServer.handleIncomingRequestStream(
                    reader: reader,
                    callerIdentity: Participant.Identity(from: "v2-caller"),
                )
            }
        }
    }
}

// swiftlint:enable type_body_length

// MARK: - Shared test support

private enum RpcTestSupport {
    /// Install a remote participant into `room` whose `clientProtocol` advertises the
    /// given version. Required for `performRpc` to read `remoteParticipants[...]?.clientProtocol`
    /// when there's no real signaling.
    static func installRemote(in room: Room, identity: Participant.Identity, clientProtocol: ClientProtocol) async throws {
        let info = Livekit_ParticipantInfo.with {
            $0.identity = identity.stringValue
            $0.sid = "PA_\(UUID().uuidString.prefix(8))"
            $0.clientProtocol = Int32(clientProtocol.rawValue)
        }
        let remote = RemoteParticipant(info: info, room: room, connectionState: .connected)
        room._state.mutate {
            $0.remoteParticipants[identity] = remote
        }
    }

    /// Builds a v2 request-stream reader. Pass `nil` for any attribute to omit
    /// it from the wire — used by negative tests that exercise the missing-attr
    /// error paths in `RpcServerManager.handleIncomingRequestStream`. Pass an
    /// `error` to simulate a peer-closed or decrypt-failed stream, which
    /// exercises the `APPLICATION_ERROR` fast-fail branch.
    static func makeRequestReader(
        requestId: String?,
        method: String?,
        payload: String = "",
        timeoutMs: UInt32?,
        version: String? = RPC_STREAM_VERSION,
        error: Error? = nil,
    ) -> StubTextStreamReader {
        var attributes: [String: String] = [:]
        if let requestId { attributes[RpcStreamAttribute.requestId] = requestId }
        if let method { attributes[RpcStreamAttribute.method] = method }
        if let timeoutMs { attributes[RpcStreamAttribute.timeoutMs] = String(timeoutMs) }
        if let version { attributes[RpcStreamAttribute.version] = version }
        return StubTextStreamReader(topic: RpcStreamTopic.request,
                                    attributes: attributes,
                                    result: error.map { .failure($0) } ?? .success(payload))
    }

    /// Builds a v2 response-stream reader. Pass `nil` for `requestId` to omit
    /// the correlation attribute — used by negative tests that exercise
    /// `RpcClientManager.handleIncomingResponseStream`'s missing-id branch.
    static func makeResponseReader(
        requestId: String?,
        payload: String = "",
        error: Error? = nil,
    ) -> StubTextStreamReader {
        var attributes: [String: String] = [:]
        if let requestId { attributes[RpcStreamAttribute.requestId] = requestId }
        return StubTextStreamReader(topic: RpcStreamTopic.response,
                                    attributes: attributes,
                                    result: error.map { .failure($0) } ?? .success(payload))
    }
}

/// Stands in for the FFI-backed reader the RPC managers consume, so a test can hand them a
/// payload — or a read failure — without a connection.
struct StubTextStreamReader: TextStreamReading {
    let info: TextStreamInfo
    private let result: Result<String, Error>
    /// How many times `readAll()` ran.
    let reads = StateSync(0)

    init(topic: String, attributes: [String: String], result: Result<String, Error>) {
        info = TextStreamInfo(
            id: UUID().uuidString,
            topic: topic,
            timestamp: Date(),
            totalLength: nil,
            attributes: attributes,
            encryptionType: .none,
            mimeType: "text/plain",
            operationType: .create,
            version: 0,
            replyToStreamID: nil,
            attachedStreamIDs: [],
            generated: false,
        )
        self.result = result
    }

    func readAll() async throws -> String {
        reads.mutate { $0 += 1 }
        return try result.get()
    }
}

/// A mocked data channel whose send waits for `onSend`, so whatever a packet triggers finishes
/// before the publish that sent it does.
private final class AwaitingDataChannelPair: MockDataChannelPair, @unchecked Sendable {
    private let onSend: @Sendable (Livekit_DataPacket) async -> Void

    init(onSend: @escaping @Sendable (Livekit_DataPacket) async -> Void) {
        self.onSend = onSend
        super.init { _ in }
    }

    override func send(dataPacket packet: Livekit_DataPacket) async throws {
        await onSend(packet)
    }
}

/// A mocked data channel that never opens, so a send waits on `opened` until its task is cancelled.
private final class UnopenedDataChannelPair: MockDataChannelPair, @unchecked Sendable {
    let opened = AsyncCompleter<Void>(label: "Mock data channel open", defaultTimeout: 10)

    override func whenOpen(kind _: Livekit_DataPacket_Kind) -> AsyncCompleter<Void> { opened }
}

/// A response stream whose read reports when it starts, waits for `release`, and then fails.
private struct GatedFailingReader: TextStreamReading {
    let info: TextStreamInfo
    let reads = StateSync(0)
    let entered = AsyncCompleter<Void>(label: "Response read started", defaultTimeout: 5)
    let release = AsyncCompleter<Void>(label: "Response read released", defaultTimeout: 5)

    init(requestId: String) {
        info = RpcTestSupport.makeResponseReader(requestId: requestId).info
    }

    func readAll() async throws -> String {
        reads.mutate { $0 += 1 }
        entered.resume(returning: ())
        try await release.wait()
        throw StreamError.terminated
    }
}

/// Async-safe append-only collector used to assert across concurrently-running tasks.
private actor TestStringCollector {
    private(set) var values: [String] = []
    func append(_ value: String) { values.append(value) }
}
