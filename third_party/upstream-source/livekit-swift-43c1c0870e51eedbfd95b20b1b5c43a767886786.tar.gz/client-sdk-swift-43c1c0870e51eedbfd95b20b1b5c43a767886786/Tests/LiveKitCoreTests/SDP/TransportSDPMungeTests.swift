/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@testable import LiveKit
import LiveKitWebRTC
import Testing

@Suite(.tags(.media))
struct TransportSDPMungeTests {
    /// Session-level `a=inactive`, an inactive RTP audio section, an active video
    /// section, and an inactive non-RTP data channel section.
    private static let offer = """
    v=0
    o=- 0 0 IN IP4 127.0.0.1
    s=-
    t=0 0
    a=inactive
    a=group:BUNDLE 0 1 2
    m=audio 9 UDP/TLS/RTP/SAVPF 111
    a=mid:0
    a=rtpmap:111 opus/48000/2
    a=inactive
    m=video 9 UDP/TLS/RTP/SAVPF 96
    a=mid:1
    a=rtpmap:96 VP8/90000
    a=sendrecv
    m=application 9 UDP/DTLS/SCTP webrtc-datachannel
    a=mid:2
    a=inactive
    """.replacingOccurrences(of: "\n", with: "\r\n") + "\r\n"

    @Test func convertsInactiveToRecvOnlyInRTPSectionsOnly() {
        let munged = Transport.mungeInactiveToRecvOnlyForMedia(Self.offer)
        let sections = SDP(parsing: munged)

        #expect(sections.mediaSections.map(\.direction) == [.recvonly, .sendrecv, .inactive])
        // Session-level line is not a media direction — must be untouched.
        #expect(sections.sessionLines.contains("a=inactive"))
    }

    @Test func preservesEOLStyleAndTrailingNewline() {
        let munged = Transport.mungeInactiveToRecvOnlyForMedia(Self.offer)

        #expect(munged == Self.offer.replacingOccurrences(of: "a=inactive\r\nm=video", with: "a=recvonly\r\nm=video"))
        #expect(munged.hasSuffix("\r\n"))
    }

    @Test func leavesSDPWithoutInactiveSectionsIdentical() {
        let sdp = Self.offer.replacingOccurrences(of: "a=inactive", with: "a=recvonly")
        #expect(Transport.mungeInactiveToRecvOnlyForMedia(sdp) == sdp)
    }

    /// Two Opus audio sections (one already declaring `stereo=1`, one carrying the
    /// `sprop-stereo=1` substring trap), a video section, and a non-Opus audio section.
    private static let singlePCOffer = """
    v=0
    m=audio 9 UDP/TLS/RTP/SAVPF 111
    a=mid:0
    a=rtpmap:111 opus/48000/2
    a=fmtp:111 minptime=10;useinbandfec=1
    m=audio 9 UDP/TLS/RTP/SAVPF 111
    a=mid:1
    a=rtpmap:111 opus/48000/2
    a=fmtp:111 sprop-stereo=1
    m=video 9 UDP/TLS/RTP/SAVPF 96
    a=mid:2
    a=rtpmap:96 VP8/90000
    m=audio 9 UDP/TLS/RTP/SAVPF 8
    a=mid:3
    a=rtpmap:8 PCMA/8000
    a=fmtp:8 maxptime=40
    """.replacingOccurrences(of: "\n", with: "\r\n") + "\r\n"

    /// In single PC mode the offerer is also the receiver, so `stereo=1` (RFC 7587 §7.1)
    /// is declared on every audio section's Opus fmtp — including past the
    /// `sprop-stereo=1` substring trap — while video and non-Opus audio are untouched.
    @Test func declaresStereoOnEveryAudioOpusSection() {
        let munged = Transport.mungeOpusStereoForAllAudio(Self.singlePCOffer)

        #expect(SDP(parsing: munged).mediaSections.flatMap(\.fmtps).map(\.config) == [
            "minptime=10;useinbandfec=1;stereo=1",
            "sprop-stereo=1;stereo=1",
            "maxptime=40",
        ])
    }

    @Test func stereoForAllAudioIsIdempotentAndPreservesUnrelatedSDP() {
        let once = Transport.mungeOpusStereoForAllAudio(Self.singlePCOffer)

        #expect(Transport.mungeOpusStereoForAllAudio(once) == once)
        #expect(Transport.mungeOpusStereoForAllAudio(Self.offer) == Self.offer)
    }

    /// A publisher offer with two video sections sending known tracks (`cam`: H.264 with two
    /// payloads, one lower-cased and already carrying a stale start bitrate, plus VP8 without
    /// an fmtp line and an rtx payload; `share`: VP9 and AV1), a sending video section whose
    /// sender is not mapped, a receive-only video section whose `a=msid` still names a mapped
    /// sender (a section left behind by an unpublished track), and an Opus audio section.
    private static let publisherOffer = """
    v=0
    o=- 0 0 IN IP4 127.0.0.1
    s=-
    t=0 0
    m=audio 9 UDP/TLS/RTP/SAVPF 111
    a=mid:0
    a=msid:- mic
    a=rtpmap:111 opus/48000/2
    a=fmtp:111 minptime=10;useinbandfec=1
    a=sendonly
    m=video 9 UDP/TLS/RTP/SAVPF 96 97 98 99
    a=mid:1
    a=msid:- cam
    a=rtpmap:96 H264/90000
    a=fmtp:96 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f
    a=rtpmap:97 h264/90000
    a=fmtp:97 packetization-mode=0;x-google-start-bitrate=500;profile-level-id=42e01f
    a=rtpmap:98 VP8/90000
    a=rtpmap:99 rtx/90000
    a=fmtp:99 apt=98
    a=sendonly
    m=video 9 UDP/TLS/RTP/SAVPF 100 101
    a=mid:2
    a=msid:- share
    a=rtpmap:100 VP9/90000
    a=fmtp:100 profile-id=0
    a=rtpmap:101 AV1/90000
    a=sendonly
    m=video 9 UDP/TLS/RTP/SAVPF 96
    a=mid:3
    a=msid:- other
    a=rtpmap:96 H264/90000
    a=fmtp:96 packetization-mode=1
    a=sendonly
    m=video 9 UDP/TLS/RTP/SAVPF 96
    a=mid:4
    a=msid:- stale
    a=rtpmap:96 H264/90000
    a=fmtp:96 packetization-mode=1
    a=recvonly
    """.replacingOccurrences(of: "\n", with: "\r\n") + "\r\n"

    /// The connection-level value is the largest hint among the sending sections' mapped
    /// senders; the receive-only section neither contributes nor gets one, and a map with no
    /// sending sender yields none.
    @Test func connectionStartBitrateIsTheLargestSendingSendersHint() {
        let document = SDP(parsing: Self.publisherOffer)

        #expect(Transport.connectionStartBitrateKbps(for: document, kbpsBySenderId: ["cam": 1000]) == 1000)
        #expect(Transport.connectionStartBitrateKbps(for: document, kbpsBySenderId: ["cam": 1000, "share": 4500]) == 4500)
        #expect(Transport.connectionStartBitrateKbps(for: document, kbpsBySenderId: ["cam": 1000, "share": 4500, "stale": 9000]) == 4500)
        #expect(Transport.connectionStartBitrateKbps(for: document, kbpsBySenderId: ["stale": 9000]) == nil)
        #expect(Transport.connectionStartBitrateKbps(for: document, kbpsBySenderId: ["mic": 900, "absent": 900]) == nil)
        #expect(Transport.connectionStartBitrateKbps(for: document, kbpsBySenderId: [:]) == nil)
    }

    /// One value for the whole connection, on every video codec of every sending video section
    /// — matched case-insensitively, replacing a stale value, appended to an existing fmtp line
    /// or inserted as a new one — including the section whose sender is unmapped. rtx, audio
    /// and the receive-only section are untouched.
    @Test func declaresTheConnectionStartBitrateOnEverySendingVideoSection() {
        let munged = Transport.mungeVideoStartBitrate(Self.publisherOffer, kbpsBySenderId: ["cam": 1000, "share": 4500, "stale": 9000])
        let sections = SDP(parsing: munged).mediaSections
        let original = SDP(parsing: Self.publisherOffer).mediaSections

        #expect(sections[0].lines == original[0].lines)
        #expect(sections[1].fmtps.map(\.config) == [
            "level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f;x-google-start-bitrate=4500",
            "packetization-mode=0;x-google-start-bitrate=4500;profile-level-id=42e01f",
            "apt=98",
            "x-google-start-bitrate=4500",
        ])
        #expect(sections[1].lines.last == "a=fmtp:98 x-google-start-bitrate=4500")
        #expect(sections[2].fmtps.map(\.config) == ["profile-id=0;x-google-start-bitrate=4500", "x-google-start-bitrate=4500"])
        #expect(sections[3].fmtps.map(\.config) == ["packetization-mode=1;x-google-start-bitrate=4500"])
        #expect(sections[4].lines == original[4].lines)
    }

    @Test func startBitrateIsIdempotentAndPreservesUnrelatedSDP() {
        let once = Transport.mungeVideoStartBitrate(Self.publisherOffer, kbpsBySenderId: ["cam": 1000])

        #expect(Transport.mungeVideoStartBitrate(once, kbpsBySenderId: ["cam": 1000]) == once)
        #expect(once.hasSuffix("\r\n"))
        // Nothing mapped, no sending sender, or only a receive-only match: byte-identical.
        #expect(Transport.mungeVideoStartBitrate(Self.publisherOffer, kbpsBySenderId: [:]) == Self.publisherOffer)
        #expect(Transport.mungeVideoStartBitrate(Self.publisherOffer, kbpsBySenderId: ["absent": 1000]) == Self.publisherOffer)
        #expect(Transport.mungeVideoStartBitrate(Self.publisherOffer, kbpsBySenderId: ["stale": 1000]) == Self.publisherOffer)
        // Sections without an msid line are never matched.
        #expect(Transport.mungeVideoStartBitrate(Self.singlePCOffer, kbpsBySenderId: ["cam": 1000]) == Self.singlePCOffer)
    }

    /// The latch condition: only a video section's fmtp counts, and the value is irrelevant.
    @Test func carriesVideoStartBitrateLooksAtVideoFmtpOnly() {
        #expect(!Transport.carriesVideoStartBitrate(Self.singlePCOffer))
        #expect(!Transport.carriesVideoStartBitrate(Self.singlePCOffer.replacingOccurrences(
            of: "a=fmtp:111 minptime=10;useinbandfec=1", with: "a=fmtp:111 minptime=10;x-google-start-bitrate=1000",
        )))
        #expect(Transport.carriesVideoStartBitrate(Self.publisherOffer)) // the stale value on payload 97
        #expect(Transport.carriesVideoStartBitrate(Transport.mungeVideoStartBitrate(Self.singlePCOffer.replacingOccurrences(
            of: "a=mid:2\r\n", with: "a=mid:2\r\na=msid:- cam\r\n",
        ), kbpsBySenderId: ["cam": 1000])))
    }

    /// Same numbers as client-sdk-js, rust-sdks and client-sdk-android: 90% of the target,
    /// capped at 1 Mbps unless the track is a screen share, and no hint at all under 300 kbps.
    @Test func startBitrateFormula() {
        #expect(Transport.startBitrateKbps(targetBps: 2_300_000, isScreenShare: false, connectionSetupTime: nil) == 1000) // 2070, capped
        #expect(Transport.startBitrateKbps(targetBps: 800_000, isScreenShare: false, connectionSetupTime: nil) == 720)
        #expect(Transport.startBitrateKbps(targetBps: 300_000, isScreenShare: false, connectionSetupTime: nil) == 270)
        #expect(Transport.startBitrateKbps(targetBps: 5_000_000, isScreenShare: true, connectionSetupTime: nil) == 4500) // not capped
        #expect(Transport.startBitrateKbps(targetBps: 299_999, isScreenShare: false, connectionSetupTime: nil) == nil)
        #expect(Transport.startBitrateKbps(targetBps: 0, isScreenShare: true, connectionSetupTime: nil) == nil)
    }

    /// The cap ramps linearly from 1 Mbps at a 1.5 s connection setup down to 300 kbps at
    /// 3.5 s. Same cases as rust-sdks' `start_bitrate_ramps_down_with_connection_setup_time`,
    /// with the setup times measured on shaped links.
    @Test(arguments: [
        (nil, 1000), // no setup time keeps the ceiling
        (0.0, 1000),
        (1.273, 1000), // 1 Mbps link median
        (1.5, 1000), // the fast anchor
        (1.724, 922), // 1 Mbps link slow attempt barely moves
        (2.334, 708), // 500 kbps link median lands mid-ramp
        (2.5, 650), // midpoint of the ramp
        (3.093, 442), // 300 kbps link fastest attempt
        (3.5, 300), // the slow anchor reaches the floor
        (18.131, 300), // anything slower stays at the floor
    ] as [(TimeInterval?, Int)])
    func startBitrateCapRampsDownWithConnectionSetupTime(setupTime: TimeInterval?, expectedKbps: Int) {
        #expect(Transport.startBitrateCapKbps(connectionSetupTime: setupTime) == expectedKbps)
    }

    /// The setup-time cap applies to camera hints only; 90% of a lower target still wins, and
    /// screen share is never capped, however slow the setup.
    @Test func startBitrateFormulaWithConnectionSetupTime() {
        #expect(Transport.startBitrateKbps(targetBps: 3_000_000, isScreenShare: false, connectionSetupTime: 0.8) == 1000)
        #expect(Transport.startBitrateKbps(targetBps: 3_000_000, isScreenShare: false, connectionSetupTime: 2.5) == 650)
        #expect(Transport.startBitrateKbps(targetBps: 3_000_000, isScreenShare: false, connectionSetupTime: 5) == 300)
        #expect(Transport.startBitrateKbps(targetBps: 500_000, isScreenShare: false, connectionSetupTime: 2.5) == 450)
        #expect(Transport.startBitrateKbps(targetBps: 300_000, isScreenShare: false, connectionSetupTime: 5) == 270)
        #expect(Transport.startBitrateKbps(targetBps: 3_000_000, isScreenShare: true, connectionSetupTime: 5) == 2700)
    }

    /// Simulcast layers are summed (they are independent streams), inactive layers and layers
    /// without a `maxBitrate` contribute nothing.
    @Test func startBitrateSumsActiveEncodings() {
        let encodings = [(500_000, true), (1_500_000, true), (9_000_000, false)].map { bps, active in
            let encoding = LKRTCRtpEncodingParameters()
            encoding.maxBitrateBps = NSNumber(value: bps)
            encoding.isActive = active
            return encoding
        }

        #expect(Transport.startBitrateKbps(for: encodings, isScreenShare: true, connectionSetupTime: nil) == 1800)
        #expect(Transport.startBitrateKbps(for: encodings, isScreenShare: false, connectionSetupTime: nil) == 1000)
        #expect(Transport.startBitrateKbps(for: [LKRTCRtpEncodingParameters()], isScreenShare: false, connectionSetupTime: nil) == nil)
        #expect(Transport.startBitrateKbps(for: [], isScreenShare: false, connectionSetupTime: nil) == nil)
    }
}
