/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

/// Result of a ``VideoEncoder`` operation, mirroring WebRTC's video codec error codes.
///
/// Only codes WebRTC acts on are named. Any other negative value is logged and
/// the frame dropped. Positive values are not exposed: the stream encoder treats
/// them as success, but the simulcast adapter stops encoding the remaining
/// layers of a frame on anything other than ``ok``.
public struct VideoEncoderStatus: RawRepresentable, Sendable, Equatable, Hashable {
    /// The underlying WebRTC video codec error code.
    public let rawValue: Int

    /// Creates a status from a WebRTC video codec error code.
    public init(rawValue: Int) {
        self.rawValue = rawValue
    }

    /// The operation completed successfully.
    public static let ok = Self(rawValue: 0)
    /// The operation failed with a generic error.
    public static let error = Self(rawValue: -1)
    /// The operation failed due to a memory allocation failure.
    public static let memory = Self(rawValue: -3)
    /// The operation failed due to an invalid parameter.
    public static let invalidParameter = Self(rawValue: -4)
    /// The operation timed out.
    public static let timeout = Self(rawValue: -6)
    /// The encoder has not been initialized via ``VideoEncoder/startEncode(with:numberOfCores:)``.
    public static let uninitialized = Self(rawValue: -7)
    /// Requests WebRTC to fall back to another encoder for this codec.
    public static let fallbackSoftware = Self(rawValue: -13)
    /// The encoder cannot honor the requested simulcast configuration.
    public static let simulcastParametersNotSupported = Self(rawValue: -15)
    /// The encoder failed and should be released.
    public static let encoderFailure = Self(rawValue: -16)
}

extension VideoEncoderStatus: CustomStringConvertible {
    public var description: String {
        switch self {
        case .ok: "ok"
        case .error: "error"
        case .memory: "memory"
        case .invalidParameter: "invalidParameter"
        case .timeout: "timeout"
        case .uninitialized: "uninitialized"
        case .fallbackSoftware: "fallbackSoftware"
        case .simulcastParametersNotSupported: "simulcastParametersNotSupported"
        case .encoderFailure: "encoderFailure"
        default: "unknown(\(rawValue))"
        }
    }
}

/// Delivers an ``EncodedVideoFrame`` produced by a custom ``VideoEncoder`` to WebRTC.
///
/// Returns `true` if the frame was accepted for packetization and transport.
public typealias VideoEncoderCallback = @Sendable (EncodedVideoFrame) -> Bool

/// A custom video encoder implementation, mirroring WebRTC's `VideoEncoder` interface.
///
/// Create instances from a ``VideoEncoderFactory`` registered via
/// ``LiveKitSDK/set(videoEncoderFactory:)``. WebRTC drives the encoder lifecycle:
/// `startEncode` and `setCallback` are both called before the first frame, in
/// either order, then `encode` per captured frame, with `setBitrate` adapting to
/// network conditions, and finally `releaseEncoder`. The callback must not be
/// required until the first `encode`.
///
/// ### Threading
///
/// WebRTC sequences ``startEncode(with:numberOfCores:)``, ``setCallback(_:)``,
/// ``encode(_:frameTypes:)``, ``setBitrate(_:framerate:)`` and
/// ``releaseEncoder()`` on its encoder queue: one call at a time, though not
/// always from the same thread. The properties are read separately from those
/// calls, so they should be cheap and safe to read from any thread.
///
/// The callback may be invoked from whichever thread produces encoded frames.
/// WebRTC packetizes, encrypts and paces the frame synchronously inside it, so
/// it should not be invoked while holding a lock that ``encode(_:frameTypes:)``
/// or ``releaseEncoder()`` also takes.
///
/// - Note: The underlying WebRTC bridge reports every encoder as hardware
///   accelerated, so CPU overuse detection uses the more permissive thresholds
///   meant for hardware encoders. A software encoder should keep its own CPU
///   usage in check. Encoders must also accept any input resolution, since
///   alignment requirements cannot be communicated to WebRTC yet.
public protocol VideoEncoder: Sendable {
    /// Human readable name of the encoder implementation reported in stats.
    var implementationName: String { get }

    /// Whether the encoder accepts frames backed by `CVPixelBuffer` directly.
    ///
    /// Returning `false` only makes WebRTC scale a frame down to the layer
    /// resolution before handing it over, and that scaled frame is still a
    /// `CVPixelBuffer`. WebRTC never converts the input to planar data, so an
    /// encoder needing planes must call ``VideoFrame/toI420()`` itself either
    /// way. Defaults to `true`.
    var supportsNativeHandle: Bool { get }

    /// QP thresholds for WebRTC's quality scaler, or `nil` to disable quality scaling.
    /// Defaults to `nil`.
    var scalingSettings: VideoEncoderQpThresholds? { get }

    /// Sets the callback used to deliver encoded frames. Pass `nil` to clear.
    func setCallback(_ callback: VideoEncoderCallback?)

    /// Prepares the encoder for the given settings.
    func startEncode(with settings: VideoEncoderSettings, numberOfCores: Int) -> VideoEncoderStatus

    /// Encodes a single frame. Deliver the result asynchronously via the callback
    /// set in ``setCallback(_:)``. The encoded output must carry the frame's
    /// ``VideoFrame/rtpTimestamp``.
    /// - Parameter frameTypes: Requested frame types, one entry per stream. A `.key`
    ///   entry requests a key frame.
    func encode(_ frame: VideoFrame, frameTypes: [EncodedVideoFrame.FrameType]) -> VideoEncoderStatus

    /// Updates the target bitrate (kilobits per second) and framerate.
    func setBitrate(_ bitrateKbps: UInt32, framerate: UInt32) -> VideoEncoderStatus

    /// Releases encoder resources. No frames may be delivered to the callback
    /// after this returns. The encoder may be started again afterwards.
    func releaseEncoder() -> VideoEncoderStatus
}

public extension VideoEncoder {
    var supportsNativeHandle: Bool { true }
    var scalingSettings: VideoEncoderQpThresholds? { nil }
}
