/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

internal import LiveKitWebRTC

@objcMembers
public class LocalVideoTrack: Track, LocalTrackProtocol, @unchecked Sendable {
    public internal(set) var capturer: VideoCapturer

    // The owning reference: the capturer holds its delegate weakly. Boxed so the source's blocking
    // release is parked and its raw pointer cannot be used off the executor.
    private let videoSourceBox: RTCBox<LKRTCVideoSource>

    init(name: String,
         source: Track.Source,
         capturer: VideoCapturer,
         videoSource: LKRTCVideoSource,
         reportStatistics: Bool)
    {
        let rtcTrack = RTC.createVideoTrack(source: videoSource)
        rtcTrack.isEnabled = true

        self.capturer = capturer
        videoSourceBox = RTCBox(videoSource)

        super.init(name: name,
                   kind: .video,
                   source: source,
                   track: RTCMediaTrack(rtcTrack),
                   reportStatistics: reportStatistics)
    }

    public func mute() async throws {
        try await super._mute()
    }

    public func unmute() async throws {
        try await super._unmute()
    }

    // MARK: - Internal

    override func startCapture() async throws {
        try await capturer.startCapture()
    }

    override func stopCapture() async throws {
        try await capturer.stopCapture()
    }
}

// MARK: - VideoTrack Protocol

extension LocalVideoTrack: VideoTrackProtocol {
    public func add(videoRenderer: VideoRenderer) {
        capturer.rendererDelegates.add(delegate: videoRenderer)
    }

    public func remove(videoRenderer: VideoRenderer) {
        capturer.rendererDelegates.remove(delegate: videoRenderer)
    }
}

public extension LocalVideoTrack {
    var publishOptions: TrackPublishOptions? { super._state.lastPublishOptions }
    var publishState: Track.PublishState { super._state.publishState }

    /// Convenience access to ``VideoCapturer/processor``.
    var processor: VideoProcessor? {
        get { capturer._state.processor }
        set { capturer._state.mutate { $0.processor = newValue } }
    }
}

public extension LocalVideoTrack {
    /// Clone with same ``VideoCapturer``.
    @available(*, deprecated, message: "Blocks the calling thread until WebRTC's factory responds; use the async variant instead.")
    func clone() -> LocalVideoTrack {
        videoSourceBox.blocking { _clone(videoSource: $0) }
    }

    /// Clones with the same ``VideoCapturer`` on the RTC executor: the calling task suspends
    /// instead of blocking its thread on WebRTC's factory.
    func clone() async -> LocalVideoTrack {
        await RTC.run { _clone(videoSource: videoSourceBox.value) }
    }

    internal func _clone(videoSource: LKRTCVideoSource) -> LocalVideoTrack {
        LocalVideoTrack(name: name,
                        source: source,
                        capturer: capturer,
                        videoSource: videoSource,
                        reportStatistics: _state.reportStatistics)
    }
}
