/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

internal import LiveKitWebRTC

@objcMembers
public class RemoteParticipant: Participant, @unchecked Sendable {
    /// Data tracks published by this participant, keyed by track name.
    ///
    /// Names are the stable identifier: a track's SID rotates when the publisher republishes
    /// after a full reconnect (the track object itself survives).
    public var dataTracks: [String: RemoteDataTrack] {
        _state.dataTracks.reduce(into: [:]) { $0[$1.name] = $1 }
    }

    init(info: Livekit_ParticipantInfo, room: Room, connectionState: ConnectionState) {
        super.init(room: room, sid: Participant.Sid(from: info.sid), identity: Participant.Identity(from: info.identity))
        set(info: info, connectionState: connectionState)
    }

    /// Adds the track, returning `false` if this exact track is already attached. Identity-based
    /// so it stays race-free while the track's SID is being reassigned by the manager.
    @discardableResult
    func addDataTrack(_ track: RemoteDataTrack) -> Bool {
        _state.mutate {
            guard !$0.dataTracks.contains(where: { $0 === track }) else { return false }
            $0.dataTracks.append(track)
            return true
        }
    }

    @discardableResult
    func removeDataTrack(sid: DataTrack.Sid) -> RemoteDataTrack? {
        // `info` crosses the FFI boundary, so resolve the track before taking the state lock.
        guard let track = _state.dataTracks.first(where: { $0.info.sid == sid }) else { return nil }
        return _state.mutate {
            guard let index = $0.dataTracks.firstIndex(where: { $0 === track }) else { return nil }
            return $0.dataTracks.remove(at: index)
        }
    }

    /// Drops the data tracks without notifying, for when they outlive this participant object: a
    /// full reconnect recreates participants, but the data track subsystem keeps its tracks and
    /// re-attaches them, so they were never really unpublished.
    func detachDataTracks() {
        _state.mutate { $0.dataTracks = [] }
    }

    override func set(info: Livekit_ParticipantInfo, connectionState: ConnectionState) {
        super.set(info: info, connectionState: connectionState)

        var validTrackPublications = [Track.Sid: RemoteTrackPublication]()
        var newTrackPublications = [Track.Sid: RemoteTrackPublication]()

        for trackInfo in info.tracks {
            let trackSid = Track.Sid(from: trackInfo.sid)
            var publication = _state.trackPublications[trackSid] as? RemoteTrackPublication
            if publication == nil {
                publication = RemoteTrackPublication(info: trackInfo, participant: self)
                newTrackPublications[trackSid] = publication
                add(publication: publication!)
            } else {
                publication!.updateFromInfo(info: trackInfo)
            }
            validTrackPublications[trackSid] = publication!
        }

        guard let room = _room else {
            log("_room is nil", .error)
            return
        }

        if case .connected = connectionState {
            for publication in newTrackPublications.values {
                delegates.notify(label: { "participant.didPublish \(publication)" }) {
                    $0.participant?(self, didPublishTrack: publication)
                }
                room.delegates.notify(label: { "room.didPublish \(publication)" }) {
                    $0.room?(room, participant: self, didPublishTrack: publication)
                }
            }
        }

        let unpublishRemoteTrackPublications = _state.trackPublications.values
            .filter { validTrackPublications[$0.sid] == nil }
            .compactMap { $0 as? RemoteTrackPublication }

        for unpublishRemoteTrackPublication in unpublishRemoteTrackPublications {
            Task.detached {
                do {
                    try await self.unpublish(publication: unpublishRemoteTrackPublication)
                } catch {
                    self.log("Failed to unpublish with error: \(error)")
                }
            }
        }
    }

    private func notifyDidFailToSubscribe(trackSid: Track.Sid, room: Room, message: String) -> LiveKitError {
        let error = LiveKitError(.invalidState, message: message)
        delegates.notify(label: { "participant.didFailToSubscribe trackSid: \(trackSid)" }) {
            $0.participant?(self, didFailToSubscribeTrackWithSid: trackSid, error: error)
        }
        room.delegates.notify(label: { "room.didFailToSubscribe trackSid: \(trackSid)" }) {
            $0.room?(room, participant: self, didFailToSubscribeTrackWithSid: trackSid, error: error)
        }
        return error
    }

    func addSubscribedMediaTrack(mediaTrack: RTCMediaTrack, rtpReceiver: RTCReceiver, trackSid: Track.Sid) async throws {
        let room = try requireRoom()
        let track: Track

        guard let publication = trackPublications[trackSid] as? RemoteTrackPublication else {
            log("Could not subscribe to mediaTrack \(trackSid), unable to locate track publication. existing sids: (\(_state.trackPublications.keys.map { String(describing: $0) }.joined(separator: ", ")))", .error)
            throw notifyDidFailToSubscribe(trackSid: trackSid, room: room,
                                           message: "Could not find published track with sid: \(trackSid)")
        }

        // Constructed on the RTC executor: attaching the audio sink an audio track needs is a
        // signaling-thread BlockingCall, and this runs on a cooperative-pool task.
        let reportStatistics = room._state.roomOptions.reportRemoteTrackStatistics

        switch mediaTrack.kind {
        case "audio":
            track = await RTC.run { () -> Track in
                RemoteAudioTrack(name: publication.name,
                                 source: publication.source,
                                 track: mediaTrack,
                                 reportStatistics: reportStatistics)
            }
        case "video":
            track = await RTC.run { () -> Track in
                RemoteVideoTrack(name: publication.name,
                                 source: publication.source,
                                 track: mediaTrack,
                                 reportStatistics: reportStatistics)
            }
        default:
            throw notifyDidFailToSubscribe(trackSid: trackSid, room: room,
                                           message: "Unsupported type: \(mediaTrack.kind)")
        }

        await publication.set(track: track)
        publication.set(subscriptionAllowed: true)

        if let transport = room._state.transport?.subscriber {
            await track.set(transport: transport, rtpReceiver: rtpReceiver)
        } else {
            log("Transport is nil", .error)
        }

        add(publication: publication)

        try await track.start()

        delegates.notify(label: { "participant.didSubscribe \(publication)" }) {
            $0.participant?(self, didSubscribeTrack: publication)
        }
        room.delegates.notify(label: { "room.didSubscribe \(publication)" }) {
            $0.room?(room, participant: self, didSubscribeTrack: publication)
        }
    }

    override public func unpublishAll(notify _notify: Bool = true) async {
        // Build a list of Publications
        let publications = _state.trackPublications.values.compactMap { $0 as? RemoteTrackPublication }
        for publication in publications {
            do {
                try await unpublish(publication: publication, notify: _notify)
            } catch {
                log("Failed to unpublish track \(publication.sid) with error \(error)", .error)
            }
        }

        // Data tracks: on disconnect the participant is removed before the async manager callback
        // arrives, so it can't route the unpublish — clear them here, mirroring the media path.
        let dataTracks = _state.mutate { state in
            let tracks = state.dataTracks
            state.dataTracks = []
            return tracks
        }
        guard _notify, let room = _room else { return }
        // `info` crosses the FFI boundary; read it outside the state lock above.
        for sid in dataTracks.map(\.info.sid) {
            delegates.notify(label: { "participant.didUnpublishDataTrack \(sid)" }) {
                $0.participant?(self, didUnpublishDataTrack: sid)
            }
            room.delegates.notify(label: { "room.didUnpublishDataTrack \(sid)" }) {
                $0.room?(room, participant: self, didUnpublishDataTrack: sid)
            }
        }
    }

    func unpublish(publication: RemoteTrackPublication, notify _notify: Bool = true) async throws {
        let room = try requireRoom()

        func _notifyUnpublish() async {
            guard _notify else { return }
            delegates.notify(label: { "participant.didUnpublish \(publication)" }) {
                $0.participant?(self, didUnpublishTrack: publication)
            }
            room.delegates.notify(label: { "room.didUnpublish \(publication)" }) {
                $0.room?(room, participant: self, didUnpublishTrack: publication)
            }
        }

        // Remove the publication
        _state.mutate { $0.trackPublications.removeValue(forKey: publication.sid) }

        // Continue if the publication has a track
        guard let track = publication.track else {
            return await _notifyUnpublish()
        }

        try await track.stop()

        if _notify {
            // Notify unsubscribe
            delegates.notify(label: { "participant.didUnsubscribe \(publication)" }) {
                $0.participant?(self, didUnsubscribeTrack: publication)
            }
            room.delegates.notify(label: { "room.didUnsubscribe \(publication)" }) {
                $0.room?(room, participant: self, didUnsubscribeTrack: publication)
            }
        }

        await _notifyUnpublish()
    }
}
