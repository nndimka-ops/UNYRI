/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

internal import LiveKitFFI

@objc
public enum EncryptionType: Int, Sendable {
    case none
    case gcm
    case custom
}

extension EncryptionType {
    func toPBType() -> Livekit_Encryption.TypeEnum {
        switch self {
        case .none: .none
        case .gcm: .gcm
        case .custom: .custom
        default: .custom
        }
    }
}

extension EncryptionType {
    /// Bridges to and from the FFI enum. Lives here beside the protobuf conversions so the data
    /// stream types stay free of encryption-specific mapping code.
    var ffiValue: LiveKitFFI.EncryptionType {
        switch self {
        case .none: .none
        case .gcm: .gcm
        case .custom: .custom
        }
    }

    init(_ ffi: LiveKitFFI.EncryptionType) {
        switch ffi {
        case .none: self = .none
        case .gcm: self = .gcm
        case .custom: self = .custom
        // A scheme added after this SDK is still a scheme — never report it as plaintext.
        @unknown default: self = .custom
        }
    }
}

extension Livekit_Encryption.TypeEnum {
    func toLKType() -> EncryptionType {
        switch self {
        case .none: .none
        case .gcm: .gcm
        case .custom: .custom
        default: .custom
        }
    }
}

@available(*, deprecated, message: "Migrate to 'EncryptionOptions' instead. Important: It will enable data channel encryption by default (requires support from all platforms).")
@objcMembers
public final class E2EEOptions: NSObject, Sendable {
    public let keyProvider: BaseKeyProvider

    public let encryptionType: EncryptionType

    public init(keyProvider: BaseKeyProvider,
                encryptionType: EncryptionType = .gcm)
    {
        self.keyProvider = keyProvider
        self.encryptionType = encryptionType
    }

    // MARK: - Equal

    override public func isEqual(_ object: Any?) -> Bool {
        guard let other = object as? Self else { return false }
        return keyProvider == other.keyProvider &&
            encryptionType == other.encryptionType
    }

    override public var hash: Int {
        var hasher = Hasher()
        hasher.combine(keyProvider)
        hasher.combine(encryptionType)
        return hasher.finalize()
    }
}

@objcMembers
public final class EncryptionOptions: NSObject, Sendable {
    public let keyProvider: BaseKeyProvider

    public let encryptionType: EncryptionType

    public init(keyProvider: BaseKeyProvider,
                encryptionType: EncryptionType = .gcm)
    {
        self.keyProvider = keyProvider
        self.encryptionType = encryptionType
    }

    /// Creates `EncryptionOptions` configured with a shared-key
    /// `BaseKeyProvider` derived from the given passphrase.
    ///
    /// - Parameters:
    ///   - key: The shared passphrase used to derive the encryption key.
    ///   - encryptionType: The encryption algorithm to use. Defaults to `.gcm`.
    public static func sharedKey(_ key: String,
                                 encryptionType: EncryptionType = .gcm) -> EncryptionOptions
    {
        EncryptionOptions(keyProvider: BaseKeyProvider(isSharedKey: true, sharedKey: key),
                          encryptionType: encryptionType)
    }

    // MARK: - Equal

    override public func isEqual(_ object: Any?) -> Bool {
        guard let other = object as? Self else { return false }
        return keyProvider == other.keyProvider &&
            encryptionType == other.encryptionType
    }

    override public var hash: Int {
        var hasher = Hasher()
        hasher.combine(keyProvider)
        hasher.combine(encryptionType)
        return hasher.finalize()
    }
}
