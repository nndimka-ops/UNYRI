/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

internal import LiveKitWebRTC

@objc
public enum IceTransportPolicy: Int, Sendable {
    case none
    case relay
    case noHost
    case all
}

extension IceTransportPolicy {
    func toRTCType() -> LKRTCIceTransportPolicy {
        switch self {
        case .none: .none
        case .relay: .relay
        case .noHost: .noHost
        case .all: .all
        }
    }
}
