/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

@objcMembers
public final class RoomOptions: NSObject, Sendable, Loggable {
    // default options for capturing
    public let defaultCameraCaptureOptions: CameraCaptureOptions

    public let defaultScreenShareCaptureOptions: ScreenShareCaptureOptions

    public let defaultAudioCaptureOptions: AudioCaptureOptions

    // default options for publishing
    public let defaultVideoPublishOptions: VideoPublishOptions

    public let defaultAudioPublishOptions: AudioPublishOptions

    public let defaultDataPublishOptions: DataPublishOptions

    /// Options controlling how incoming data streams are handled (e.g. the maximum accepted
    /// payload size).
    public let dataStreamOptions: DataStreamOptions

    /// AdaptiveStream lets LiveKit automatically manage quality of subscribed
    /// video tracks to optimize for bandwidth and CPU.
    /// When attached video elements are visible, it'll choose an appropriate
    /// resolution based on the size of largest video element it's attached to.
    ///
    /// When none of the video elements are visible, it'll temporarily pause
    /// the data flow until they are visible again.
    ///
    public let adaptiveStream: Bool

    /// Dynamically pauses video layers that are not being consumed by any subscribers,
    /// significantly reducing publishing CPU and bandwidth usage.
    ///
    public let dynacast: Bool

    public let stopLocalTrackOnUnpublish: Bool

    /// Automatically suspend(mute) local camera video tracks when the app enters background and
    /// resume(unmute) when the app enters foreground again.
    public let suspendLocalVideoTracksInBackground: Bool

    /// E2EE Options
    public let e2eeOptions: E2EEOptions?
    /// Encryption
    public let encryptionOptions: EncryptionOptions?

    public let reportRemoteTrackStatistics: Bool

    /// Use a single peer connection for both publishing and subscribing.
    ///
    /// - Note: Requires LiveKit Cloud or LiveKit OSS >= 1.9.2.
    public let singlePeerConnection: Bool

    override public init() {
        defaultCameraCaptureOptions = CameraCaptureOptions()
        defaultScreenShareCaptureOptions = ScreenShareCaptureOptions()
        defaultAudioCaptureOptions = AudioCaptureOptions()
        defaultVideoPublishOptions = VideoPublishOptions()
        defaultAudioPublishOptions = AudioPublishOptions()
        defaultDataPublishOptions = DataPublishOptions()
        dataStreamOptions = DataStreamOptions()
        adaptiveStream = false
        dynacast = false
        stopLocalTrackOnUnpublish = true
        suspendLocalVideoTracksInBackground = true
        e2eeOptions = nil
        encryptionOptions = nil
        reportRemoteTrackStatistics = false
        singlePeerConnection = false
    }

    public init(defaultCameraCaptureOptions: CameraCaptureOptions = CameraCaptureOptions(),
                defaultScreenShareCaptureOptions: ScreenShareCaptureOptions = ScreenShareCaptureOptions(),
                defaultAudioCaptureOptions: AudioCaptureOptions = AudioCaptureOptions(),
                defaultVideoPublishOptions: VideoPublishOptions = VideoPublishOptions(),
                defaultAudioPublishOptions: AudioPublishOptions = AudioPublishOptions(),
                defaultDataPublishOptions: DataPublishOptions = DataPublishOptions(),
                dataStreamOptions: DataStreamOptions = DataStreamOptions(),
                adaptiveStream: Bool = false,
                dynacast: Bool = false,
                stopLocalTrackOnUnpublish: Bool = true,
                suspendLocalVideoTracksInBackground: Bool = true,
                e2eeOptions: E2EEOptions? = nil,
                encryptionOptions: EncryptionOptions? = nil,
                reportRemoteTrackStatistics: Bool = false,
                singlePeerConnection: Bool = false)
    {
        self.defaultCameraCaptureOptions = defaultCameraCaptureOptions
        self.defaultScreenShareCaptureOptions = defaultScreenShareCaptureOptions
        self.defaultAudioCaptureOptions = defaultAudioCaptureOptions
        self.defaultVideoPublishOptions = defaultVideoPublishOptions
        self.defaultAudioPublishOptions = defaultAudioPublishOptions
        self.defaultDataPublishOptions = defaultDataPublishOptions
        self.dataStreamOptions = dataStreamOptions
        self.adaptiveStream = adaptiveStream
        self.dynacast = dynacast
        self.stopLocalTrackOnUnpublish = stopLocalTrackOnUnpublish
        self.suspendLocalVideoTracksInBackground = suspendLocalVideoTracksInBackground
        self.e2eeOptions = e2eeOptions
        self.encryptionOptions = encryptionOptions
        self.reportRemoteTrackStatistics = reportRemoteTrackStatistics
        self.singlePeerConnection = singlePeerConnection

        super.init()

        if e2eeOptions != nil, encryptionOptions != nil {
            log("Specifying both 'e2eeOptions' and 'encryptionOptions' is not supported. Migrate to 'EncryptionOptions' to enable data channel encryption (requires support from all platforms).", .error)
        }
    }

    /// The initializer without `dataStreamOptions`, which defaults to ``DataStreamOptions/init()``.
    /// Keeps code and binaries built against the earlier signature working.
    public convenience init(defaultCameraCaptureOptions: CameraCaptureOptions = CameraCaptureOptions(),
                            defaultScreenShareCaptureOptions: ScreenShareCaptureOptions = ScreenShareCaptureOptions(),
                            defaultAudioCaptureOptions: AudioCaptureOptions = AudioCaptureOptions(),
                            defaultVideoPublishOptions: VideoPublishOptions = VideoPublishOptions(),
                            defaultAudioPublishOptions: AudioPublishOptions = AudioPublishOptions(),
                            defaultDataPublishOptions: DataPublishOptions = DataPublishOptions(),
                            adaptiveStream: Bool = false,
                            dynacast: Bool = false,
                            stopLocalTrackOnUnpublish: Bool = true,
                            suspendLocalVideoTracksInBackground: Bool = true,
                            e2eeOptions: E2EEOptions? = nil,
                            encryptionOptions: EncryptionOptions? = nil,
                            reportRemoteTrackStatistics: Bool = false,
                            singlePeerConnection: Bool = false)
    {
        self.init(defaultCameraCaptureOptions: defaultCameraCaptureOptions,
                  defaultScreenShareCaptureOptions: defaultScreenShareCaptureOptions,
                  defaultAudioCaptureOptions: defaultAudioCaptureOptions,
                  defaultVideoPublishOptions: defaultVideoPublishOptions,
                  defaultAudioPublishOptions: defaultAudioPublishOptions,
                  defaultDataPublishOptions: defaultDataPublishOptions,
                  dataStreamOptions: DataStreamOptions(),
                  adaptiveStream: adaptiveStream,
                  dynacast: dynacast,
                  stopLocalTrackOnUnpublish: stopLocalTrackOnUnpublish,
                  suspendLocalVideoTracksInBackground: suspendLocalVideoTracksInBackground,
                  e2eeOptions: e2eeOptions,
                  encryptionOptions: encryptionOptions,
                  reportRemoteTrackStatistics: reportRemoteTrackStatistics,
                  singlePeerConnection: singlePeerConnection)
    }

    // MARK: - Equal

    override public func isEqual(_ object: Any?) -> Bool {
        guard let other = object as? Self else { return false }
        return defaultCameraCaptureOptions == other.defaultCameraCaptureOptions &&
            defaultScreenShareCaptureOptions == other.defaultScreenShareCaptureOptions &&
            defaultAudioCaptureOptions == other.defaultAudioCaptureOptions &&
            defaultVideoPublishOptions == other.defaultVideoPublishOptions &&
            defaultAudioPublishOptions == other.defaultAudioPublishOptions &&
            defaultDataPublishOptions == other.defaultDataPublishOptions &&
            dataStreamOptions == other.dataStreamOptions &&
            adaptiveStream == other.adaptiveStream &&
            dynacast == other.dynacast &&
            stopLocalTrackOnUnpublish == other.stopLocalTrackOnUnpublish &&
            suspendLocalVideoTracksInBackground == other.suspendLocalVideoTracksInBackground &&
            e2eeOptions == other.e2eeOptions &&
            encryptionOptions == other.encryptionOptions &&
            reportRemoteTrackStatistics == other.reportRemoteTrackStatistics &&
            singlePeerConnection == other.singlePeerConnection
    }

    override public var hash: Int {
        var hasher = Hasher()
        hasher.combine(defaultCameraCaptureOptions)
        hasher.combine(defaultScreenShareCaptureOptions)
        hasher.combine(defaultAudioCaptureOptions)
        hasher.combine(defaultVideoPublishOptions)
        hasher.combine(defaultAudioPublishOptions)
        hasher.combine(defaultDataPublishOptions)
        hasher.combine(dataStreamOptions)
        hasher.combine(adaptiveStream)
        hasher.combine(dynacast)
        hasher.combine(stopLocalTrackOnUnpublish)
        hasher.combine(suspendLocalVideoTracksInBackground)
        hasher.combine(e2eeOptions)
        hasher.combine(encryptionOptions)
        hasher.combine(reportRemoteTrackStatistics)
        hasher.combine(singlePeerConnection)
        return hasher.finalize()
    }
}
