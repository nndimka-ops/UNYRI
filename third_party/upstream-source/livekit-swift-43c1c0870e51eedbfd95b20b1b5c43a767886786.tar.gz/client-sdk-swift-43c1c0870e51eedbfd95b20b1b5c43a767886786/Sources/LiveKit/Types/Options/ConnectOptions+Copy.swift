/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

public extension ConnectOptions {
    func copyWith(autoSubscribe: ValueOrAbsent<Bool> = .absent,
                  reconnectAttempts: ValueOrAbsent<Int> = .absent,
                  reconnectAttemptDelay: ValueOrAbsent<TimeInterval> = .absent,
                  reconnectMaxDelay: ValueOrAbsent<TimeInterval> = .absent,
                  protocolVersion: ValueOrAbsent<ProtocolVersion> = .absent,
                  clientProtocol: ValueOrAbsent<ClientProtocol> = .absent) -> ConnectOptions
    {
        ConnectOptions(autoSubscribe: autoSubscribe.value(ifAbsent: self.autoSubscribe),
                       reconnectAttempts: reconnectAttempts.value(ifAbsent: self.reconnectAttempts),
                       reconnectAttemptDelay: reconnectAttemptDelay.value(ifAbsent: self.reconnectAttemptDelay),
                       reconnectMaxDelay: reconnectMaxDelay.value(ifAbsent: self.reconnectMaxDelay),
                       protocolVersion: protocolVersion.value(ifAbsent: self.protocolVersion),
                       clientProtocol: clientProtocol.value(ifAbsent: self.clientProtocol))
    }
}
