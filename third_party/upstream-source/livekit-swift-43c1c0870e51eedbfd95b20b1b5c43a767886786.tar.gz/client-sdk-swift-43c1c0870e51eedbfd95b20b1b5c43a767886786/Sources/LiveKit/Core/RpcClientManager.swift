/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

/// Caller-side RPC.
///
/// Owns the in-flight bookkeeping (pending acks and pending responses) and the wire-level
/// publishing of v1 RPC packets / v2 RPC request streams. `LocalParticipant.performRpc`
/// is a one-line proxy that forwards into this actor.
actor RpcClientManager: Loggable {
    /// Default upper bound on round-trip latency to the destination, in seconds. Used by the
    /// ack watchdog and to clamp the effective response timeout. Exposed so the public
    /// `LocalParticipant.performRpc` overloads can share the same default.
    static let defaultMaxRoundTripLatency: TimeInterval = 7

    /// Default timeout for receiving a response after the initial connection, in seconds.
    static let defaultResponseTimeout: TimeInterval = 15

    private weak var room: Room?

    private(set) var pendingAcks: Set<String> = Set()
    private(set) var pendingResponses: [String: PendingRpcResponse] = [:]
    private(set) var ackWatchdogs: [String: AnyTaskCancellable] = [:]

    /// Hook fired once after the RPC request has been published but before the caller
    /// starts waiting on the completer. Receives the freshly-generated `requestId` so
    /// a caller can simulate a fast remote ack/response that races the wait. Used by
    /// tests (reachable via `@testable import LiveKit`).
    var afterPublish: (@Sendable (String) async -> Void)?

    func attach(to room: Room) {
        self.room = room
    }

    func setAfterPublish(_ hook: (@Sendable (String) async -> Void)?) {
        afterPublish = hook
    }

    // MARK: - Public entry point

    /// Initiate an RPC call to a remote participant. Transport selection is automatic and
    /// matches the SDK's documented behavior: peer's `clientProtocol >= .v1` → v2 data stream,
    /// otherwise v1 packet.
    func performRpc(destinationIdentity: Participant.Identity,
                    method: String,
                    payload: String,
                    responseTimeout: TimeInterval = RpcClientManager.defaultResponseTimeout,
                    maxRoundTripLatency: TimeInterval = RpcClientManager.defaultMaxRoundTripLatency) async throws -> String
    {
        // A call cancelled before it starts sends nothing, like the data stream methods.
        try Task.checkCancellation()
        let room = try requireRoom()

        let remoteClientProtocol = room.remoteParticipants[destinationIdentity]?.clientProtocol ?? .v0
        let useStreamTransport = remoteClientProtocol >= .v1 && Self.serverSupportsRpcV2(room.serverVersion)

        let requestId = UUID().uuidString
        let minEffectiveTimeout: TimeInterval = maxRoundTripLatency + 1
        let effectiveTimeout = max(responseTimeout, minEffectiveTimeout)

        // Pre-register pending state synchronously on the actor *before* publishing the
        // request. Prevents a race where a fast remote can ack/respond before registration
        // completes — the response would otherwise log "received for unexpected request" and
        // the call would hang to the outer responseTimeout.
        let completer = AsyncCompleter<String>(label: "rpc-\(requestId)", defaultTimeout: responseTimeout)
        pendingAcks.insert(requestId)
        pendingResponses[requestId] = PendingRpcResponse(
            participantIdentity: destinationIdentity,
            completer: completer,
        )

        do {
            if useStreamTransport {
                try await publishRequestStream(in: room,
                                               destinationIdentity: destinationIdentity,
                                               requestId: requestId,
                                               method: method,
                                               payload: payload,
                                               responseTimeout: effectiveTimeout)
            } else {
                try await publishRequest(in: room,
                                         destinationIdentity: destinationIdentity,
                                         requestId: requestId,
                                         method: method,
                                         payload: payload,
                                         responseTimeout: effectiveTimeout)
            }
        } catch {
            // Publish failed — clean up the registered state before re-throwing.
            removeAllPending(requestId)
            try Task.checkCancellation()
            throw error
        }

        await afterPublish?(requestId)

        // Ack watchdog: fail fast if no ack arrives within maxRoundTripLatency.
        // Stored as `AnyTaskCancellable` so the deferred cleanup cancels the sleep
        // when the call resolves early.
        ackWatchdogs[requestId] = Task { [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(maxRoundTripLatency * 1_000_000_000))
            guard let self else { return }
            await fireAckTimeoutIfPending(requestId: requestId)
        }.cancellable()

        defer { removeAllPending(requestId) }
        do {
            return try await completer.wait()
        } catch {
            // A cancelled caller gets `CancellationError`, not the completer's `LiveKitError(.cancelled)`.
            try Task.checkCancellation()
            // AsyncCompleter signals its own `defaultTimeout` expiry with `LiveKitError(.timedOut)`.
            // That path means "we got the ack (or the ack-watchdog hasn't fired yet) but the
            // user-supplied `responseTimeout` elapsed without a response" → `responseTimeout`
            // (1502). The ack-watchdog path resolves the completer directly with
            // `connectionTimeout` (1501) and falls through the `throw error` branch.
            if let error = error as? LiveKitError, error.type == .timedOut {
                throw RpcError.builtIn(.responseTimeout)
            }
            throw error
        }
    }

    // MARK: - Server-version compatibility

    /// v2 data-stream RPC requires server ≥ 1.8.0. Returns `true` when the server version
    /// is unknown (e.g. before signaling completes) so we don't downgrade unnecessarily.
    /// Older servers silently fall back to the v1 packet path; a >15 KB payload then
    /// surfaces as `requestPayloadTooLarge` (1402) on `publishRequest`.
    static func serverSupportsRpcV2(_ serverVersion: String?) -> Bool {
        guard let serverVersion else { return true }
        return serverVersion.compare("1.8.0", options: .numeric) != .orderedAscending
    }

    /// Watchdog terminal action: if `requestId` is still awaiting an ack, clear pending
    /// state and resolve its completer with `connectionTimeout`. AsyncCompleter idempotency
    /// makes this safe even if a real response has already resolved the completer between
    /// the watchdog scheduling and this call running.
    func fireAckTimeoutIfPending(requestId: String) {
        guard pendingAcks.contains(requestId) else { return }
        pendingAcks.remove(requestId)
        let pending = pendingResponses.removeValue(forKey: requestId)
        pending?.completer.resume(throwing: RpcError.builtIn(.connectionTimeout))
    }

    // MARK: - Incoming dispatch

    /// Resolve a pending RPC call from a v1 `RpcResponse` packet. Note that `pendingAcks`
    /// is intentionally not cleared here — the watchdog's gate stays armed until either
    /// `handleIncomingAck` or `fireAckTimeoutIfPending` clears it. Either path is safe
    /// because the completer is idempotent.
    func handleIncomingResponse(requestId: String,
                                payload: String?,
                                error: RpcError?)
    {
        guard let pending = pendingResponses.removeValue(forKey: requestId) else {
            log("[Rpc] Response received for unexpected RPC request, id = \(requestId)")
            return
        }
        if let error {
            pending.completer.resume(throwing: error)
        } else {
            pending.completer.resume(returning: payload ?? "")
        }
    }

    /// Resolve a pending RPC call from a v2 response stream on `lk.rpc_response`. Reads the
    /// `lk.rpc_request_id` attribute to match against pending requests, then resolves
    /// with the streamed payload — but only if `senderIdentity` matches the original
    /// destination of the call. A response from any other peer is ignored (and the
    /// pending entry is left in place so the legitimate sender can still resolve).
    func handleIncomingResponseStream(reader: some TextStreamReading, senderIdentity: Participant.Identity) async {
        guard let requestId = reader.info.attributes[RpcStreamAttribute.requestId] else {
            log("[Rpc] Incoming v2 RPC response stream is missing request id attribute", .error)
            return
        }

        // Validate the request and the sender BEFORE reading the stream — matches JS and avoids
        // burning cycles (or worse, hitting `readAll` side effects) on a late or spoofed
        // payload. After this check passes, both the success and read-failure
        // paths trust the sender and resume the pending call directly.
        guard let expected = pendingResponses[requestId] else {
            log("[Rpc] Response stream received for unexpected RPC request, id = \(requestId)")
            return
        }
        guard expected.participantIdentity == senderIdentity else {
            log("[Rpc] Response stream for \(requestId) from wrong sender (expected \(expected.participantIdentity), got \(senderIdentity)); ignoring", .error)
            return
        }

        let payload: String
        do {
            payload = try await reader.readAll()
        } catch {
            // The call can end while the stream is read, for example when its task is cancelled.
            guard let pending = pendingResponses.removeValue(forKey: requestId) else {
                log("[Rpc] Failed to read v2 RPC response payload for \(requestId), which is no longer pending: \(error)")
                return
            }
            log("[Rpc] Failed to read v2 RPC response payload for \(requestId): \(error)", .error)
            // Fail the pending call fast instead of letting it hang to responseTimeout.
            pending.completer.resume(throwing: RpcError(code: RpcError.BuiltInError.applicationError.code,
                                                        message: "Error reading RPC response payload",
                                                        data: ""))
            return
        }

        guard let pending = pendingResponses.removeValue(forKey: requestId) else {
            log("[Rpc] Response stream received for unexpected RPC request, id = \(requestId)")
            return
        }
        pending.completer.resume(returning: payload)
    }

    /// Clear the pending-ack flag for a request when an `RpcAck` arrives.
    func handleIncomingAck(requestId: String) {
        pendingAcks.remove(requestId)
    }

    /// Reject every in-flight RPC targeting `identity` with `recipientDisconnected`
    /// (1503). Called from `Room._onParticipantDidDisconnect(identity:)` so the caller
    /// learns immediately instead of waiting for the user-supplied `responseTimeout`.
    /// AsyncCompleter idempotency makes this safe even if a real response races the
    /// disconnect.
    func handleParticipantDisconnected(_ identity: Participant.Identity) {
        let toReap = pendingResponses.filter { $0.value.participantIdentity == identity }
        for (requestId, pending) in toReap {
            pendingResponses.removeValue(forKey: requestId)
            pendingAcks.remove(requestId)
            ackWatchdogs.removeValue(forKey: requestId)
            pending.completer.resume(throwing: RpcError.builtIn(.recipientDisconnected))
        }
    }

    /// Reject every in-flight RPC with `recipientDisconnected`. Called from
    /// `Room.cleanUp(...)` during teardown / full reconnect — at that point no
    /// participant survives, so identity-filtering is unnecessary.
    func handleAllPendingDisconnected() {
        for (_, pending) in pendingResponses {
            pending.completer.resume(throwing: RpcError.builtIn(.recipientDisconnected))
        }
        pendingResponses.removeAll()
        pendingAcks.removeAll()
        ackWatchdogs.removeAll()
    }

    // MARK: - State ops

    /// Number of in-flight RPCs awaiting a response. Exposed for test-time leak checks.
    var pendingCount: Int {
        pendingResponses.count
    }

    func removeAllPending(_ requestId: String) {
        pendingAcks.remove(requestId)
        pendingResponses.removeValue(forKey: requestId)
        ackWatchdogs.removeValue(forKey: requestId)
    }

    // MARK: - Outgoing wire

    // swiftlint:disable:next function_parameter_count
    private func publishRequest(in room: Room,
                                destinationIdentity: Participant.Identity,
                                requestId: String,
                                method: String,
                                payload: String,
                                responseTimeout: TimeInterval) async throws
    {
        guard payload.byteLength <= MAX_RPC_PAYLOAD_BYTES else {
            throw RpcError.builtIn(.requestPayloadTooLarge)
        }

        let dataPacket = Livekit_DataPacket.with {
            $0.destinationIdentities = [destinationIdentity.stringValue]
            $0.kind = .reliable
            $0.rpcRequest = Livekit_RpcRequest.with {
                $0.id = requestId
                $0.method = method
                $0.payload = payload
                $0.responseTimeoutMs = UInt32(responseTimeout * 1000)
                $0.version = 1
            }
        }

        try await room.send(dataPacket: dataPacket)
    }

    // swiftlint:disable:next function_parameter_count
    private func publishRequestStream(in room: Room,
                                      destinationIdentity: Participant.Identity,
                                      requestId: String,
                                      method: String,
                                      payload: String,
                                      responseTimeout: TimeInterval) async throws
    {
        let options = StreamTextOptions(
            topic: RpcStreamTopic.request,
            attributes: [
                RpcStreamAttribute.requestId: requestId,
                RpcStreamAttribute.method: method,
                RpcStreamAttribute.timeoutMs: String(UInt32(responseTimeout * 1000)),
                RpcStreamAttribute.version: RPC_STREAM_VERSION,
            ],
            destinationIdentities: [destinationIdentity],
        )
        let writer = try await room.localParticipant.streamText(options: options)
        try await writer.write(payload)
        try await writer.close()
    }

    // MARK: - Helpers

    private func requireRoom() throws -> Room {
        guard let room else { throw LiveKitError(.invalidState, message: "Room is nil") }
        return room
    }
}
