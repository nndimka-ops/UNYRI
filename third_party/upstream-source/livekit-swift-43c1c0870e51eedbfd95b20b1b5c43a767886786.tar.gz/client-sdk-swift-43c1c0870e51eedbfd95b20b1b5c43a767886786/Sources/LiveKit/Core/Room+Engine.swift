/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// swiftlint:disable file_length

import Foundation

#if canImport(Network)
import Network
#endif

internal import LiveKitWebRTC

// Room+Engine
extension Room {
    // MARK: - Public

    typealias ConditionEvalFunc = @Sendable (_ newState: State, _ oldState: State?) -> Bool

    // MARK: - Private

    struct ConditionalExecutionEntry {
        let executeCondition: ConditionEvalFunc
        let removeCondition: ConditionEvalFunc
        let block: @Sendable () -> Void
    }

    // Resets state of transports
    func cleanUpRTC(withError disconnectError: Error? = nil) async {
        // Close data channels
        publisherDataChannel.reset(throwing: disconnectError)
        subscriberDataChannel.reset(throwing: disconnectError)

        await _state.transport?.close()

        // Retire the join only after the transports are down: teardown gates (e.g. the data-track
        // publish gate) re-arm off the closing channels, so the "no transport" window that
        // in-flight callers observe must not open before they do.
        _ = _state.mutate {
            $0.hasPublished = false
            return $0.stage.retireJoin()
        }
    }

    func publisherShouldNegotiate(force: Bool = false) async throws {
        log()

        let publisher = try requirePublisher()
        try await publisher.negotiate(force: force)
        _state.mutate { $0.hasPublished = true }
    }

    func send(userPacket: Livekit_UserPacket, kind: Livekit_DataPacket_Kind) async throws {
        try await send(dataPacket: .with {
            $0.user = userPacket
            $0.kind = kind
        })
    }

    /// Negotiates the publisher peer connection on demand and waits for it to connect.
    ///
    /// Transport only — it gates on no data channel. Callers about to write a packet want
    /// ``ensureDataChannelReady(kind:)``, which adds the channel's own latch.
    func ensurePublisherConnected() async throws {
        // Subscriber-primary dual PC is the only mode that defers publisher negotiation until
        // something is published; elsewhere `connect()` already waited for this transport.
        guard case .subscriberPrimary = _state.transport else { return }

        let publisher = try requirePublisher()

        let connectionState = await publisher.connectionState
        if connectionState != .connected, connectionState != .connecting {
            try await publisherShouldNegotiate()
        }

        try await publisherTransportConnectedCompleter.wait(timeout: _state.connectOptions.publisherTransportConnectTimeout)
    }

    /// Waits until the channel a packet of `kind` will be written to can take bytes, negotiating
    /// the publisher first where that is deferred.
    ///
    /// The channel wait is **not** conditional on the transport mode, which is what the old
    /// `guard case .subscriberPrimary` made it. `connect()` returns once the *primary* transport is
    /// connected and never waits on data channels — those open on the SCTP association afterwards —
    /// so where the publisher is primary a send issued right after connect races the channel
    /// opening. That race is not benign: an ungated write lands in the drain's queue, and under
    /// `.dropOldest` the next submitter evicts it and resolves its waiter *successfully*, so a
    /// burst of publishes right after connect collapses to its last packet with every earlier one
    /// reporting success.
    ///
    /// - Parameter kind: Gates on this kind's channel alone; see ``DataChannelPair/whenOpen(kind:)``.
    func ensureDataChannelReady(kind: Livekit_DataPacket_Kind) async throws {
        // Nothing can open a channel once teardown has started, so the latch below has nothing that
        // could resolve it and the wait would only burn its full timeout.
        //
        // `.reconnecting` is let through, but note that a *full* reconnect runs `cleanUpRTC` and so
        // fails anything waiting here — along with everything already queued in the drains. The two
        // go together on purpose: preserving a gate waiter while failing the writes behind it would
        // only move where the caller finds out. (`DataTracks` does preserve its own gate across a
        // reconnect; it has no queued writes to contradict.) A quick reconnect never resets, so a
        // send spanning one parks and ships on the resumed channel.
        switch _state.connectionState {
        case .disconnecting, .disconnected:
            throw LiveKitError(.invalidState, message: "Room is not connected")
        case .connecting, .reconnecting, .connected:
            break
        }

        // Concurrently: in subscriber-primary mode the channel opens on the SCTP association the
        // transport is still bringing up, so the two complete together.
        async let transportReady: Void = ensurePublisherConnected()
        async let channelReady: Void = publisherDataChannel.whenOpen(kind: kind).wait()
        _ = try await (transportReady, channelReady)
    }

    func send(dataPacket packet: consuming Livekit_DataPacket) async throws {
        // The same field `DataChannelPair.send` routes on, so the channel awaited here is the one
        // the packet is handed to.
        let kind = packet.kind
        try await ensureDataChannelReady(kind: kind)

        // At this point publisher should be .connected and dc should be .open
        if await !(_state.transport?.publisher.isConnected ?? false) {
            log("publisher is not .connected", .error)
        }

        // A data stream packet sent on behalf of another identity already names it, and the
        // server decides whether to accept that. Every other packet is sent as the local participant.
        let keepsIdentity = switch packet.value {
        case .streamHeader, .streamChunk, .streamTrailer: !packet.participantIdentity.isEmpty
        default: false
        }

        // `modifying` is consuming: with no other owner this stamps in place,
        // where the per-field setters used to deep-copy the whole payload.
        let stamped = packet.modifying {
            if !keepsIdentity, let identity = localParticipant.identity?.stringValue {
                $0.participantIdentity = identity
            }
            if let sid = localParticipant.sid?.stringValue {
                $0.participantSid = sid
            }
        }

        try await publisherDataChannel.send(dataPacket: stamped)
    }
}

// MARK: - Internal

extension Room {
    /// Builds the peer connection configuration.
    ///
    /// - Parameter connectResponse: The JOIN/RECONNECT response, or `nil` before the socket has
    ///   opened. Without it the server's ICE servers and relay policy are unknown, so the result
    ///   carries client-side settings only and must be replaced via `Transport.set(configuration:)`
    ///   once the response arrives — see ``EarlyPublisher``.
    func makeRTCConfiguration(connectResponse: SignalClient.ConnectResponse?) -> LKRTCConfiguration {
        let connectOptions = _state.connectOptions

        // Make a copy, instead of modifying the user-supplied RTCConfiguration object.
        let rtcConfiguration = LKRTCConfiguration.liveKitDefault()

        // Set iceServers provided by the server
        rtcConfiguration.iceServers = connectResponse?.rtcIceServers ?? []

        if !connectOptions.iceServers.isEmpty {
            // Override with user provided iceServers
            rtcConfiguration.iceServers = connectOptions.iceServers.map { $0.toRTCType() }
        }

        if connectResponse?.clientConfiguration.forceRelay == .enabled {
            rtcConfiguration.iceTransportPolicy = .relay
        } else {
            rtcConfiguration.iceTransportPolicy = connectOptions.iceTransportPolicy.toRTCType()
        }

        rtcConfiguration.enableDscp = connectOptions.isDscpEnabled

        return rtcConfiguration
    }

    func configureTransports(connectResponse: SignalClient.ConnectResponse,
                             singlePeerConnection: Bool,
                             earlyPublisher: EarlyPublisher? = nil) async throws
    {
        let rtcConfiguration = makeRTCConfiguration(connectResponse: connectResponse)

        if case let .join(joinResponse) = connectResponse {
            log("Configuring transports with JOIN response...")

            guard case let .connecting(connection) = _state.stage else {
                log("Received JOIN without a connecting stage", .error)
                throw LiveKitError(.invalidState, message: "Received JOIN without a connecting stage")
            }

            let join = try await JoinDependencies.make(room: self,
                                                       connection: connection,
                                                       joinResponse: joinResponse,
                                                       rtcConfiguration: rtcConfiguration,
                                                       singlePeerConnection: singlePeerConnection,
                                                       earlyPublisher: earlyPublisher)
            do {
                try _state.mutate { try $0.stage.join(join) }
            } catch {
                await join.transport.close()
                throw error
            }
        } else if case let .reconnect(reconnectResponse) = connectResponse {
            log("[Connect] Configuring transports with RECONNECT response...")
            try await _state.transport?.set(configuration: rtcConfiguration)
            publisherDataChannel.retryReliable(lastSequence: reconnectResponse.lastMessageSeq)
        }
    }
}

// MARK: - Execution control (Internal)

extension Room {
    func execute(when condition: @escaping ConditionEvalFunc,
                 removeWhen removeCondition: @escaping ConditionEvalFunc,
                 _ block: @Sendable @escaping () -> Void)
    {
        // already matches condition, execute immediately
        if _state.read({ condition($0, nil) }) {
            log("[execution control] executing immediately...")
            block()
        } else {
            _blockProcessQueue.async { [weak self] in
                guard let self else { return }

                // create an entry and enqueue block
                log("[execution control] enqueuing entry...")

                let entry = ConditionalExecutionEntry(executeCondition: condition,
                                                      removeCondition: removeCondition,
                                                      block: block)

                _queuedBlocks.append(entry)
            }
        }
    }
}

// MARK: - Connection / Reconnection logic

public enum StartReconnectReason: Sendable {
    case websocket
    case transport
    case networkSwitch
    case debug
}

// Room+ConnectSequences
extension Room {
    /// The outcome of ``connectSignal(_:_:singlePC:earlyPublisher:)``: what the server answered,
    /// and the connect state as it stands after any fallback.
    private struct SignalConnection {
        let response: SignalClient.ConnectResponse
        let singlePC: Bool
        let earlyPublisher: EarlyPublisher?
    }

    /// Opens the signal socket, falling back to the legacy path when the server has no `/rtc/v1`.
    ///
    /// Returns the negotiated state rather than mutating the caller's: on fallback the early
    /// publisher is closed and dropped, because the legacy path needs a dual-PC publisher, which
    /// differs in both `primary` and `singlePCMode` — immutable on `Transport` — so it cannot be
    /// reused and `configureTransports` builds a fresh pair.
    private func connectSignal(_ url: URL, _ token: String,
                               singlePC: Bool,
                               earlyPublisher: EarlyPublisher?) async throws -> SignalConnection
    {
        do {
            let response = try await signalClient.connect(url,
                                                          token,
                                                          connectOptions: _state.connectOptions,
                                                          reconnectMode: _state.isReconnectingWithMode,
                                                          adaptiveStream: _state.roomOptions.adaptiveStream,
                                                          singlePeerConnection: singlePC,
                                                          publisherOffer: earlyPublisher?.offer,
                                                          connectSpan: connectSpan)
            return SignalConnection(response: response, singlePC: singlePC, earlyPublisher: earlyPublisher)
        } catch let error as LiveKitError where error.type == .serviceNotFound && singlePC {
            log("v1 RTC path not supported, retrying with legacy path", .warning)
            await earlyPublisher?.close()

            let response = try await signalClient.connect(url,
                                                          token,
                                                          connectOptions: _state.connectOptions,
                                                          reconnectMode: _state.isReconnectingWithMode,
                                                          adaptiveStream: _state.roomOptions.adaptiveStream,
                                                          singlePeerConnection: false,
                                                          connectSpan: connectSpan)
            return SignalConnection(response: response, singlePC: false, earlyPublisher: nil)
        }
    }

    // full connect sequence, doesn't update connection state
    func fullConnectSequence(_ url: URL, _ token: String) async throws {
        // Taken before any peer connection or the signal socket exists, so every attempt (initial
        // connect, full reconnect, region failover) times itself from scratch. See
        // `Transport.set(connectionSetupTime:)`.
        let connectStartedAt = ProcessInfo.processInfo.systemUptime
        var singlePC = _state.roomOptions.singlePeerConnection

        // Built before the socket opens so its offer rides along with the JOIN request, removing
        // the offer→answer round trip from the connect path. It is serialized ahead of the
        // handshake rather than overlapped with it — the offer has to be in the JOIN URL.
        //
        // Skipped once the signal client knows this server only speaks v0: the peer connection
        // and its three data channels would be built and immediately discarded on every
        // full-reconnect and region-failover attempt. `quickReconnectSequence` gates the same way.
        let mayBundleOffer = await !signalClient.useV0SignalPath
        var earlyPublisher: EarlyPublisher? = if singlePC, mayBundleOffer {
            try await EarlyPublisher.make(room: self,
                                          rtcConfiguration: makeRTCConfiguration(connectResponse: nil))
        } else {
            nil
        }
        if earlyPublisher != nil { connectSpan?.record("early_pc_created") }

        // Until `configureTransports` adopts it into the stage, the early publisher is not
        // reachable from `cleanUp()`, so every exit before that point closes it here.
        var isAdopted = false

        do {
            let connected = try await connectSignal(url, token,
                                                    singlePC: singlePC,
                                                    earlyPublisher: earlyPublisher)
            let connectResponse = connected.response
            singlePC = connected.singlePC
            earlyPublisher = connected.earlyPublisher

            // Check cancellation after WebSocket connected
            try Task.checkCancellation()

            connectSpan?.record("signal")
            connectSpan?.record("join_recv")

            try await configureTransports(connectResponse: connectResponse,
                                          singlePeerConnection: singlePC,
                                          earlyPublisher: earlyPublisher)
            // Adoption happens only on the `.join` branch inside `configureTransports`. A
            // `.reconnect` response leaves the early publisher unowned, so the catch below must
            // still close it.
            if case .join = connectResponse { isAdopted = true }
            // The JOIN built new transports; their start time covers video published before the
            // primary transport connects.
            if isAdopted { await _state.transport?.publisher.set(connectStartedAt: connectStartedAt) }
            connectSpan?.record("pc_created")
            // Check cancellation after configuring transports
            try Task.checkCancellation()

            // Resume after configuring transports...
            await signalClient.resumeQueues()
            try Task.checkCancellation()

            // Eager publisher negotiation must run after `resumeQueues()` —
            // offers are not queueable, so sending while suspended drops them.
            if case let .join(joinResponse) = connectResponse {
                if earlyPublisher?.offer != nil {
                    // The offer went out with the JOIN request and the server answers it over
                    // the signal channel, so negotiating again here would offer over the top
                    // of it. Matches `sent_publisher_offer` in rust-sdks.
                    _state.mutate { $0.hasPublished = true }
                } else {
                    let isSubscriberPrimary = singlePC ? false : joinResponse.subscriberPrimary
                    if singlePC || !isSubscriberPrimary || joinResponse.fastPublish {
                        try await publisherShouldNegotiate(force: true)
                    }
                }
            }

            // Wait for transport...
            try await primaryTransportConnectedCompleter.wait(timeout: _state.connectOptions.primaryTransportConnectTimeout)
            try Task.checkCancellation()

            if isAdopted { await recordConnectionSetupTime(startedAt: connectStartedAt) }
        } catch {
            // Once adopted, the staged join owns teardown through `cleanUp()`.
            if !isAdopted { await earlyPublisher?.close() }
            throw error
        }

        connectSpan?.record("engine")
        connectSpan?.record("pc_connected")
    }

    /// Hands the time from `startedAt` (`ProcessInfo.systemUptime`) to the primary transport
    /// connecting to the publisher, which lowers the video start bitrate hint for a slow
    /// connection. See `Transport.set(connectionSetupTime:)`.
    private func recordConnectionSetupTime(startedAt: TimeInterval) async {
        let connectionSetupTime = ProcessInfo.processInfo.systemUptime - startedAt
        log("Connection setup took \(Int((connectionSetupTime * 1000).rounded())) ms")
        await _state.transport?.publisher.set(connectionSetupTime: connectionSetupTime)
    }

    // swiftlint:disable:next cyclomatic_complexity function_body_length
    func startReconnect(reason: StartReconnectReason, nextReconnectMode: ReconnectMode? = nil) async throws {
        log("[Connect] Starting, reason: \(reason)")

        guard case .connected = _state.connectionState else {
            log("[Connect] Must be called with connected state", .error)
            throw LiveKitError(.invalidState)
        }

        let url = _state.read { $0.connectedUrl ?? $0.providedUrl }
        guard let url, let token = _state.token else {
            log("[Connect] Url or token is nil", .error)
            throw LiveKitError(.invalidState)
        }

        guard _state.transport != nil else {
            log("[Connect] Transport is nil", .error)
            throw LiveKitError(.invalidState)
        }

        guard _state.isReconnectingWithMode == nil else {
            log("[Connect] Reconnect already in progress...", .warning)
            throw LiveKitError(.invalidState)
        }

        _state.mutate {
            // Mark as Re-connecting internally
            $0.isReconnectingWithMode = .quick
            $0.nextReconnectMode = nextReconnectMode
        }

        // quick connect sequence, does not update connection state
        @Sendable func quickReconnectSequence() async throws {
            log("[Connect] Starting .quick reconnect sequence...")

            let singlePC = await !signalClient.useV0SignalPath
            let connectResponse = try await signalClient.connect(url,
                                                                 token,
                                                                 connectOptions: _state.connectOptions,
                                                                 reconnectMode: _state.isReconnectingWithMode,
                                                                 participantSid: localParticipant.sid,
                                                                 adaptiveStream: _state.roomOptions.adaptiveStream,
                                                                 singlePeerConnection: singlePC)
            try Task.checkCancellation()

            // Update configuration
            try await configureTransports(connectResponse: connectResponse,
                                          singlePeerConnection: singlePC)
            try Task.checkCancellation()

            // Resume after configuring transports...
            await signalClient.resumeQueues()

            log("[Connect] Waiting for subscriber to connect...")
            // Wait for primary transport to connect (if not already)
            do {
                try await primaryTransportConnectedCompleter.wait(timeout: _state.connectOptions.primaryTransportConnectTimeout)
                log("[Connect] Subscriber transport connected")
            } catch {
                log("[Connect] Subscriber transport failed to connect, error: \(error)", .error)
                throw error
            }
            try Task.checkCancellation()

            // send SyncState before offer
            try await sendSyncState()

            await _state.transport?.setSubscriberRestartingIce()

            if let publisher = _state.transport?.publisher, _state.hasPublished {
                // Only if published, wait for publisher to connect...
                log("[Connect] Waiting for publisher to connect...")
                try await publisher.createAndSendOffer(iceRestart: true)
                do {
                    try await publisherTransportConnectedCompleter.wait(timeout: _state.connectOptions.publisherTransportConnectTimeout)
                    log("[Connect] Publisher transport connected")
                } catch {
                    log("[Connect] Publisher transport failed to connect, error: \(error)", .error)
                    throw error
                }
            }

            dataTracks?.handleReconnect(fullReconnect: false)
        }

        // "full" re-connection sequence
        // as a last resort, try to do a clean re-connection and re-publish existing tracks
        @Sendable func fullReconnectSequence() async throws {
            log("[Connect] starting .full reconnect sequence...")

            _state.mutate {
                // Mark as Re-connecting
                $0.connectionState = .reconnecting
            }

            let (providedUrl, connectedUrl, token) = _state.read { ($0.providedUrl, $0.connectedUrl, $0.token) }

            guard let providedUrl, let connectedUrl, let token else {
                log("[Connect] Url or token is nil")
                throw LiveKitError(.invalidState)
            }

            let finalUrl: URL
            await cleanUp(isFullReconnect: true)
            if providedUrl.isCloud {
                guard let regionManager = await regionManager(for: providedUrl) else {
                    throw LiveKitError(.onlyForCloud)
                }

                finalUrl = try await connectWithCloudRegionFailover(regionManager: regionManager,
                                                                    initialUrl: connectedUrl,
                                                                    initialRegion: nil,
                                                                    token: token)
            } else {
                try await fullConnectSequence(connectedUrl, token)
                finalUrl = connectedUrl
            }

            _state.mutate { $0.connectedUrl = finalUrl }

            dataTracks?.handleReconnect(fullReconnect: true)
        }

        do {
            let reconnectTask = Task.retrying(totalAttempts: _state.connectOptions.reconnectAttempts,
                                              retryDelay: { @Sendable attempt in
                                                  let delay = TimeInterval.computeReconnectDelay(forAttempt: attempt,
                                                                                                 baseDelay: self._state.connectOptions.reconnectAttemptDelay,
                                                                                                 maxDelay: self._state.connectOptions.reconnectMaxDelay,
                                                                                                 totalAttempts: self._state.connectOptions.reconnectAttempts,
                                                                                                 addJitter: true)
                                                  self.log("[Connect] Retry cycle waiting for \(String(format: "%.2f", delay)) seconds before attempt \(attempt + 1)")
                                                  return delay
                                              }) { currentAttempt, totalAttempts in
                // Not reconnecting state anymore
                guard let currentMode = self._state.isReconnectingWithMode else {
                    self.log("[Connect] Not in reconnect state anymore, exiting retry cycle.")
                    return
                }

                self.log("[Connect] Starting retry attempt \(currentAttempt)/\(totalAttempts) with mode: \(currentMode)")

                // Try full reconnect for the final attempt
                if totalAttempts == currentAttempt, self._state.nextReconnectMode == nil {
                    self._state.mutate { $0.nextReconnectMode = .full }
                }

                let mode: ReconnectMode = self._state.mutate {
                    let mode: ReconnectMode = ($0.nextReconnectMode == .full || $0.isReconnectingWithMode == .full) ? .full : .quick
                    $0.isReconnectingWithMode = mode
                    $0.nextReconnectMode = nil
                    return mode
                }

                do {
                    if case .quick = mode {
                        try await quickReconnectSequence()
                        self.log("[Connect] Quick reconnect succeeded for attempt \(currentAttempt)")
                    } else if case .full = mode {
                        try await fullReconnectSequence()
                        self.log("[Connect] Full reconnect succeeded for attempt \(currentAttempt)")
                    }
                } catch {
                    self.log("[Connect] Reconnect mode: \(mode) failed with error: \(error)", .error)
                    // Re-throw
                    throw error
                }
            }

            _state.mutate {
                $0.reconnectTask = reconnectTask.cancellable()
            }

            try await reconnectTask.value

            // Re-connect sequence successful
            log("[Connect] Sequence completed")
            _state.mutate {
                $0.connectionState = .connected
                $0.reconnectTask = nil
                $0.isReconnectingWithMode = nil
                $0.nextReconnectMode = nil
            }

            if let providedUrl = _state.providedUrl, providedUrl.isCloud, let regionManager = await regionManager(for: providedUrl) {
                // Clear failed region attempts after a successful reconnect.
                await regionManager.resetAttempts()
            }
        } catch {
            log("[Connect] Sequence failed with error: \(error)")

            // Only clean up if the reconnect task wasn't cancelled — when cancelled,
            // the caller (disconnect() or a new reconnect) handles cleanup separately.
            if !Task.isCancelled {
                await cleanUp(withError: error)
            }
        }
    }
}

// MARK: - Session Migration

extension Room {
    func sendSyncState() async throws {
        guard let transport = _state.transport else {
            log("Transport is nil", .error)
            return
        }

        let (previousAnswer, previousOffer) = await transport.syncStateDescriptions()

        // 1. autosubscribe on, so subscribed tracks = all tracks - unsub tracks,
        //    in this case, we send unsub tracks, so server add all tracks to this
        //    subscribe pc and unsub special tracks from it.
        // 2. autosubscribe off, we send subscribed tracks.

        let autoSubscribe = _state.connectOptions.autoSubscribe
        // Use isDesired (subscription intent) instead of isSubscribed (actual state)
        // to avoid race condition during quick reconnect where tracks aren't attached yet.
        let trackSids = _state.remoteParticipants.values.flatMap { participant in
            participant._state.trackPublications.values
                .compactMap { $0 as? RemoteTrackPublication }
                .filter { $0.isDesired != autoSubscribe }
                .map(\.sid)
        }

        log("trackSids: \(trackSids)")

        let subscription = Livekit_UpdateSubscription.with {
            $0.trackSids = trackSids.map(\.stringValue)
            $0.participantTracks = []
            $0.subscribe = !autoSubscribe
        }

        let publishDataTracks = await dataTracks?.syncStatePublishResponses() ?? []

        try await signalClient.sendSyncState(answer: previousAnswer?.toPBType(offerId: 0),
                                             offer: previousOffer?.toPBType(offerId: 0),
                                             subscription: subscription,
                                             publishTracks: localParticipant.publishedTracksInfo(),
                                             publishDataTracks: publishDataTracks,
                                             dataChannels: publisherDataChannel.infos(),
                                             dataChannelReceiveStates: subscriberDataChannel.receiveStates())
    }
}

// MARK: - Private helpers

extension Room {
    func requirePublisher() throws -> Transport {
        guard let publisher = _state.transport?.publisher else {
            log("Publisher is nil", .error)
            throw LiveKitError(.invalidState, message: "Publisher is nil")
        }

        return publisher
    }
}
