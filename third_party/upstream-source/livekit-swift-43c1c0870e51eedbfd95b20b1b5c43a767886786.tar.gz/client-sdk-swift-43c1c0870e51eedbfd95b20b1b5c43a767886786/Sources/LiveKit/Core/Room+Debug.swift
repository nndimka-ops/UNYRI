/*
 * Copyright 2026 LiveKit
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import Foundation

public enum SimulateScenario: Sendable {
    // Client
    case quickReconnect
    case fullReconnect
    // Server
    case nodeFailure
    case migration
    case serverLeave
    case speakerUpdate(seconds: Int)
    case forceTCP
    case forceTLS
}

public extension Room {
    /// Simulate a scenario for debuggin
    func debug_simulate(scenario: SimulateScenario) async throws {
        if case .quickReconnect = scenario {
            try await startReconnect(reason: .debug)
        } else if case .fullReconnect = scenario {
            try await startReconnect(reason: .debug, nextReconnectMode: .full)
        } else {
            try await signalClient.sendSimulate(scenario: scenario)
        }
    }
}
