// Copyright 2025 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#![doc = include_str!("../README.md")]

mod plugin;
pub mod proto;
mod room;
pub mod rtc_engine;

pub mod webrtc {
    pub use libwebrtc::*;

    #[cfg(not(target_arch = "wasm32"))]
    pub use crate::rtc_engine::lk_runtime::WebRtcRuntimeInitializedError;

    /// Enables zero playout delay for native video receivers created by the shared WebRTC runtime.
    ///
    /// Call this before [`crate::Room::connect`]. Repeated calls are allowed, but enabling the
    /// mode after the default WebRTC runtime is active returns
    /// [`WebRtcRuntimeInitializedError`].
    #[cfg(not(target_arch = "wasm32"))]
    pub fn enable_zero_playout_delay() -> Result<(), WebRtcRuntimeInitializedError> {
        crate::rtc_engine::lk_runtime::LkRuntime::enable_zero_playout_delay()
    }
}

pub use room::*;

/// `use livekit::prelude::*;` to import livekit types
pub mod prelude;

// Platform Audio Device Module (ADM) management
#[cfg(not(target_arch = "wasm32"))]
mod platform_audio;
#[cfg(not(target_arch = "wasm32"))]
pub use platform_audio::*;

pub use plugin::*;

mod utils;
