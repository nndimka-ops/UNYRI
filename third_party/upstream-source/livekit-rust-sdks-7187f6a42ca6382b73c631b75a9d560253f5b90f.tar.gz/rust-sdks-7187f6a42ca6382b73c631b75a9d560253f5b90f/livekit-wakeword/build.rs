// Copyright 2026 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

fn main() {
    println!("cargo::rustc-check-cfg=cfg(use_tract)");
    let target = std::env::var("TARGET").unwrap_or_default();
    if target == "aarch64-pc-windows-msvc" {
        return;
    }
    println!("cargo::rustc-cfg=use_tract");
}
