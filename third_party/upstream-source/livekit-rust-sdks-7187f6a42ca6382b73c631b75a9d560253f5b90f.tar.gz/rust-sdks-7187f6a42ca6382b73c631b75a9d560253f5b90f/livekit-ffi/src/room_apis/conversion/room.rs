// Copyright 2025 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::{proto, server::room::FfiRoom};
use livekit::{
    e2ee::{
        key_provider::{KeyProvider, KeyProviderOptions},
        E2eeOptions, EncryptionType,
    },
    options::{
        AudioEncoding, DegradationPreference, FrameMetadataFeatures, TrackPublishOptions,
        VideoEncoderBackend, VideoEncoding,
    },
    prelude::*,
    webrtc::{
        native::frame_cryptor::{EncryptionState, KeyDerivationAlgorithm},
        prelude::{ContinualGatheringPolicy, IceServer, IceTransportsType, RtcConfiguration},
    },
    RoomDataStreamOptions, RoomInfo,
};
use std::time::Duration;

fn frame_metadata_features_from_proto(features: Vec<i32>) -> FrameMetadataFeatures {
    let mut frame_metadata_features = FrameMetadataFeatures::default();

    for feature in
        features.into_iter().filter_map(|value| proto::FrameMetadataFeature::try_from(value).ok())
    {
        match feature {
            proto::FrameMetadataFeature::FmfUserTimestamp => {
                frame_metadata_features.user_timestamp = true;
            }
            proto::FrameMetadataFeature::FmfFrameId => {
                frame_metadata_features.frame_id = true;
            }
            proto::FrameMetadataFeature::FmfUserData => {
                frame_metadata_features.user_data = true;
            }
        }
    }

    frame_metadata_features
}

fn video_encoder_from_proto(backend: Option<i32>) -> Option<VideoEncoderBackend> {
    match backend.and_then(|value| proto::VideoEncoderBackend::try_from(value).ok())? {
        proto::VideoEncoderBackend::EncoderBackendAuto => Some(VideoEncoderBackend::Auto),
        proto::VideoEncoderBackend::EncoderBackendSoftware => Some(VideoEncoderBackend::Software),
        proto::VideoEncoderBackend::EncoderBackendHardware => Some(VideoEncoderBackend::Hardware),
        proto::VideoEncoderBackend::EncoderBackendNvenc => Some(VideoEncoderBackend::Nvenc),
        proto::VideoEncoderBackend::EncoderBackendVaapi => Some(VideoEncoderBackend::Vaapi),
        proto::VideoEncoderBackend::EncoderBackendVideotoolbox => {
            Some(VideoEncoderBackend::VideoToolbox)
        }
        proto::VideoEncoderBackend::EncoderBackendPreEncoded => {
            Some(VideoEncoderBackend::PreEncoded)
        }
    }
}

fn degradation_preference_from_proto(pref: Option<i32>) -> Option<DegradationPreference> {
    match pref.and_then(|value| proto::DegradationPreference::try_from(value).ok())? {
        proto::DegradationPreference::Balanced => Some(DegradationPreference::Balanced),
        proto::DegradationPreference::MaintainFramerate => {
            Some(DegradationPreference::MaintainFramerate)
        }
        proto::DegradationPreference::MaintainResolution => {
            Some(DegradationPreference::MaintainResolution)
        }
        proto::DegradationPreference::MaintainFramerateAndResolution => {
            Some(DegradationPreference::MaintainFramerateAndResolution)
        }
    }
}

impl From<EncryptionState> for proto::EncryptionState {
    fn from(value: EncryptionState) -> Self {
        match value {
            EncryptionState::New => Self::New,
            EncryptionState::Ok => Self::Ok,
            EncryptionState::EncryptionFailed => Self::EncryptionFailed,
            EncryptionState::DecryptionFailed => Self::DecryptionFailed,
            EncryptionState::MissingKey => Self::MissingKey,
            EncryptionState::KeyRatcheted => Self::KeyRatcheted,
            EncryptionState::InternalError => Self::InternalError,
        }
    }
}

impl From<ConnectionQuality> for proto::ConnectionQuality {
    fn from(value: ConnectionQuality) -> Self {
        match value {
            ConnectionQuality::Excellent => Self::QualityExcellent,
            ConnectionQuality::Good => Self::QualityGood,
            ConnectionQuality::Poor => Self::QualityPoor,
            ConnectionQuality::Lost => Self::QualityLost,
        }
    }
}

impl From<ConnectionState> for proto::ConnectionState {
    fn from(value: ConnectionState) -> Self {
        match value {
            ConnectionState::Connected => Self::ConnConnected,
            ConnectionState::Reconnecting => Self::ConnReconnecting,
            ConnectionState::Disconnected => Self::ConnDisconnected,
        }
    }
}

impl From<proto::EncryptionType> for EncryptionType {
    fn from(value: proto::EncryptionType) -> Self {
        match value {
            proto::EncryptionType::None => Self::None,
            proto::EncryptionType::Gcm => Self::Gcm,
            proto::EncryptionType::Custom => Self::Custom,
        }
    }
}

impl From<EncryptionType> for proto::EncryptionType {
    fn from(value: EncryptionType) -> Self {
        match value {
            EncryptionType::None => Self::None,
            EncryptionType::Gcm => Self::Gcm,
            EncryptionType::Custom => Self::Custom,
        }
    }
}

impl From<DisconnectReason> for proto::DisconnectReason {
    fn from(value: DisconnectReason) -> Self {
        match value {
            DisconnectReason::UnknownReason => Self::UnknownReason,
            DisconnectReason::ClientInitiated => Self::ClientInitiated,
            DisconnectReason::DuplicateIdentity => Self::DuplicateIdentity,
            DisconnectReason::ServerShutdown => Self::ServerShutdown,
            DisconnectReason::ParticipantRemoved => Self::ParticipantRemoved,
            DisconnectReason::RoomDeleted => Self::RoomDeleted,
            DisconnectReason::StateMismatch => Self::StateMismatch,
            DisconnectReason::JoinFailure => Self::JoinFailure,
            DisconnectReason::Migration => Self::Migration,
            DisconnectReason::SignalClose => Self::SignalClose,
            DisconnectReason::RoomClosed => Self::RoomClosed,
            DisconnectReason::UserUnavailable => Self::UserUnavailable,
            DisconnectReason::UserRejected => Self::UserRejected,
            DisconnectReason::SipTrunkFailure => Self::SipTrunkFailure,
            DisconnectReason::ConnectionTimeout => Self::ConnectionTimeout,
            DisconnectReason::MediaFailure => Self::MediaFailure,
            DisconnectReason::AgentError => Self::AgentError,
        }
    }
}

impl From<proto::DisconnectReason> for DisconnectReason {
    fn from(value: proto::DisconnectReason) -> Self {
        match value {
            proto::DisconnectReason::UnknownReason => Self::UnknownReason,
            proto::DisconnectReason::ClientInitiated => Self::ClientInitiated,
            proto::DisconnectReason::DuplicateIdentity => Self::DuplicateIdentity,
            proto::DisconnectReason::ServerShutdown => Self::ServerShutdown,
            proto::DisconnectReason::ParticipantRemoved => Self::ParticipantRemoved,
            proto::DisconnectReason::RoomDeleted => Self::RoomDeleted,
            proto::DisconnectReason::StateMismatch => Self::StateMismatch,
            proto::DisconnectReason::JoinFailure => Self::JoinFailure,
            proto::DisconnectReason::Migration => Self::Migration,
            proto::DisconnectReason::SignalClose => Self::SignalClose,
            proto::DisconnectReason::RoomClosed => Self::RoomClosed,
            proto::DisconnectReason::UserUnavailable => Self::UserUnavailable,
            proto::DisconnectReason::UserRejected => Self::UserRejected,
            proto::DisconnectReason::SipTrunkFailure => Self::SipTrunkFailure,
            proto::DisconnectReason::ConnectionTimeout => Self::ConnectionTimeout,
            proto::DisconnectReason::MediaFailure => Self::MediaFailure,
            proto::DisconnectReason::AgentError => Self::AgentError,
        }
    }
}

impl From<proto::KeyProviderOptions> for KeyProviderOptions {
    fn from(value: proto::KeyProviderOptions) -> Self {
        let key_derivation_algorithm = value.key_derivation_function().into();
        Self {
            ratchet_window_size: value.ratchet_window_size,
            ratchet_salt: value.ratchet_salt,
            failure_tolerance: value.failure_tolerance,
            key_ring_size: value.key_ring_size,
            key_derivation_algorithm,
        }
    }
}

impl From<proto::KeyDerivationFunction> for KeyDerivationAlgorithm {
    fn from(value: proto::KeyDerivationFunction) -> Self {
        match value {
            proto::KeyDerivationFunction::Pbkdf2 => KeyDerivationAlgorithm::PBKDF2,
            proto::KeyDerivationFunction::Hkdf => KeyDerivationAlgorithm::HKDF,
        }
    }
}

impl From<proto::IceTransportType> for IceTransportsType {
    fn from(value: proto::IceTransportType) -> Self {
        match value {
            proto::IceTransportType::TransportRelay => Self::Relay,
            proto::IceTransportType::TransportNohost => Self::NoHost,
            proto::IceTransportType::TransportAll => Self::All,
        }
    }
}

impl From<proto::ContinualGatheringPolicy> for ContinualGatheringPolicy {
    fn from(value: proto::ContinualGatheringPolicy) -> Self {
        match value {
            proto::ContinualGatheringPolicy::GatherOnce => Self::GatherOnce,
            proto::ContinualGatheringPolicy::GatherContinually => Self::GatherContinually,
        }
    }
}

impl From<proto::IceServer> for IceServer {
    fn from(value: proto::IceServer) -> Self {
        Self {
            urls: value.urls,
            username: value.username.unwrap_or_default(),
            password: value.password.unwrap_or_default(),
        }
    }
}

impl From<proto::RtcConfig> for RtcConfiguration {
    fn from(value: proto::RtcConfig) -> Self {
        // Start from RoomOptions defaults; RtcConfiguration is #[non_exhaustive]
        // so it must be built from Default rather than a struct literal.
        let mut config = RoomOptions::default().rtc_config;

        config.ice_transport_type =
            value.ice_transport_type.map_or(config.ice_transport_type, |x| {
                proto::IceTransportType::try_from(x).unwrap().into()
            });
        config.continual_gathering_policy =
            value.continual_gathering_policy.map_or(config.continual_gathering_policy, |x| {
                proto::ContinualGatheringPolicy::try_from(x).unwrap().into()
            });
        config.ice_servers = value.ice_servers.into_iter().map(Into::into).collect();
        config
    }
}

impl From<proto::RoomOptions> for RoomOptions {
    fn from(value: proto::RoomOptions) -> Self {
        let e2ee = value.e2ee.and_then(|opts| {
            let encryption_type = opts.encryption_type();
            let provider_opts = opts.key_provider_options;

            Some(E2eeOptions {
                encryption_type: encryption_type.into(),
                key_provider: if provider_opts.shared_key.is_some() {
                    let shared_key = provider_opts.shared_key.clone().unwrap();
                    KeyProvider::with_shared_key(provider_opts.into(), shared_key)
                } else {
                    KeyProvider::new(provider_opts.into())
                },
            })
        });

        let encryption = value.encryption.and_then(|opts| {
            let encryption_type = opts.encryption_type();
            let provider_opts = opts.key_provider_options;

            Some(E2eeOptions {
                encryption_type: encryption_type.into(),
                key_provider: if provider_opts.shared_key.is_some() {
                    let shared_key = provider_opts.shared_key.clone().unwrap();
                    KeyProvider::with_shared_key(provider_opts.into(), shared_key)
                } else {
                    KeyProvider::new(provider_opts.into())
                },
            })
        });

        let rtc_config =
            value.rtc_config.map(Into::into).unwrap_or(RoomOptions::default().rtc_config);

        let mut options = RoomOptions::default();
        options.adaptive_stream = value.adaptive_stream.unwrap_or(options.adaptive_stream);
        options.auto_subscribe = value.auto_subscribe.unwrap_or(options.auto_subscribe);
        options.dynacast = value.dynacast.unwrap_or(options.dynacast);
        options.rtc_config = rtc_config;
        options.join_retries = value.join_retries.unwrap_or(options.join_retries);
        options.e2ee = e2ee;
        options.encryption = encryption;
        options.single_peer_connection =
            value.single_peer_connection.unwrap_or(options.single_peer_connection);
        options.connect_timeout =
            value.connect_timeout_ms.map(Duration::from_millis).unwrap_or(options.connect_timeout);
        options.sdk_options.other_sdks = value.other_sdks;
        if let Some(data_stream) = value.data_stream {
            let mut data_stream_options = RoomDataStreamOptions::default();
            if let Some(max_payload_byte_length) = data_stream.max_payload_byte_length {
                data_stream_options = data_stream_options
                    .with_max_payload_byte_length(max_payload_byte_length as usize);
            }
            if data_stream.use_legacy_client_implementation.unwrap_or(false) {
                data_stream_options = data_stream_options.with_legacy_client_implementation(true);
            }
            options.data_stream = data_stream_options;
        }
        options
    }
}

impl From<proto::DataPacketKind> for DataPacketKind {
    fn from(value: proto::DataPacketKind) -> Self {
        match value {
            proto::DataPacketKind::KindReliable => Self::Reliable,
            proto::DataPacketKind::KindLossy => Self::Lossy,
        }
    }
}

impl From<DataPacketKind> for proto::DataPacketKind {
    fn from(value: DataPacketKind) -> Self {
        match value {
            DataPacketKind::Reliable => Self::KindReliable,
            DataPacketKind::Lossy => Self::KindLossy,
        }
    }
}

impl From<proto::TrackPublishOptions> for TrackPublishOptions {
    fn from(opts: proto::TrackPublishOptions) -> Self {
        let default_publish_options = TrackPublishOptions::default();
        let video_codec = opts.video_codec.map(|x| proto::VideoCodec::try_from(x).ok()).flatten();
        let source = opts.source.map(|x| proto::TrackSource::try_from(x).ok()).flatten();

        Self {
            video_codec: video_codec.map(Into::into).unwrap_or(default_publish_options.video_codec),
            source: source.map(Into::into).unwrap_or(default_publish_options.source),
            video_encoding: opts
                .video_encoding
                .map(Into::into)
                .or(default_publish_options.video_encoding),
            audio_encoding: opts
                .audio_encoding
                .map(Into::into)
                .or(default_publish_options.audio_encoding),
            dtx: opts.dtx.unwrap_or(default_publish_options.dtx),
            red: opts.red.unwrap_or(default_publish_options.red),
            simulcast: opts.simulcast.unwrap_or(default_publish_options.simulcast),
            stream: opts.stream.unwrap_or(default_publish_options.stream),
            simulcast_layers: default_publish_options.simulcast_layers,
            preconnect_buffer: opts
                .preconnect_buffer
                .unwrap_or(default_publish_options.preconnect_buffer),
            frame_metadata_features: frame_metadata_features_from_proto(
                opts.frame_metadata_features,
            ),
            video_encoder: video_encoder_from_proto(opts.video_encoder)
                .unwrap_or(default_publish_options.video_encoder),
            scalability_mode: opts.scalability_mode,
            degradation_preference: degradation_preference_from_proto(opts.degradation_preference),
        }
    }
}

impl From<proto::VideoEncoding> for VideoEncoding {
    fn from(opts: proto::VideoEncoding) -> Self {
        Self { max_bitrate: opts.max_bitrate, max_framerate: opts.max_framerate }
    }
}

impl From<proto::AudioEncoding> for AudioEncoding {
    fn from(opts: proto::AudioEncoding) -> Self {
        Self { max_bitrate: opts.max_bitrate }
    }
}

#[cfg(test)]
mod tests {
    use livekit::{
        options::{TrackPublishOptions, VideoEncoderBackend},
        prelude::RoomOptions,
    };

    use super::{frame_metadata_features_from_proto, video_encoder_from_proto};
    use crate::proto;

    #[test]
    fn frame_metadata_features_default_to_empty() {
        let features = frame_metadata_features_from_proto(Vec::new());

        assert!(!features.user_timestamp);
        assert!(!features.frame_id);
    }

    #[test]
    fn frame_metadata_features_enable_known_flags() {
        let features = frame_metadata_features_from_proto(vec![
            proto::FrameMetadataFeature::FmfUserTimestamp.into(),
            proto::FrameMetadataFeature::FmfFrameId.into(),
        ]);

        assert!(features.user_timestamp);
        assert!(features.frame_id);
    }

    #[test]
    fn other_sdks_round_trips_from_room_options() {
        let options = RoomOptions::from(proto::RoomOptions {
            other_sdks: Some("ros_portal:1.2.3".to_string()),
            ..Default::default()
        });

        assert_eq!(options.sdk_options.other_sdks.as_deref(), Some("ros_portal:1.2.3"));
    }

    #[test]
    fn other_sdks_defaults_to_none() {
        let options = RoomOptions::from(proto::RoomOptions::default());

        assert!(options.sdk_options.other_sdks.is_none());
    }

    #[test]
    fn video_encoder_defaults_to_auto() {
        let options = TrackPublishOptions::from(proto::TrackPublishOptions::default());

        assert_eq!(options.video_encoder, VideoEncoderBackend::Auto);
    }

    #[test]
    fn video_encoder_maps_known_values() {
        let cases = [
            (proto::VideoEncoderBackend::EncoderBackendAuto, VideoEncoderBackend::Auto),
            (proto::VideoEncoderBackend::EncoderBackendSoftware, VideoEncoderBackend::Software),
            (proto::VideoEncoderBackend::EncoderBackendHardware, VideoEncoderBackend::Hardware),
            (proto::VideoEncoderBackend::EncoderBackendNvenc, VideoEncoderBackend::Nvenc),
            (proto::VideoEncoderBackend::EncoderBackendVaapi, VideoEncoderBackend::Vaapi),
            (
                proto::VideoEncoderBackend::EncoderBackendVideotoolbox,
                VideoEncoderBackend::VideoToolbox,
            ),
            (proto::VideoEncoderBackend::EncoderBackendPreEncoded, VideoEncoderBackend::PreEncoded),
        ];

        for (proto_backend, expected) in cases {
            assert_eq!(video_encoder_from_proto(Some(proto_backend as i32)), Some(expected));
        }
    }
}

impl From<&FfiRoom> for proto::RoomInfo {
    fn from(value: &FfiRoom) -> Self {
        let room = &value.inner.room;
        proto::RoomInfo {
            sid: room.maybe_sid().map(|x| x.to_string()),
            name: room.name(),
            metadata: room.metadata(),
            lossy_dc_buffered_amount_low_threshold: room
                .data_channel_options(DataPacketKind::Lossy)
                .buffered_amount_low_threshold,
            reliable_dc_buffered_amount_low_threshold: room
                .data_channel_options(DataPacketKind::Reliable)
                .buffered_amount_low_threshold,
            empty_timeout: room.empty_timeout(),
            departure_timeout: room.departure_timeout(),
            max_participants: room.max_participants(),
            creation_time: room.creation_time(),
            num_participants: room.num_participants(),
            num_publishers: room.num_publishers(),
            active_recording: room.active_recording(),
        }
    }
}

impl From<RoomInfo> for proto::RoomInfo {
    fn from(room: RoomInfo) -> Self {
        proto::RoomInfo {
            sid: room.sid.map(|x| x.to_string()),
            name: room.name,
            metadata: room.metadata,
            lossy_dc_buffered_amount_low_threshold: room
                .lossy_dc_options
                .buffered_amount_low_threshold,
            reliable_dc_buffered_amount_low_threshold: room
                .reliable_dc_options
                .buffered_amount_low_threshold,
            empty_timeout: room.empty_timeout,
            departure_timeout: room.departure_timeout,
            max_participants: room.max_participants,
            creation_time: room.creation_time,
            num_participants: room.num_participants,
            num_publishers: room.num_publishers,
            active_recording: room.active_recording,
        }
    }
}

impl From<proto::ChatMessage> for livekit::ChatMessage {
    fn from(proto_msg: proto::ChatMessage) -> Self {
        livekit::ChatMessage {
            id: proto_msg.id,
            message: proto_msg.message,
            timestamp: proto_msg.timestamp,
            edit_timestamp: proto_msg.edit_timestamp,
            deleted: proto_msg.deleted,
            generated: proto_msg.generated,
        }
    }
}

impl From<livekit::ChatMessage> for proto::ChatMessage {
    fn from(msg: livekit::ChatMessage) -> Self {
        proto::ChatMessage {
            id: msg.id,
            message: msg.message,
            timestamp: msg.timestamp,
            edit_timestamp: msg.edit_timestamp,
            deleted: msg.deleted.into(),
            generated: msg.generated.into(),
        }
    }
}

impl From<livekit_protocol::data_stream::Header> for proto::data_stream::Header {
    fn from(msg: livekit_protocol::data_stream::Header) -> Self {
        let content_header = match msg.content_header {
            Some(livekit_protocol::data_stream::header::ContentHeader::TextHeader(text_header)) => {
                Some(proto::data_stream::header::ContentHeader::TextHeader(
                    proto::data_stream::TextHeader {
                        operation_type: text_header.operation_type,
                        version: Some(text_header.version),
                        reply_to_stream_id: Some(text_header.reply_to_stream_id),
                        attached_stream_ids: text_header.attached_stream_ids,
                        generated: Some(text_header.generated),
                    },
                ))
            }
            Some(livekit_protocol::data_stream::header::ContentHeader::ByteHeader(byte_header)) => {
                Some(proto::data_stream::header::ContentHeader::ByteHeader(
                    proto::data_stream::ByteHeader { name: byte_header.name },
                ))
            }
            None => None,
        };

        proto::data_stream::Header {
            stream_id: msg.stream_id,
            timestamp: msg.timestamp,
            topic: msg.topic,
            mime_type: msg.mime_type,
            total_length: msg.total_length,
            attributes: msg.attributes,
            content_header,
        }
    }
}

impl From<proto::data_stream::Header> for livekit_protocol::data_stream::Header {
    fn from(msg: proto::data_stream::Header) -> Self {
        let content_header = match msg.content_header {
            Some(proto::data_stream::header::ContentHeader::TextHeader(text_header)) => {
                Some(livekit_protocol::data_stream::header::ContentHeader::TextHeader(
                    livekit_protocol::data_stream::TextHeader {
                        operation_type: text_header.operation_type,
                        version: text_header.version.unwrap_or_default(),
                        reply_to_stream_id: text_header.reply_to_stream_id.unwrap_or_default(),
                        attached_stream_ids: text_header.attached_stream_ids,
                        generated: text_header.generated.unwrap_or(false),
                    },
                ))
            }
            Some(proto::data_stream::header::ContentHeader::ByteHeader(byte_header)) => {
                Some(livekit_protocol::data_stream::header::ContentHeader::ByteHeader(
                    livekit_protocol::data_stream::ByteHeader { name: byte_header.name },
                ))
            }
            None => None,
        };

        livekit_protocol::data_stream::Header {
            stream_id: msg.stream_id,
            timestamp: msg.timestamp,
            topic: msg.topic,
            mime_type: msg.mime_type,
            total_length: msg.total_length,
            attributes: msg.attributes,
            content_header,
            encryption_type: 0,
            // Data streams v2 fields
            inline_content: None,
            compression: livekit_protocol::data_stream::CompressionType::None as i32,
        }
    }
}

impl From<livekit_protocol::data_stream::Chunk> for proto::data_stream::Chunk {
    fn from(msg: livekit_protocol::data_stream::Chunk) -> Self {
        proto::data_stream::Chunk {
            stream_id: msg.stream_id,
            content: msg.content,
            chunk_index: msg.chunk_index,
            version: Some(msg.version),
            iv: msg.iv,
        }
    }
}

impl From<proto::data_stream::Chunk> for livekit_protocol::data_stream::Chunk {
    fn from(msg: proto::data_stream::Chunk) -> Self {
        livekit_protocol::data_stream::Chunk {
            stream_id: msg.stream_id,
            content: msg.content,
            chunk_index: msg.chunk_index,
            version: msg.version.unwrap_or(0),
            iv: msg.iv,
        }
    }
}

impl From<livekit_protocol::data_stream::Trailer> for proto::data_stream::Trailer {
    fn from(msg: livekit_protocol::data_stream::Trailer) -> Self {
        Self { stream_id: msg.stream_id, reason: msg.reason, attributes: msg.attributes }
    }
}

impl From<proto::data_stream::Trailer> for livekit_protocol::data_stream::Trailer {
    fn from(msg: proto::data_stream::Trailer) -> Self {
        Self { stream_id: msg.stream_id, reason: msg.reason, attributes: msg.attributes }
    }
}
