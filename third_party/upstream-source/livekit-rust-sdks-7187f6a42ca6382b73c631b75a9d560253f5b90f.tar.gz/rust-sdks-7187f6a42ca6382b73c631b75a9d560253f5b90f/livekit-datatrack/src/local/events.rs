// Copyright 2025 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::{
    api::{DataTrackInfo, DataTrackOptions, LocalDataTrack, PublishError},
    packet::Handle,
    schema::{DataTrackFrameEncoding, DataTrackSchemaId},
};
use bytes::Bytes;
use from_variants::FromVariants;
use std::sync::Arc;
use tokio::sync::oneshot;

/// An external event handled by [`Manager`](super::manager::Manager).
#[derive(Debug, FromVariants)]
pub enum InputEvent {
    PublishRequest(PublishRequest),
    PublishCancelled(PublishCancelled),
    QueryPublished(QueryPublished),
    UnpublishRequest(UnpublishRequest),
    SfuPublishResponse(SfuPublishResponse),
    SfuUnpublishResponse(SfuUnpublishResponse),
    /// Republish all tracks.
    ///
    /// This must be sent after a full reconnect in order for existing publications
    /// to be recognized by the SFU. Each republished track will be assigned a new SID.
    ///
    RepublishTracks,
    /// Shutdown the manager and all associated tracks.
    Shutdown,
}

/// An event produced by [`Manager`](super::manager::Manager) requiring external action.
#[derive(Debug, FromVariants)]
pub enum OutputEvent {
    SfuPublishRequest(SfuPublishRequest),
    SfuUnpublishRequest(SfuUnpublishRequest),
    /// Serialized packets are ready to be sent over the transport.
    PacketsAvailable(Vec<Bytes>),
}

// MARK: - Input events

/// Client requested to publish a track.
///
/// Send using [`ManagerInput::publish_track`] and await the result.
///
/// [`ManagerInput::publish_track`]: super::manager::ManagerInput::publish_track
///
#[derive(Debug)]
pub struct PublishRequest {
    /// Publish options.
    pub(super) options: DataTrackOptions,
    /// Async completion channel.
    pub(super) result_tx: oneshot::Sender<Result<LocalDataTrack, PublishError>>,
}

/// Client request to publish a track has been cancelled (internal).
#[derive(Debug)]
pub struct PublishCancelled {
    /// Publisher handle of the pending publication.
    pub(super) handle: Handle,
}

/// Client request to unpublish a track (internal).
#[derive(Debug)]
pub struct UnpublishRequest {
    /// Publisher handle of the track to unpublish.
    pub(super) handle: Handle,
}

/// Get information about all currently published tracks.
///
/// Send using [`ManagerInput::query_tracks`] and await the result. This is used
/// to support sync state.
///
/// [`ManagerInput::query_tracks`]: super::manager::ManagerInput::query_tracks
///
#[derive(Debug)]
pub struct QueryPublished {
    pub(super) result_tx: oneshot::Sender<Vec<Arc<DataTrackInfo>>>,
}

/// SFU responded to a request to publish a data track.
///
/// Protocol equivalent: [`livekit_protocol::PublishDataTrackResponse`].
///
#[derive(Debug)]
pub struct SfuPublishResponse {
    /// Publisher handle of the track.
    pub handle: Handle,
    /// Outcome of the publish request.
    pub result: Result<DataTrackInfo, PublishError>,
}

/// SFU notification that a track has been unpublished.
///
/// Protocol equivalent: [`livekit_protocol::UnpublishDataTrackResponse`].
///
#[derive(Debug)]
pub struct SfuUnpublishResponse {
    /// Publisher handle of the track that was unpublished.
    pub handle: Handle,
}

// MARK: - Output events

/// Request sent to the SFU to publish a track.
///
/// Protocol equivalent: [`livekit_protocol::PublishDataTrackRequest`].
///
#[derive(Debug)]
pub struct SfuPublishRequest {
    pub handle: Handle,
    pub name: String,
    pub uses_e2ee: bool,
    pub schema: Option<DataTrackSchemaId>,
    pub frame_encoding: Option<DataTrackFrameEncoding>,
}

/// Request sent to the SFU to unpublish a track.
///
/// Protocol equivalent: [`livekit_protocol::UnpublishDataTrackRequest`].
///
#[derive(Debug)]
pub struct SfuUnpublishRequest {
    /// Publisher handle of the track to unpublish.
    pub handle: Handle,
}
