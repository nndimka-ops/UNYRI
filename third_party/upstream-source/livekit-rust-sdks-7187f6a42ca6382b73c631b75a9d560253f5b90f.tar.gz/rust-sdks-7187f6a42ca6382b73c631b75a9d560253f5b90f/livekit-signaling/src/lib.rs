// Copyright 2025 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#![doc = include_str!("../README.md")]

use std::{
    borrow::Cow,
    fmt::Debug,
    io::Write,
    sync::{
        atomic::{AtomicU32, Ordering},
        Arc,
    },
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use base64::{engine::general_purpose::URL_SAFE as BASE64_URL_SAFE, Engine};
use flate2::{write::GzEncoder, Compression};
use http::StatusCode;
use livekit_protocol as proto;
use parking_lot::Mutex;
use prost::Message;
use thiserror::Error;
use tokio::sync::{mpsc, Mutex as AsyncMutex, RwLock as AsyncRwLock};
use tokio::{
    task::JoinHandle,
    time::{interval, sleep, Instant},
};

use crate::signal_stream::SignalStream;
use livekit_net::HttpClientExt;

mod region_url_provider;
mod signal_stream;

// Shared mock WsClient/HttpClient for the unit tests below. Gated on the signal client alone,
// since the tests that use it do not need access-token.
#[cfg(test)]
mod test_transport;

pub use region_url_provider::RegionUrlProvider;

pub type SignalEmitter = mpsc::UnboundedSender<SignalEvent>;
pub type SignalEvents = mpsc::UnboundedReceiver<SignalEvent>;
pub type SignalResult<T> = Result<T, SignalError>;

pub const JOIN_RESPONSE_TIMEOUT: Duration = Duration::from_secs(5);
pub const SIGNAL_CONNECT_TIMEOUT: Duration = Duration::from_secs(5);
const REGION_FETCH_TIMEOUT: Duration = Duration::from_secs(3);
const VALIDATE_TIMEOUT: Duration = Duration::from_secs(3);
pub const PROTOCOL_VERSION: u32 = 17;

/// Capabilities the Rust SDK advertises to the SFU at connect time.
///
/// `CapCompressionDeflateRaw` is always advertised because the SDK's deflate-raw codec
/// (flate2/miniz_oxide) is pure-Rust and compiled in unconditionally.
const CLIENT_CAPABILITIES: &[proto::client_info::Capability] = &[
    proto::client_info::Capability::CapPacketTrailer,
    proto::client_info::Capability::CapCompressionDeflateRaw,
];

pub use livekit_common::{
    CLIENT_PROTOCOL_DATA_STREAM_RPC, CLIENT_PROTOCOL_DATA_STREAM_V2, CLIENT_PROTOCOL_DEFAULT,
};

/// The client protocol which is sent to other clients and indicates the set of apis that other
/// clients should assume this client supports.
const CLIENT_PROTOCOL_VERSION: i32 = CLIENT_PROTOCOL_DATA_STREAM_V2;

/// The client protocol advertised to other clients, honoring the legacy data streams opt-out.
fn advertised_client_protocol(options: &SignalOptions) -> i32 {
    if options.use_legacy_data_streams {
        CLIENT_PROTOCOL_DATA_STREAM_RPC
    } else {
        CLIENT_PROTOCOL_VERSION
    }
}

#[derive(Error, Debug)]
#[non_exhaustive]
pub enum SignalError {
    #[error("failed to parse the url: {0}")]
    UrlParse(String),
    #[error("access token has invalid characters")]
    TokenFormat,
    #[error("client error: {0} - {1}")]
    Client(StatusCode, String),
    #[error("server error: {0} - {1}")]
    Server(StatusCode, String),
    /// HTTP status from a WebSocket upgrade, kept separate from the authoritative
    /// `rtc/validate` result in [`Client`](Self::Client)/[`Server`](Self::Server).
    /// Retryable: the engine escalates a handshake status to a full reconnect,
    /// whereas `Client(401|403)` is a terminal auth failure.
    #[error("handshake error: {status}")]
    Handshake { status: StatusCode },
    #[error("failed to decode messages from server: {0}")]
    ProtoParse(#[from] prost::DecodeError),
    #[error("{0}")]
    Timeout(String),
    #[error("failed to send message to the server")]
    SendError,
    #[error("transport connection error: {0}")]
    Connection(String),
    #[error("transport closed")]
    Closed,
    /// The lifecycle does not accept the requested step from its current state, for example a
    /// resume while a close is still in flight. The crate-private `SignalState` transition
    /// table lists what each state accepts.
    #[error("cannot {0}")]
    InvalidState(String),
    /// No network transport is registered. On foreign/host builds the host must
    /// call `livekit_net::set_ws_client` / `set_http_client` before connecting.
    /// This is a permanent configuration error, not a transient failure — callers
    /// must not retry.
    #[error("no network transport registered")]
    TransportNotConfigured,
    /// Failed to retrieve region information from LiveKit Cloud.
    ///
    /// This error occurs when the SDK cannot fetch the `/settings/regions` endpoint
    /// from LiveKit Cloud. The error message includes the full error chain to help
    /// diagnose the root cause.
    ///
    /// # Common Causes
    ///
    /// - **Missing CA certificates**: When deploying in containers using slim base images
    ///   (e.g., `node:*-slim`, `debian:*-slim`, Alpine), the system CA certificate store
    ///   may be empty. The error will include "invalid peer certificate: UnknownIssuer".
    ///
    ///   **Fix**: Install the `ca-certificates` package in your Dockerfile:
    ///   ```dockerfile
    ///   RUN apt-get update && apt-get install -y ca-certificates
    ///   ```
    ///
    ///   **Alternative**: Use the `rustls-tls-webpki-roots` feature instead of
    ///   `rustls-tls-native-roots` to bundle Mozilla's root certificates.
    ///
    /// - **Network connectivity issues**: The container cannot reach LiveKit Cloud endpoints.
    ///
    /// - **Invalid or expired access token**: The token used for authentication is not valid.
    #[error("failed to retrieve region info: {0}")]
    RegionError(String),
    #[error("server sent leave during reconnect: reason={reason:?}, action={action:?}")]
    LeaveRequest { reason: proto::DisconnectReason, action: proto::leave_request::Action },
}

#[derive(Debug, Clone)]
#[non_exhaustive]
pub struct SignalSdkOptions {
    pub sdk: String,
    pub sdk_version: Option<String>,
    /// Comma separated list of additional LiveKit SDKs layered on top of this one, with
    /// versions, e.g. `"components-js:1.2.3,track-processors-js:1.2.3"`. Sent to the server
    /// as `ClientInfo.other_sdks`. `None` when there are none — optional so callers that
    /// predate the field keep working unchanged.
    #[doc(hidden)]
    pub other_sdks: Option<String>,
}

impl Default for SignalSdkOptions {
    fn default() -> Self {
        Self { sdk: "rust".to_string(), sdk_version: None, other_sdks: None }
    }
}

#[derive(Debug, Clone)]
#[non_exhaustive]
pub struct SignalOptions {
    pub auto_subscribe: bool,
    pub adaptive_stream: bool,
    pub sdk_options: SignalSdkOptions,
    /// Enable single peer connection mode
    pub single_peer_connection: bool,
    /// Timeout for each individual signal connection attempt
    pub connect_timeout: Duration,
    /// Advertise only legacy data stream support: caps ClientInfo.client_protocol at
    /// [`CLIENT_PROTOCOL_DATA_STREAM_RPC`] instead of [`CLIENT_PROTOCOL_DATA_STREAM_V2`].
    #[doc(hidden)]
    pub use_legacy_data_streams: bool,
}

impl Default for SignalOptions {
    fn default() -> Self {
        Self {
            auto_subscribe: true,
            adaptive_stream: false,
            sdk_options: SignalSdkOptions::default(),
            single_peer_connection: false,
            connect_timeout: SIGNAL_CONNECT_TIMEOUT,
            use_legacy_data_streams: false,
        }
    }
}

pub enum SignalEvent {
    /// Received a message from the server
    Message(Box<proto::signal_response::Message>),

    /// Signal connection closed, SignalClient::restart() can be called to reconnect
    Close(Cow<'static, str>),
}

/// Lifecycle of the signal connection. The state owns the transport, so "which state" and "is
/// there a socket" cannot disagree.
///
/// - `ReconnectComplete` keeps the client `Reconnecting` until the engine sends `Reconnected`,
///   so session-scoped sends stay held until the media path is confirmed.
/// - A stale transport cannot report in: `SignalClient::restart` closes and awaits the previous
///   transport's task before it starts the next attempt.
/// - `ReconnectFailed` always lands in `Offline`. Whether the failure is terminal is the
///   engine's call, made from the error `restart` returns.
#[derive(Debug, Default)]
enum SignalState {
    /// The initial connect is in flight. The constructor drives this state: no client exists
    /// to send or close on until it completes.
    #[default]
    Connecting,
    /// Transport up and the session confirmed. Sends go straight through.
    Connected(SignalStream),
    /// Resume in flight (`None`), or transport back and engine not yet confirmed (`Some`).
    /// Session-scoped sends queue throughout.
    Reconnecting(Option<SignalStream>),
    /// The transport was lost without a close being asked for. No attempt is in flight, and
    /// the session is still resumable.
    Offline,
    /// A close was asked for and the transport is shutting down.
    Disconnecting,
    /// Closed on request. Still resumable.
    Closed,
}

/// Inputs that move a [`SignalState`].
#[derive(Debug)]
enum SignalInput {
    /// The transport is up and the server answered with a `JoinResponse`.
    ConnectComplete(SignalStream),
    /// The initial connect failed. There is no session to fall back on, so this is terminal.
    ConnectFailed,
    /// Start resuming the session on a new transport.
    Reconnect,
    /// The resume's transport is up and the server answered with a `ReconnectResponse`.
    ReconnectComplete(SignalStream),
    ReconnectFailed,
    /// The engine confirms the resume is complete, which releases held session requests.
    Reconnected,
    /// The transport died on its own: remote close or keepalive lapse.
    TransportFailed,
    Close,
    /// The close handshake settled.
    CloseComplete,
}

impl SignalState {
    /// The transition table.
    /// `Ok`: the transport the old state owned and the new one does not - close it.
    /// `Err`: refused, logged, nothing moved.
    fn transition(&mut self, input: SignalInput) -> Result<Option<SignalStream>, SignalInput> {
        use SignalInput as In;
        use SignalState::*;
        let (next_state, released_stream) = match (std::mem::take(self), input) {
            (Connecting, In::ConnectComplete(stream)) => (Connected(stream), None),
            (Connecting, In::ConnectFailed) => (Closed, None),
            (Connected(stream), In::Reconnect) => (Reconnecting(None), Some(stream)),
            (Offline | Closed, In::Reconnect) => (Reconnecting(None), None),
            (Reconnecting(None), In::ReconnectComplete(stream)) => {
                (Reconnecting(Some(stream)), None)
            }
            (Reconnecting(stream), In::ReconnectFailed) => (Offline, stream),
            (Reconnecting(Some(stream)), In::Reconnected) => (Connected(stream), None),
            (Connected(stream) | Reconnecting(Some(stream)), In::TransportFailed) => {
                (Offline, Some(stream))
            }
            (Connected(stream) | Reconnecting(Some(stream)), In::Close) => {
                (Disconnecting, Some(stream))
            }
            (Reconnecting(None) | Offline, In::Close) => (Disconnecting, None),
            (Disconnecting, In::CloseComplete) => (Closed, None),
            (state, input) => {
                log::debug!("ignoring signal lifecycle input {input:?} in state {state:?}");
                *self = state;
                return Err(input);
            }
        };
        *self = next_state;
        Ok(released_stream)
    }

    fn stream(&self) -> Option<&SignalStream> {
        match self {
            Self::Connected(stream) | Self::Reconnecting(Some(stream)) => Some(stream),
            Self::Connecting
            | Self::Reconnecting(None)
            | Self::Offline
            | Self::Disconnecting
            | Self::Closed => None,
        }
    }
}

struct SignalInner {
    // The write lock is held across reconnects to avoid transportless gaps
    state: AsyncRwLock<SignalState>,
    token: Mutex<String>, // Token can be refreshed
    /// Session-scoped signals held while no confirmed transport can carry them. Always taken
    /// under `state`, so the lock order is fixed, and held across a drain so a concurrent
    /// sender cannot slip a newer signal between two held ones.
    queue: AsyncMutex<Vec<proto::signal_request::Message>>,
    url: String,
    options: SignalOptions,
    join_response: proto::JoinResponse,
    request_id: AtomicU32,
    /// Tracks whether single PC mode is active (v1 path succeeded)
    single_pc_mode_active: bool,
}

pub struct SignalClient {
    inner: Arc<SignalInner>,
    emitter: SignalEmitter,
    handle: Mutex<Option<JoinHandle<()>>>,
}

impl Debug for SignalClient {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SignalClient")
            .field("url", &self.url())
            .field("join_response", &self.join_response())
            .field("options", &self.options())
            .finish()
    }
}

impl SignalClient {
    pub async fn connect(
        url: &str,
        token: &str,
        options: SignalOptions,
        publisher_offer: Option<proto::SessionDescription>,
    ) -> SignalResult<(Self, proto::JoinResponse, SignalEvents)> {
        let handle_success = |inner: Arc<SignalInner>, join_response, stream_events| {
            let (emitter, events) = mpsc::unbounded_channel();
            let signal_task =
                tokio::spawn(signal_task(inner.clone(), emitter.clone(), stream_events));

            (Self { inner, emitter, handle: Mutex::new(Some(signal_task)) }, join_response, events)
        };

        match SignalInner::connect(url, token, options.clone(), publisher_offer.clone()).await {
            Ok((inner, join_response, stream_events)) => {
                Ok(handle_success(inner, join_response, stream_events))
            }
            Err(err) => {
                // fallback to region urls
                if matches!(&err, SignalError::Handshake { status } if status.as_u16() != 403) {
                    log::error!("unexpected signal error: {}", err.to_string());
                }

                // Fetching region URLs is best-effort. `fetch_region_urls`
                // already returns an empty list for non-cloud (direct /
                // self-hosted) URLs, so those skip the fallback entirely. If the
                // fetch itself fails (e.g. the region endpoint is unreachable),
                // that must NOT be fatal: log a warning and fall back to the
                // original connection error rather than masking it with the
                // fetch error.
                let urls = match RegionUrlProvider::fetch_region_urls(url, token).await {
                    Ok(urls) => urls,
                    Err(region_err) => {
                        log::warn!(
                            "failed to fetch region urls: {region_err}; surfacing original connection error"
                        );
                        return Err(err);
                    }
                };

                // With no region URLs to try, this surfaces the original error.
                // Otherwise we keep the most recent region attempt error, so that
                // if every region fails the caller sees why the last region
                // connection failed.
                let mut last_err = err;
                for region_url in urls.iter() {
                    log::info!("fallback connection to: {}", region_url);
                    match SignalInner::connect(
                        region_url,
                        token,
                        options.clone(),
                        publisher_offer.clone(),
                    )
                    .await
                    {
                        Ok((inner, join_response, stream_events)) => {
                            return Ok(handle_success(inner, join_response, stream_events))
                        }
                        Err(region_conn_err) => {
                            // This region is unreachable; drop it from the cache
                            // so the next attempt doesn't hand it out again.
                            RegionUrlProvider::mark_failed(url, region_url);
                            last_err = region_conn_err;
                        }
                    }
                }

                Err(last_err)
            }
        }
    }

    /// Restart the connection to the server.
    ///
    /// Leaves the client in a "reconnecting" state with pass-through-only sends
    /// queueable signals (e.g. `AddTrack`, `Mute`, `UpdateSubscription`) accumulate
    /// in the queue. Caller MUST invoke [`Self::set_reconnected`] once the resume
    /// has fully recovered (PC connected, SyncState sent) to drain the queue and
    /// re-enable normal sends.
    /// Reopen the signalling link for a resume, reporting `reason` to the server so it can
    /// attribute why the client reconnected.
    pub async fn restart(
        &self,
        reason: proto::ReconnectReason,
    ) -> SignalResult<proto::ReconnectResponse> {
        self.close().await;

        let (reconnect_response, stream_events) = self.inner.restart(reason).await?;
        let signal_task =
            tokio::spawn(signal_task(self.inner.clone(), self.emitter.clone(), stream_events));

        *self.handle.lock() = Some(signal_task);
        Ok(reconnect_response)
    }

    /// Mark the signal as fully reconnected: moves `Reconnecting` to `Connected` and drains
    /// the queue, so subsequent sends go straight through.
    ///
    /// MUST be called by the engine after `wait_pc_reconnected` succeeds.
    /// Without this, the queued mutations (subscription updates, mutes, etc.)
    /// stay buffered indefinitely.
    pub async fn set_reconnected(&self) {
        self.inner.set_reconnected().await;
    }

    /// Send a signal to the server (e.g. publish, subscribe, etc.)
    /// This will automatically queue the message if the connection fails
    /// The queue is flushed on the next restart
    pub async fn send(&self, signal: proto::signal_request::Message) {
        self.inner.send(signal).await
    }

    /// Close the connection to the server
    pub async fn close(&self) {
        self.inner.close(true).await;

        let handle = self.handle.lock().take();
        if let Some(signal_task) = handle {
            let _ = signal_task.await;
        }
    }

    /// Returns Initial JoinResponse
    pub fn join_response(&self) -> proto::JoinResponse {
        self.inner.join_response.clone()
    }

    /// Returns the initial options
    pub fn options(&self) -> SignalOptions {
        self.inner.options.clone()
    }

    /// Returns the initial URL
    pub fn url(&self) -> String {
        self.inner.url.clone()
    }

    /// Returns the last refreshed token (Or initial token if not refreshed yet)
    pub fn token(&self) -> String {
        self.inner.token.lock().clone()
    }

    /// Increment request_id for user-initiated requests and [`RequestResponse`][`proto::RequestResponse`]s
    pub fn next_request_id(&self) -> u32 {
        self.inner.next_request_id().clone()
    }

    /// Returns whether single peer connection mode is active.
    /// This is determined by whether the /rtc/v1 path was used successfully.
    pub fn is_single_pc_mode_active(&self) -> bool {
        self.inner.is_single_pc_mode_active()
    }

    /// Returns whether the underlying WebSocket is currently in place.
    ///
    /// The inner `signal_task` moves the client to `Offline` when the WebSocket dies
    /// (ping timeout or remote close), so callers in the resume path can use
    /// this to detect "signal died again while we were waiting for the PC."
    /// Note: `Reconnecting` with its transport installed counts as connected. The engine has
    /// not confirmed the resume yet, and that window is exactly what this check serves.
    pub async fn is_connected(&self) -> bool {
        self.inner.state.read().await.stream().is_some()
    }
}

impl SignalInner {
    pub async fn connect(
        url: &str,
        token: &str,
        options: SignalOptions,
        publisher_offer: Option<proto::SessionDescription>,
    ) -> SignalResult<(
        Arc<Self>,
        proto::JoinResponse,
        mpsc::UnboundedReceiver<Box<proto::signal_response::Message>>,
    )> {
        // The machine starts `Connecting` and is driven here, before there is a client to
        // hold it. A failed attempt ends `Closed` and is dropped with the error.
        let mut state = SignalState::default();
        let attempt = async {
            let (stream, mut events, single_pc_mode_active) =
                Self::open_transport(url, token, &options, publisher_offer.as_ref()).await?;
            let join_response = get_join_response(&mut events).await?;
            SignalResult::Ok((stream, events, single_pc_mode_active, join_response))
        };
        let (stream, events, single_pc_mode_active, join_response) = match attempt.await {
            Ok(connected) => connected,
            Err(err) => {
                let _ = state.transition(SignalInput::ConnectFailed);
                return Err(err);
            }
        };
        state
            .transition(SignalInput::ConnectComplete(stream))
            .expect("a fresh machine is Connecting and accepts its transport");

        let inner = Arc::new(SignalInner {
            state: AsyncRwLock::new(state),
            token: Mutex::new(token.to_owned()),
            queue: Default::default(),
            options,
            url: url.to_string(),
            join_response: join_response.clone(),
            request_id: AtomicU32::new(1),
            single_pc_mode_active,
        });

        Ok((inner, join_response, events))
    }

    /// Open the WebSocket: the v1 path first when single peer connection is enabled, falling
    /// back to v0 only when v1 is absent (404). Also returns whether the v1 path is active.
    async fn open_transport(
        url: &str,
        token: &str,
        options: &SignalOptions,
        publisher_offer: Option<&proto::SessionDescription>,
    ) -> SignalResult<(
        SignalStream,
        mpsc::UnboundedReceiver<Box<proto::signal_response::Message>>,
        bool,
    )> {
        // Try v1 path first if single_peer_connection is enabled
        let use_v1_path = options.single_peer_connection;
        // For initial connection: reconnect=false, reconnect_reason=None, participant_sid=""
        let lk_url = get_livekit_url(url, options, use_v1_path, false, None, "", publisher_offer)?;
        match SignalStream::connect(lk_url.clone(), token, options.connect_timeout).await {
            Ok((new_stream, stream_events)) => {
                log::debug!(
                    "signal connection successful: path={}, single_pc_mode={}",
                    if use_v1_path { "v1" } else { "v0" },
                    use_v1_path
                );
                Ok((new_stream, stream_events, use_v1_path))
            }
            Err(err) => {
                log::warn!(
                    "signal connection failed on {} path: {:?}",
                    if use_v1_path { "v1" } else { "v0" },
                    err
                );

                if let SignalError::TokenFormat = err {
                    return Err(err);
                }

                // Only fall back to v0 on a 404 (v1 endpoint absent). Other statuses
                // are real issues that shouldn't be masked by switching signaling mode.
                // The 404 is a WebSocket upgrade status, so it arrives as `Handshake`.
                let is_not_found =
                    matches!(&err, SignalError::Handshake { status } if status.as_u16() == 404);

                if use_v1_path && is_not_found {
                    let lk_url_v0 = get_livekit_url(url, options, false, false, None, "", None)?;
                    log::warn!("v1 path not found (404), falling back to v0 path");
                    match SignalStream::connect(lk_url_v0.clone(), token, options.connect_timeout)
                        .await
                    {
                        Ok((new_stream, stream_events)) => Ok((new_stream, stream_events, false)),
                        Err(err) => {
                            log::error!("v0 fallback also failed: {:?}", err);
                            if let SignalError::TokenFormat = err {
                                return Err(err);
                            }
                            Self::validate(lk_url_v0, token).await?;
                            Err(err)
                        }
                    }
                } else {
                    // Connection failed, try to retrieve more information
                    Self::validate(lk_url, token).await?;
                    Err(err)
                }
            }
        }
    }

    /// Validate the connection by calling rtc/validate.
    ///
    /// This is called from `connect()` when the primary WebSocket upgrade fails
    /// with a non-404 status, to surface a clearer HTTP-level error than the WS
    /// upgrade error. The access token is sent as `Authorization: Bearer <token>`
    /// so the server can actually authenticate the request; without it, the
    /// server returns 401 "no permissions to access the room" regardless of
    /// what the original error was, masking the real cause (e.g. a 503 from a
    /// saturated node becomes a fabricated 401 to the caller). See
    /// https://github.com/livekit/rust-sdks/issues/1042.
    async fn validate(ws_url: url::Url, token: &str) -> SignalResult<()> {
        let validate_url = get_validate_url(ws_url);
        let http = require_http_client()?;
        let headers = bearer_headers(token);

        let validate_fut = async {
            // validate() is best-effort diagnostic enrichment: it turns a failed WS
            // upgrade into a clearer HTTP-level status error. A failure of the GET
            // *itself* (network/TLS error) carries no such information, so swallow
            // it and return Ok(()) — the caller then surfaces the original
            // connection error rather than this unrelated one. See issue #1042.
            let Ok(res) = http.get(validate_url.to_string(), headers).await else {
                return Ok(());
            };
            // Fail closed on an out-of-range status (fall back to 502, matching the
            // region path) so a bogus status can't silently pass as 200/OK.
            let status =
                http::StatusCode::from_u16(res.status).unwrap_or(http::StatusCode::BAD_GATEWAY);
            if status.is_client_error() {
                return Err(SignalError::Client(
                    status,
                    String::from_utf8_lossy(&res.body).into_owned(),
                ));
            } else if status.is_server_error() {
                return Err(SignalError::Server(
                    status,
                    String::from_utf8_lossy(&res.body).into_owned(),
                ));
            }
            Ok(())
        };

        // A validate timeout is likewise non-fatal: fall through to Ok(()) so the
        // caller's original error is what surfaces, not a validate-timeout.
        tokio::time::timeout(VALIDATE_TIMEOUT, validate_fut).await.unwrap_or(Ok(()))
    }

    /// Returns whether single peer connection mode is active
    pub fn is_single_pc_mode_active(&self) -> bool {
        self.single_pc_mode_active
    }

    /// Restart is called when trying to resume the room (RtcSession resume).
    ///
    /// The write lock is held for the entire close + connect, so concurrent senders wait on
    /// the read side and land on the new transport instead of in a transport-less gap.
    pub async fn restart(
        self: &Arc<Self>,
        reason: proto::ReconnectReason,
    ) -> SignalResult<(
        proto::ReconnectResponse,
        mpsc::UnboundedReceiver<Box<proto::signal_response::Message>>,
    )> {
        let mut state = self.state.write().await;
        let old_stream = state.transition(SignalInput::Reconnect).map_err(|_| {
            SignalError::InvalidState(format!("resume the signal session from {state:?}"))
        })?;
        if let Some(old_stream) = old_stream {
            old_stream.close(false).await;
        }

        let sid = &self.join_response.participant.as_ref().unwrap().sid;
        let token = self.token.lock().clone();
        let lk_url = get_livekit_url(
            &self.url,
            &self.options,
            self.single_pc_mode_active,
            true,
            Some(reason as i32),
            sid,
            None,
        )
        .unwrap();

        let attempt = async {
            let (new_stream, mut events) =
                SignalStream::connect(lk_url, &token, self.options.connect_timeout).await?;
            let reconnect_response = get_reconnect_response(&mut events).await?;
            SignalResult::Ok((new_stream, reconnect_response, events))
        };
        match attempt.await {
            Ok((new_stream, reconnect_response, events)) => {
                state
                    .transition(SignalInput::ReconnectComplete(new_stream))
                    .expect("the write lock is held, so the state is still Reconnecting");
                Ok((reconnect_response, events))
            }
            Err(err) => {
                let _ = state.transition(SignalInput::ReconnectFailed);
                Err(err)
            }
        }
    }

    /// See [`SignalClient::set_reconnected`].
    pub async fn set_reconnected(&self) {
        let mut state = self.state.write().await;
        let _ = state.transition(SignalInput::Reconnected);
        // Drain while still holding the write lock, so no concurrent send can overtake what
        // was held during the resume.
        if let SignalState::Connected(stream) = &*state {
            self.flush_queue(stream).await;
        }
    }

    /// Close the connection on request.
    pub async fn close(&self, notify_close: bool) {
        // Already closing or closed: whoever owns that close finishes it.
        let Ok(stream) = self.state.write().await.transition(SignalInput::Close) else {
            return;
        };
        if let Some(stream) = stream {
            stream.close(notify_close).await;
        }
        let _ = self.state.write().await.transition(SignalInput::CloseComplete);
    }

    /// The transport died on its own (remote close or ping timeout): release it and go `Offline`.
    async fn transport_failed(&self) {
        let released = self.state.write().await.transition(SignalInput::TransportFailed);
        if let Ok(Some(stream)) = released {
            stream.close(true).await;
        }
    }

    /// Send a signal to the server.
    ///
    /// Pass-through signals go out on any transport; session-scoped signals wait in the queue
    /// until `Connected`.
    pub async fn send(&self, signal: proto::signal_request::Message) {
        let state = self.state.read().await;
        let stream = match &*state {
            SignalState::Connected(stream) => {
                self.flush_queue(stream).await;
                Some(stream)
            }
            SignalState::Reconnecting(Some(stream)) if is_pass_through(&signal) => Some(stream),
            SignalState::Connecting
            | SignalState::Reconnecting(_)
            | SignalState::Offline
            | SignalState::Disconnecting
            | SignalState::Closed => None,
        };

        match stream {
            Some(stream) => {
                if stream.send(signal.clone()).await.is_err() {
                    self.hold_or_drop(signal, "send failed").await;
                }
            }
            None => self.hold_or_drop(signal, "no confirmed transport").await,
        }
    }

    async fn hold_or_drop(&self, signal: proto::signal_request::Message, why: &str) {
        if is_pass_through(&signal) {
            log::warn!("dropping pass-through signal: {why}");
        } else {
            self.queue.lock().await.push(signal);
        }
    }

    /// Send every held signal over `stream`, in the order it was held. The queue stays locked
    /// for the whole drain: a concurrent `Connected` send waits here instead of overtaking.
    async fn flush_queue(&self, stream: &SignalStream) {
        let mut queue = self.queue.lock().await;
        for signal in queue.drain(..) {
            if let Err(err) = stream.send(signal).await {
                log::error!("failed to send queued signal: {}", err); // Lost message
            }
        }
    }

    /// Increment request_id for user-initiated requests and [`RequestResponse`][`proto::RequestResponse`]s
    pub fn next_request_id(&self) -> u32 {
        self.request_id.fetch_add(1, Ordering::SeqCst)
    }
}

/// Middleware task to receive SignalStream events and handle SignalClient specific logic
async fn signal_task(
    inner: Arc<SignalInner>,
    emitter: SignalEmitter, // Public emitter
    mut internal_events: mpsc::UnboundedReceiver<Box<proto::signal_response::Message>>,
) {
    let mut ping_interval = interval(Duration::from_secs(inner.join_response.ping_interval as u64));
    let timeout_duration = Duration::from_secs(inner.join_response.ping_timeout as u64);
    let ping_timeout = sleep(timeout_duration);
    tokio::pin!(ping_timeout);

    let mut rtt = 0; // TODO(theomonnom): Should we expose SignalClient rtt?

    loop {
        tokio::select! {
            signal = internal_events.recv() => {
                if let Some(signal) = signal {
                    // Received a message from the server
                    match signal.as_ref() {
                        proto::signal_response::Message::RefreshToken(ref token) => {
                            // Refresh the token so the client can still reconnect if the initial join token expired
                            *inner.token.lock() = token.clone();
                        }
                        proto::signal_response::Message::PongResp(ref pong) => {
                            // Reset the ping_timeout if we received a pong
                            let now = SystemTime::now()
                                .duration_since(UNIX_EPOCH)
                                .unwrap()
                                .as_millis() as i64;

                            rtt = now - pong.last_ping_timestamp;
                        }
                        _ => {}
                    }

                    ping_timeout.as_mut().reset(Instant::now() + timeout_duration);

                    let _ = emitter.send(SignalEvent::Message(signal));
                } else {
                    let _ = emitter.send(SignalEvent::Close("stream closed".into()));
                    break; // Stream closed
                }
            }
            _ = ping_interval.tick() => {
                let now = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap()
                    .as_millis() as i64;

                let ping = proto::signal_request::Message::PingReq(proto::Ping{
                    timestamp: now,
                    rtt,
                });

                inner.send(ping).await;
            }
            _ = &mut ping_timeout => {
                // No pong within the configured window — the WS is dead even
                // if the OS hasn't told us yet. Tear down the stream and emit
                // Close; the engine layer reads that as a trigger to drive
                // a resume reconnect (see SignalEvent::Close docs).
                let _ = emitter.send(SignalEvent::Close("ping timeout".into()));
                break;
            }
        }
    }

    // The loop only ends when the transport is gone or unresponsive. Refused, and so a no-op,
    // when the transport was closed on request.
    inner.transport_failed().await;
}

/// Returns true for signals that must NOT be queued during a reconnect — they
/// drive signaling/negotiation itself (Trickle ICE candidates, the
/// publisher Offer, the subscriber Answer, the client SyncState that the SFU
/// uses to resync state, plus simulate/leave). Buffering these would deadlock
/// the resume. Mirrors `client-sdk-js` `passThroughQueueSignals`.
fn is_pass_through(signal: &proto::signal_request::Message) -> bool {
    matches!(
        signal,
        proto::signal_request::Message::SyncState(_)
            | proto::signal_request::Message::Trickle(_)
            | proto::signal_request::Message::Offer(_)
            | proto::signal_request::Message::Answer(_)
            | proto::signal_request::Message::Simulate(_)
            | proto::signal_request::Message::Leave(_)
    )
}

fn client_info_sdk_for_name(sdk: &str) -> proto::client_info::Sdk {
    match sdk {
        "js" => proto::client_info::Sdk::Js,
        "ios" | "swift" => proto::client_info::Sdk::Swift,
        "android" => proto::client_info::Sdk::Android,
        "flutter" => proto::client_info::Sdk::Flutter,
        "go" => proto::client_info::Sdk::Go,
        "unity" => proto::client_info::Sdk::Unity,
        "reactnative" => proto::client_info::Sdk::ReactNative,
        "rust" => proto::client_info::Sdk::Rust,
        "python" => proto::client_info::Sdk::Python,
        "cpp" => proto::client_info::Sdk::Cpp,
        "unityweb" => proto::client_info::Sdk::UnityWeb,
        "node" => proto::client_info::Sdk::Node,
        "esp32" => proto::client_info::Sdk::Esp32,
        _ => {
            log::warn!("unknown SDK name in signal options: {}", sdk);
            proto::client_info::Sdk::Unknown
        }
    }
}

/// Create the base64-encoded WrappedJoinRequest parameter required for v1 path
///
/// Parameters:
/// - options: SignalOptions containing auto_subscribe, adaptive_stream, etc.
/// - reconnect: true if this is a reconnection attempt
/// - participant_sid: the participant SID (only used during reconnection)
fn create_join_request_param(
    options: &SignalOptions,
    reconnect: bool,
    reconnect_reason: Option<i32>,
    participant_sid: &str,
    os: String,
    os_version: String,
    device_model: String,
    publisher_offer: Option<&proto::SessionDescription>,
) -> String {
    let connection_settings = proto::ConnectionSettings {
        auto_subscribe: options.auto_subscribe,
        adaptive_stream: options.adaptive_stream,
        ..Default::default()
    };

    let client_info = proto::ClientInfo {
        sdk: client_info_sdk_for_name(&options.sdk_options.sdk) as i32,
        version: options.sdk_options.sdk_version.clone().unwrap_or_default(),
        protocol: PROTOCOL_VERSION as i32,
        os,
        os_version,
        device_model,
        capabilities: CLIENT_CAPABILITIES.iter().map(|c| *c as i32).collect(),
        client_protocol: advertised_client_protocol(options),
        other_sdks: options.sdk_options.other_sdks.clone().unwrap_or_default(),
        ..Default::default()
    };

    let mut join_request = proto::JoinRequest {
        client_info: Some(client_info),
        connection_settings: Some(connection_settings),
        reconnect,
        publisher_offer: publisher_offer.cloned(),
        ..Default::default()
    };

    // Only set participant_sid if non-empty (for reconnects)
    if !participant_sid.is_empty() {
        join_request.participant_sid = participant_sid.to_string();
    }

    // Only set reconnect_reason if provided
    if let Some(reason) = reconnect_reason {
        join_request.reconnect_reason = reason;
    }

    // Serialize JoinRequest to bytes
    let join_request_bytes = join_request.encode_to_vec();

    // Always use gzip compression to reduce URL size on poor networks
    let (compressed_bytes, compression) = {
        let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
        if encoder.write_all(&join_request_bytes).is_ok() {
            if let Ok(compressed) = encoder.finish() {
                // Only use compressed version if it's actually smaller
                if compressed.len() < join_request_bytes.len() {
                    (compressed, proto::wrapped_join_request::Compression::Gzip as i32)
                } else {
                    (join_request_bytes, proto::wrapped_join_request::Compression::None as i32)
                }
            } else {
                (join_request_bytes, proto::wrapped_join_request::Compression::None as i32)
            }
        } else {
            (join_request_bytes, proto::wrapped_join_request::Compression::None as i32)
        }
    };

    let wrapped_join_request =
        proto::WrappedJoinRequest { join_request: compressed_bytes, compression };

    // Serialize WrappedJoinRequest to bytes and base64url encode
    // (URL-safe base64 avoids percent-encoding issues in query parameters)
    let wrapped_bytes = wrapped_join_request.encode_to_vec();
    BASE64_URL_SAFE.encode(&wrapped_bytes)
}

/// Build the LiveKit WebSocket URL for connection
///
/// Parameters:
/// - url: the base server URL
/// - options: SignalOptions
/// - use_v1_path: if true, use /rtc/v1 (single PC mode), otherwise /rtc (dual PC mode)
/// - reconnect: true if this is a reconnection attempt
/// - reconnect_reason: reason for reconnection (only used when reconnect=true)
/// - participant_sid: the participant SID (only used during reconnection)
fn get_livekit_url(
    url: &str,
    options: &SignalOptions,
    use_v1_path: bool,
    reconnect: bool,
    reconnect_reason: Option<i32>,
    participant_sid: &str,
    publisher_offer: Option<&proto::SessionDescription>,
) -> SignalResult<url::Url> {
    let mut lk_url = url::Url::parse(url).map_err(|err| SignalError::UrlParse(err.to_string()))?;

    if !lk_url.has_host() {
        return Err(SignalError::UrlParse("missing host or scheme".into()));
    }

    // Automatically switch to websocket scheme when using user is providing http(s) scheme
    if lk_url.scheme() == "https" {
        lk_url.set_scheme("wss").unwrap();
    } else if lk_url.scheme() == "http" {
        lk_url.set_scheme("ws").unwrap();
    } else if lk_url.scheme() != "wss" && lk_url.scheme() != "ws" {
        return Err(SignalError::UrlParse(format!("unsupported scheme: {}", lk_url.scheme())));
    }

    if let Ok(mut segs) = lk_url.path_segments_mut() {
        segs.push("rtc");
        if use_v1_path {
            segs.push("v1");
        }
    }

    let os_info = os_info::get();
    let device_model = device_info::device_info().map(|info| info.model).unwrap_or_default();

    if use_v1_path {
        // For v1 path (single PC mode): only join_request param
        // All other info (sdk, protocol, auto_subscribe, etc.) is inside the JoinRequest protobuf
        let join_request_param = create_join_request_param(
            options,
            reconnect,
            reconnect_reason,
            participant_sid,
            os_info.os_type().to_string(),
            os_info.version().to_string(),
            device_model.to_string(),
            publisher_offer,
        );
        lk_url.query_pairs_mut().append_pair("join_request", &join_request_param);
    } else {
        // For v0 path (dual PC mode): use URL query parameters
        lk_url
            .query_pairs_mut()
            .append_pair("sdk", options.sdk_options.sdk.as_str())
            .append_pair("os", os_info.os_type().to_string().as_str())
            .append_pair("os_version", os_info.version().to_string().as_str())
            .append_pair("device_model", device_model.to_string().as_str())
            .append_pair("protocol", PROTOCOL_VERSION.to_string().as_str())
            .append_pair(
                "client_protocol",
                advertised_client_protocol(options).to_string().as_str(),
            )
            .append_pair("auto_subscribe", if options.auto_subscribe { "1" } else { "0" })
            .append_pair("adaptive_stream", if options.adaptive_stream { "1" } else { "0" });

        if let Some(sdk_version) = &options.sdk_options.sdk_version {
            lk_url.query_pairs_mut().append_pair("version", sdk_version.as_str());
        }

        if let Some(other_sdks) =
            options.sdk_options.other_sdks.as_deref().filter(|s| !s.is_empty())
        {
            lk_url.query_pairs_mut().append_pair("other_sdks", other_sdks);
        }

        // parse client capabilities
        if !CLIENT_CAPABILITIES.is_empty() {
            let caps =
                CLIENT_CAPABILITIES.iter().map(|c| c.as_str_name()).collect::<Vec<_>>().join(",");
            lk_url.query_pairs_mut().append_pair("capabilities", &caps);
        }

        // For reconnects in v0 path, add reconnect and sid as separate query parameters
        if reconnect {
            lk_url
                .query_pairs_mut()
                .append_pair("reconnect", "1")
                .append_pair("sid", participant_sid);

            // The server parses this with `strconv.Atoi` (`rtcservice.go`), so it is the
            // enum's numeric value stringified, not its name. `reconnect_reason` is already
            // an `i32` (the caller casts), so `to_string` yields e.g. "3". On the v1 path the
            // equivalent travels inside the JoinRequest protobuf as an integer field.
            if let Some(reason_value) = reconnect_reason {
                lk_url
                    .query_pairs_mut()
                    .append_pair("reconnect_reason", reason_value.to_string().as_str());
            }
        }
    }

    Ok(lk_url)
}

/// Build the `Authorization: Bearer <token>` header vec used by HTTP/WS callers.
pub(crate) fn bearer_headers(token: &str) -> Vec<livekit_net::Header> {
    vec![livekit_net::Header { name: "Authorization".into(), value: format!("Bearer {token}") }]
}

/// Resolve the registered WebSocket client, or a permanent
/// [`SignalError::TransportNotConfigured`] if none has been set. Centralises the
/// lookup so callers share one error rather than each inventing a string.
pub(crate) fn require_ws_client() -> SignalResult<Arc<dyn livekit_net::WsClient>> {
    livekit_net::ws_client().ok_or(SignalError::TransportNotConfigured)
}

/// Resolve the registered HTTP client, or a permanent
/// [`SignalError::TransportNotConfigured`] if none has been set.
pub(crate) fn require_http_client() -> SignalResult<Arc<dyn livekit_net::HttpClient>> {
    livekit_net::http_client().ok_or(SignalError::TransportNotConfigured)
}

/// Verify `token` can be encoded as an HTTP `Authorization` header value. A token
/// carrying characters illegal in a header value can never authenticate, so
/// callers surface a clear, non-retryable [`SignalError::TokenFormat`] up front
/// rather than a generic transport error deep in the connect path (which would
/// otherwise drive the pointless v1→v0 + full-reconnect fallback).
pub(crate) fn check_token_format(token: &str) -> SignalResult<()> {
    http::HeaderValue::from_str(&format!("Bearer {token}"))
        .map(|_| ())
        .map_err(|_| SignalError::TokenFormat)
}

/// Map a [`livekit_net::TransportError`] onto a [`SignalError`], so transport
/// failures cascade up with `?`/`.into()`.
///
/// - `Timeout` → `SignalError::Timeout` (timed out at transport layer)
/// - `Http { status }` → `Client` for 4xx, `Server` for 5xx (empty body — caller
///   may have already read the body separately)
/// - `Connection` / `Other` → `SignalError::Connection` (network/TLS/transport failure)
/// - `Closed` → `SignalError::Closed` (peer/transport closed)
///
/// Every variant except `LeaveRequest` drives the engine's full-reconnect path.
impl From<livekit_net::TransportError> for SignalError {
    fn from(e: livekit_net::TransportError) -> Self {
        use livekit_net::TransportError as TE;
        match e {
            TE::Timeout => SignalError::Timeout("transport timed out".into()),
            // Only a failed WebSocket upgrade yields `Http`; it maps to `Handshake`,
            // leaving `Client`/`Server` for the authoritative `validate()` result.
            TE::Http { status } => SignalError::Handshake {
                status: http::StatusCode::from_u16(status).unwrap_or(http::StatusCode::BAD_GATEWAY),
            },
            TE::Closed => SignalError::Closed,
            TE::Connection(m) => SignalError::Connection(m),
            TE::Other(m) => SignalError::Connection(m),
        }
    }
}

/// Convert a WebSocket URL (with /rtc or /rtc/v1 path) to the validate endpoint URL
fn get_validate_url(mut ws_url: url::Url) -> url::Url {
    ws_url.set_scheme(if ws_url.scheme() == "wss" { "https" } else { "http" }).unwrap();
    // ws_url already has /rtc or /rtc/v1 from get_livekit_url, so only append /validate
    if let Ok(mut segs) = ws_url.path_segments_mut() {
        segs.push("validate");
    }
    ws_url
}

macro_rules! get_async_message {
    ($fnc:ident, $pattern:pat => $result:expr, $ty:ty) => {
        async fn $fnc(
            receiver: &mut mpsc::UnboundedReceiver<Box<proto::signal_response::Message>>,
        ) -> SignalResult<$ty> {
            let join = async {
                while let Some(event) = receiver.recv().await {
                    if let $pattern = *event {
                        return Ok($result);
                    }
                }

                // The channel only ends when the read task does, i.e. the transport went away
                // before the server answered. That is a close, not a timeout — nothing waited.
                // Only the `tokio::time::timeout` wrapper below is a genuine timeout.
                Err(SignalError::Closed)
            };

            tokio::time::timeout(JOIN_RESPONSE_TIMEOUT, join).await.map_err(|_| {
                SignalError::Timeout(format!("failed to receive {}", std::any::type_name::<$ty>()))
            })?
        }
    };
}

get_async_message!(
    get_join_response,
    proto::signal_response::Message::Join(msg) => msg,
    proto::JoinResponse
);

/// Debug-slice the prost oneof to recover the variant name (e.g. "Update") without
/// matching every possible variant. Only used in cold log paths.
fn signal_message_variant_name(msg: &proto::signal_response::Message) -> String {
    let dbg = format!("{:?}", msg);
    dbg.split(['(', ' ']).next().unwrap_or("Unknown").to_string()
}

async fn get_reconnect_response(
    receiver: &mut mpsc::UnboundedReceiver<Box<proto::signal_response::Message>>,
) -> SignalResult<proto::ReconnectResponse> {
    let join = async {
        while let Some(event) = receiver.recv().await {
            match *event {
                proto::signal_response::Message::Reconnect(msg) => return Ok(msg),
                proto::signal_response::Message::Leave(leave) => {
                    return Err(SignalError::LeaveRequest {
                        reason: leave.reason(),
                        action: leave.action(),
                    });
                }
                other => {
                    // Some server versions interleave signal messages before the
                    // ReconnectResponse. Client-side reordering would risk applying
                    // stale state; log and drop, and rely on a server-side ordering
                    // fix for correctness.
                    log::warn!(
                        "signal message arrived before ReconnectResponse, dropping: {}",
                        signal_message_variant_name(&other)
                    );
                }
            }
        }

        // The channel only ends when the read task does, i.e. the transport went away
        // before the server answered. That is a close, not a timeout — nothing waited.
        // Only the `tokio::time::timeout` wrapper below is a genuine timeout.
        Err(SignalError::Closed)
    };

    tokio::time::timeout(JOIN_RESPONSE_TIMEOUT, join).await.map_err(|_| {
        SignalError::Timeout(format!(
            "failed to receive {}",
            std::any::type_name::<proto::ReconnectResponse>()
        ))
    })?
}

#[cfg(test)]
mod tests {
    use base64::engine::general_purpose::STANDARD as BASE64_STANDARD;

    use super::*;

    fn signal_options_for_cpp(version: &str) -> SignalOptions {
        let mut options = SignalOptions::default();
        options.sdk_options.sdk = "cpp".to_string();
        options.sdk_options.sdk_version = Some(version.to_string());
        options
    }

    fn decode_join_request_param_for_test(param: &str) -> proto::JoinRequest {
        let wrapped_bytes = BASE64_STANDARD.decode(param).unwrap();
        let wrapped = proto::WrappedJoinRequest::decode(wrapped_bytes.as_slice()).unwrap();
        proto::JoinRequest::decode(wrapped.join_request.as_slice()).unwrap()
    }

    /// The server attributes client reconnects from this value
    /// (`rtcservice.go`: `r.FormValue("reconnect_reason")`), so a resume that omits it is
    /// invisible in that telemetry. Both signalling paths must carry it: v0 as a query
    /// parameter, v1 inside the JoinRequest protobuf.
    #[test]
    fn resume_reports_the_reconnect_reason_on_both_signalling_paths() {
        let reason = proto::ReconnectReason::RrSubscriberFailed;

        let v0 = get_livekit_url(
            "ws://localhost:7880",
            &SignalOptions::default(),
            /* use_v1_path= */ false,
            /* reconnect= */ true,
            Some(reason as i32),
            "PA_test",
            None,
        )
        .unwrap();
        let v0_params: Vec<(String, String)> =
            v0.query_pairs().map(|(k, v)| (k.into_owned(), v.into_owned())).collect();
        // The server parses this with `strconv.Atoi`, so it must be the enum's numeric value
        // stringified ("3"), never its name ("RR_SUBSCRIBER_FAILED"). Pinned as a literal so
        // the wire format is asserted rather than restated.
        assert_eq!(reason as i32, 3);
        assert!(
            v0_params.contains(&("reconnect_reason".to_string(), "3".to_string())),
            "v0 resume must send reconnect_reason as the stringified number, got {v0_params:?}"
        );

        let v1 = get_livekit_url(
            "ws://localhost:7880",
            &SignalOptions::default(),
            /* use_v1_path= */ true,
            /* reconnect= */ true,
            Some(reason as i32),
            "PA_test",
            None,
        )
        .unwrap();
        let join_request_param = v1
            .query_pairs()
            .find(|(k, _)| k == "join_request")
            .map(|(_, v)| v.into_owned())
            .expect("v1 resume must carry a join_request");
        assert_eq!(decode_join_request_param_for_test(&join_request_param).reconnect_reason, 3);
    }

    /// An initial connect is not a reconnect, so it must not claim a reason.
    #[test]
    fn initial_connect_sends_no_reconnect_reason() {
        let url = get_livekit_url(
            "ws://localhost:7880",
            &SignalOptions::default(),
            /* use_v1_path= */ false,
            /* reconnect= */ false,
            None,
            "",
            None,
        )
        .unwrap();
        assert!(url.query_pairs().all(|(k, _)| k != "reconnect_reason"));
    }

    #[test]
    fn client_info_sdk_for_name_maps_known_sdks() {
        assert_eq!(client_info_sdk_for_name("cpp"), proto::client_info::Sdk::Cpp);
        assert_eq!(client_info_sdk_for_name("ios"), proto::client_info::Sdk::Swift);
        assert_eq!(client_info_sdk_for_name("rust"), proto::client_info::Sdk::Rust);
        assert_eq!(client_info_sdk_for_name("node"), proto::client_info::Sdk::Node);
        assert_eq!(client_info_sdk_for_name("reactnative"), proto::client_info::Sdk::ReactNative);
        assert_eq!(client_info_sdk_for_name("unityweb"), proto::client_info::Sdk::UnityWeb);
        assert_eq!(client_info_sdk_for_name("unknown-sdk"), proto::client_info::Sdk::Unknown);
    }

    /// Build an `Offline` SignalInner suitable for exercising the queue routing in
    /// `send`. Any actual write would be dropped, which is fine — these tests only assert
    /// which side of the queue each message lands on.
    fn make_stub_inner() -> Arc<SignalInner> {
        make_stub_inner_with(proto::JoinResponse::default())
    }

    /// As `make_stub_inner`, with a join response — `restart` reads the participant sid from it.
    fn make_stub_inner_with(join_response: proto::JoinResponse) -> Arc<SignalInner> {
        Arc::new(SignalInner {
            state: AsyncRwLock::new(SignalState::Offline),
            token: Mutex::new(String::new()),
            queue: Default::default(),
            url: "wss://localhost:7880".to_string(),
            options: SignalOptions::default(),
            join_response,
            request_id: AtomicU32::new(1),
            single_pc_mode_active: false,
        })
    }

    fn mute(sid: &str) -> proto::signal_request::Message {
        proto::signal_request::Message::Mute(proto::MuteTrackRequest {
            sid: sid.into(),
            muted: true,
        })
    }

    /// The sids of the queued mute requests, in queue order.
    async fn queued_sids(inner: &Arc<SignalInner>) -> Vec<String> {
        inner
            .queue
            .lock()
            .await
            .iter()
            .filter_map(|signal| match signal {
                proto::signal_request::Message::Mute(m) => Some(m.sid.clone()),
                _ => None,
            })
            .collect()
    }

    /// A live stream over the shared mock transport, for the tests that need the
    /// difference between "held because we are reconnecting" and "held because
    /// there is nowhere to send".
    ///
    /// Gated like its callers: `test_transport` only exists for the tokio flavour, so an
    /// ungated helper would break the `async` build.
    async fn mock_stream() -> SignalStream {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();
        SignalStream::connect(
            url::Url::parse("wss://localhost:7880/rtc").unwrap(),
            "",
            Duration::from_secs(1),
        )
        .await
        .expect("the mock transport always connects")
        .0
    }

    #[tokio::test]
    async fn send_queues_queueable_signals_while_offline() {
        let inner = make_stub_inner();

        // Queueable: AddTrack, Mute, UpdateSubscription
        inner
            .send(proto::signal_request::Message::AddTrack(proto::AddTrackRequest {
                cid: "track1".into(),
                ..Default::default()
            }))
            .await;
        inner
            .send(proto::signal_request::Message::Mute(proto::MuteTrackRequest {
                sid: "sid1".into(),
                muted: true,
            }))
            .await;
        inner
            .send(proto::signal_request::Message::Subscription(proto::UpdateSubscription {
                track_sids: vec!["sid2".into()],
                ..Default::default()
            }))
            .await;

        assert_eq!(
            inner.queue.lock().await.len(),
            3,
            "all three queueable signals should be buffered"
        );
    }

    #[tokio::test]
    async fn send_does_not_queue_pass_through_signals_while_offline() {
        let inner = make_stub_inner();

        // Pass-through: Trickle, Offer, Answer, SyncState, Simulate, Leave.
        // With no transport these are logged and dropped — but critically they do NOT land
        // in the queue.
        inner.send(proto::signal_request::Message::Trickle(proto::TrickleRequest::default())).await;
        inner
            .send(proto::signal_request::Message::Offer(proto::SessionDescription::default()))
            .await;
        inner
            .send(proto::signal_request::Message::Answer(proto::SessionDescription::default()))
            .await;
        inner.send(proto::signal_request::Message::SyncState(proto::SyncState::default())).await;
        inner
            .send(proto::signal_request::Message::Simulate(proto::SimulateScenario::default()))
            .await;
        inner.send(proto::signal_request::Message::Leave(proto::LeaveRequest::default())).await;

        let queued = inner.queue.lock().await.len();
        assert_eq!(queued, 0, "pass-through signals must not be queued, got {queued}");
    }

    /// The engine's confirmation is what turns a resumed transport into a connected one, and
    /// everything held during the resume goes out at that moment, not on the next send.
    #[tokio::test]
    async fn set_reconnected_confirms_the_transport_and_drains_the_queue() {
        let inner = make_stub_inner();
        *inner.state.write().await = SignalState::Reconnecting(Some(mock_stream().await));

        inner.send(mute("held-during-resume")).await;
        assert_eq!(queued_sids(&inner).await, vec!["held-during-resume"]);

        inner.set_reconnected().await;

        assert!(matches!(*inner.state.read().await, SignalState::Connected(_)));
        assert!(inner.queue.lock().await.is_empty(), "the queue must drain on confirmation");
    }

    /// A connection that records what was sent and never ends, so the stream's write task stays
    /// alive and every `send` genuinely awaits its acknowledgement.
    struct RecordingConn {
        sent: Mutex<Vec<Vec<u8>>>,
    }

    #[async_trait::async_trait]
    impl livekit_net::WsConnection for RecordingConn {
        async fn send(&self, frame: Vec<u8>) -> Result<(), livekit_net::TransportError> {
            self.sent.lock().push(frame);
            Ok(())
        }
        async fn recv(&self) -> Result<Option<Vec<u8>>, livekit_net::TransportError> {
            std::future::pending().await
        }
        async fn close(&self) {}
    }

    /// The mute sids the connection saw, in wire order.
    fn sent_sids(conn: &RecordingConn) -> Vec<String> {
        conn.sent
            .lock()
            .iter()
            .filter_map(|frame| {
                match proto::SignalRequest::decode(frame.as_slice()).ok()?.message {
                    Some(proto::signal_request::Message::Mute(m)) => Some(m.sid),
                    _ => None,
                }
            })
            .collect()
    }

    /// Held signals are older than anything a concurrent sender has, so they must all reach
    /// the wire before it. The read lock is shared, so only the queue lock can enforce that.
    #[tokio::test]
    async fn a_concurrent_send_cannot_overtake_the_held_batch() {
        let conn = Arc::new(RecordingConn { sent: Mutex::new(Vec::new()) });
        let (stream, _events) = SignalStream::spawn(conn.clone());
        let inner = make_stub_inner();
        *inner.state.write().await = SignalState::Connected(stream);
        inner.queue.lock().await.extend([mute("held-1"), mute("held-2")]);

        let a = tokio::spawn({
            let inner = inner.clone();
            async move { inner.send(mute("a")).await }
        });
        let b = tokio::spawn({
            let inner = inner.clone();
            async move { inner.send(mute("b")).await }
        });
        a.await.unwrap();
        b.await.unwrap();

        let order = sent_sids(&conn);
        assert_eq!(&order[..2], ["held-1", "held-2"], "held batch was interleaved: {order:?}");
        assert_eq!(order.len(), 4);
    }

    /// The queue is FIFO, and the release order is the send order. The existing
    /// `send_queues_queueable_signals_during_reconnect` only counts what landed there.
    #[tokio::test]
    async fn queued_signals_keep_their_order() {
        let inner = make_stub_inner();

        inner.send(mute("first")).await;
        inner.send(mute("second")).await;
        inner.send(mute("third")).await;

        assert_eq!(queued_sids(&inner).await, vec!["first", "second", "third"]);
    }

    /// A resume is not complete when the transport comes back — the engine calls
    /// `set_reconnected` once the media path is back too, which is seconds later. A
    /// session-scoped send in that window must queue behind what is already waiting rather
    /// than overtake it.
    #[tokio::test]
    async fn send_still_queues_after_the_transport_returns() {
        let inner = make_stub_inner();

        // issued while the resume is in flight
        inner.send(mute("held-during-resume")).await;

        // the resume has answered and its transport is installed; `restart` deliberately
        // stays `Reconnecting` until the engine reports in
        *inner.state.write().await = SignalState::Reconnecting(Some(mock_stream().await));

        inner.send(mute("issued-while-catching-up")).await;

        assert_eq!(
            queued_sids(&inner).await,
            vec!["held-during-resume", "issued-while-catching-up"],
            "a live transport must not let a later send overtake a held one"
        );
    }

    /// A failed resume has to land in `Offline`, so the next attempt starts clean and
    /// `is_connected` tells the engine the truth.
    #[tokio::test]
    async fn restart_failure_leaves_the_state_offline() {
        let _ = mock_stream().await; // installs the shared mock transport
        let inner = make_stub_inner_with(proto::JoinResponse {
            participant: Some(proto::ParticipantInfo {
                sid: "PA_test".into(),
                ..Default::default()
            }),
            ..Default::default()
        });

        // The mock yields one Pong and then ends the stream, so no ReconnectResponse ever
        // arrives and the resume fails.
        let err = inner
            .restart(proto::ReconnectReason::RrUnknown)
            .await
            .err()
            .expect("restart must fail without a reconnect answer");
        assert!(matches!(err, SignalError::Closed), "expected a close, got {err:?}");
        assert!(
            matches!(*inner.state.read().await, SignalState::Offline),
            "a failed restart must leave the state offline"
        );
    }

    async fn state_named(name: &str) -> SignalState {
        match name {
            "Connecting" => SignalState::Connecting,
            "Connected(SignalStream)" => SignalState::Connected(mock_stream().await),
            "Reconnecting(None)" => SignalState::Reconnecting(None),
            "Reconnecting(Some(SignalStream))" => {
                SignalState::Reconnecting(Some(mock_stream().await))
            }
            "Offline" => SignalState::Offline,
            "Disconnecting" => SignalState::Disconnecting,
            "Closed" => SignalState::Closed,
            other => panic!("unknown state {other}"),
        }
    }

    async fn input_named(name: &str) -> SignalInput {
        match name {
            "ConnectComplete" => SignalInput::ConnectComplete(mock_stream().await),
            "ConnectFailed" => SignalInput::ConnectFailed,
            "Reconnect" => SignalInput::Reconnect,
            "ReconnectComplete" => SignalInput::ReconnectComplete(mock_stream().await),
            "ReconnectFailed" => SignalInput::ReconnectFailed,
            "Reconnected" => SignalInput::Reconnected,
            "TransportFailed" => SignalInput::TransportFailed,
            "Close" => SignalInput::Close,
            "CloseComplete" => SignalInput::CloseComplete,
            other => panic!("unknown input {other}"),
        }
    }

    /// The whole table: `None` means the state refuses the input and must not move.
    fn expected(from: &str, input: &str) -> Option<&'static str> {
        match (from, input) {
            ("Connecting", "ConnectComplete") => Some("Connected(SignalStream)"),
            ("Connecting", "ConnectFailed") => Some("Closed"),
            ("Connected(SignalStream)", "Reconnect") => Some("Reconnecting(None)"),
            ("Connected(SignalStream)", "TransportFailed") => Some("Offline"),
            ("Connected(SignalStream)", "Close") => Some("Disconnecting"),
            ("Reconnecting(None)", "ReconnectComplete") => Some("Reconnecting(Some(SignalStream))"),
            ("Reconnecting(None)", "ReconnectFailed") => Some("Offline"),
            ("Reconnecting(None)", "Close") => Some("Disconnecting"),
            ("Reconnecting(Some(SignalStream))", "ReconnectFailed") => Some("Offline"),
            ("Reconnecting(Some(SignalStream))", "Reconnected") => Some("Connected(SignalStream)"),
            ("Reconnecting(Some(SignalStream))", "TransportFailed") => Some("Offline"),
            ("Reconnecting(Some(SignalStream))", "Close") => Some("Disconnecting"),
            ("Offline", "Reconnect") => Some("Reconnecting(None)"),
            ("Offline", "Close") => Some("Disconnecting"),
            ("Disconnecting", "CloseComplete") => Some("Closed"),
            ("Closed", "Reconnect") => Some("Reconnecting(None)"),
            _ => None,
        }
    }

    #[tokio::test]
    async fn every_state_and_input_matches_the_transition_table() {
        const STATES: &[&str] = &[
            "Connecting",
            "Connected(SignalStream)",
            "Reconnecting(None)",
            "Reconnecting(Some(SignalStream))",
            "Offline",
            "Disconnecting",
            "Closed",
        ];
        const INPUTS: &[&str] = &[
            "ConnectComplete",
            "ConnectFailed",
            "Reconnect",
            "ReconnectComplete",
            "ReconnectFailed",
            "Reconnected",
            "TransportFailed",
            "Close",
            "CloseComplete",
        ];
        for from in STATES {
            for input in INPUTS {
                let mut state = state_named(from).await;
                let result = state.transition(input_named(input).await);
                let landed = format!("{state:?}");
                match expected(from, input) {
                    Some(to) => {
                        assert_eq!(landed, to, "{from} + {input} should reach {to}");
                        // a transport the new state does not own must be handed back to be closed
                        let releases =
                            from.contains("SignalStream") && !to.contains("SignalStream");
                        assert_eq!(
                            result.as_ref().ok().map(|s| s.is_some()),
                            Some(releases),
                            "{from} + {input} released the wrong transport"
                        );
                    }
                    None => {
                        assert!(result.is_err(), "{from} refuses {input}");
                        assert_eq!(landed, *from, "{from} refuses {input}, so it must not move");
                    }
                }
            }
        }
    }

    #[test]
    fn livekit_url_test() {
        let io = SignalOptions::default();

        assert!(get_livekit_url("localhost:7880", &io, false, false, None, "", None).is_err());
        assert_eq!(
            get_livekit_url("https://localhost:7880", &io, false, false, None, "", None)
                .unwrap()
                .scheme(),
            "wss"
        );
        assert_eq!(
            get_livekit_url("http://localhost:7880", &io, false, false, None, "", None)
                .unwrap()
                .scheme(),
            "ws"
        );
        assert_eq!(
            get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None)
                .unwrap()
                .scheme(),
            "wss"
        );
        assert_eq!(
            get_livekit_url("ws://localhost:7880", &io, false, false, None, "", None)
                .unwrap()
                .scheme(),
            "ws"
        );
        assert!(get_livekit_url("ftp://localhost:7880", &io, false, false, None, "", None).is_err());
    }

    #[test]
    fn livekit_url_v0_reports_cpp_sdk_and_version() {
        let io = signal_options_for_cpp("9.9.9-test");
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None).unwrap();
        let query: std::collections::HashMap<_, _> = lk_url.query_pairs().into_owned().collect();

        assert_eq!(query.get("sdk").map(String::as_str), Some("cpp"));
        assert_eq!(query.get("version").map(String::as_str), Some("9.9.9-test"));
    }

    #[test]
    fn livekit_url_v1_join_request_reports_cpp_sdk_and_version() {
        let io = signal_options_for_cpp("9.9.9-test");
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, true, false, None, "", None).unwrap();
        let join_request_param = lk_url
            .query_pairs()
            .find_map(|(key, value)| (key == "join_request").then(|| value.into_owned()))
            .unwrap();
        let join_request = decode_join_request_param_for_test(&join_request_param);
        let client_info = join_request.client_info.unwrap();

        assert_eq!(client_info.sdk, proto::client_info::Sdk::Cpp as i32);
        assert_eq!(client_info.version, "9.9.9-test");
    }

    #[test]
    fn livekit_url_legacy_data_streams_advertises_v1_client_protocol() {
        let mut io = SignalOptions::default();
        io.use_legacy_data_streams = true;

        // v1 path: client_protocol is inside the join_request param
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, true, false, None, "", None).unwrap();
        let join_request_param = lk_url
            .query_pairs()
            .find_map(|(key, value)| (key == "join_request").then(|| value.into_owned()))
            .unwrap();
        let join_request = decode_join_request_param_for_test(&join_request_param);
        let client_info = join_request.client_info.unwrap();
        assert_eq!(client_info.client_protocol, CLIENT_PROTOCOL_DATA_STREAM_RPC);

        // v0 path: client_protocol is a query param
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None).unwrap();
        let client_protocol = lk_url
            .query_pairs()
            .find_map(|(key, value)| (key == "client_protocol").then(|| value.into_owned()))
            .unwrap();
        assert_eq!(client_protocol, CLIENT_PROTOCOL_DATA_STREAM_RPC.to_string());
    }

    #[test]
    fn livekit_url_forwards_other_sdks_on_both_paths() {
        let mut io = signal_options_for_cpp("9.9.9-test");
        io.sdk_options.other_sdks = Some("ros_portal:1.2.3,another-sdk:2.0.0".to_string());

        // v1 path: other_sdks travels inside the join_request param
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, true, false, None, "", None).unwrap();
        let join_request_param = lk_url
            .query_pairs()
            .find_map(|(key, value)| (key == "join_request").then(|| value.into_owned()))
            .unwrap();
        let join_request = decode_join_request_param_for_test(&join_request_param);
        let client_info = join_request.client_info.unwrap();
        assert_eq!(client_info.other_sdks, "ros_portal:1.2.3,another-sdk:2.0.0");

        // v0 path: other_sdks is a query param
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None).unwrap();
        let other_sdks = lk_url
            .query_pairs()
            .find_map(|(key, value)| (key == "other_sdks").then(|| value.into_owned()))
            .unwrap();
        assert_eq!(other_sdks, "ros_portal:1.2.3,another-sdk:2.0.0");
    }

    #[test]
    fn livekit_url_omits_other_sdks_when_unset() {
        assert!(SignalOptions::default().sdk_options.other_sdks.is_none());

        // `None` (callers predating the field) and `Some("")` must both behave as
        // "no additional SDKs" on either path.
        for other_sdks in [None, Some(String::new())] {
            let mut io = SignalOptions::default();
            io.sdk_options.other_sdks = other_sdks;

            let lk_url =
                get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None).unwrap();
            assert!(lk_url.query_pairs().all(|(key, _)| key != "other_sdks"));

            let lk_url =
                get_livekit_url("wss://localhost:7880", &io, true, false, None, "", None).unwrap();
            let join_request_param = lk_url
                .query_pairs()
                .find_map(|(key, value)| (key == "join_request").then(|| value.into_owned()))
                .unwrap();
            let join_request = decode_join_request_param_for_test(&join_request_param);
            assert!(join_request.client_info.unwrap().other_sdks.is_empty());
        }
    }

    #[test]
    fn validate_url_test() {
        let io = SignalOptions::default();
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None).unwrap();
        let validate_url = get_validate_url(lk_url);

        // Should be /rtc/validate, not /rtc/rtc/validate
        assert_eq!(validate_url.path(), "/rtc/validate");
        assert_eq!(validate_url.scheme(), "https");
    }

    #[test]
    fn livekit_url_includes_client_capabilities() {
        let io = SignalOptions::default();
        let lk_url =
            get_livekit_url("wss://localhost:7880", &io, false, false, None, "", None).unwrap();

        let capabilities = lk_url
            .query_pairs()
            .find_map(|(key, value)| (key == "capabilities").then(|| value.into_owned()))
            .unwrap();
        let expected = CLIENT_CAPABILITIES
            .iter()
            .map(|capability| capability.as_str_name())
            .collect::<Vec<_>>()
            .join(",");

        assert_eq!(capabilities, expected);
    }

    // -----------------------------------------------------------------------
    // From<TransportError> for SignalError unit tests (pure mapping, no transport needed)
    // -----------------------------------------------------------------------

    // A WS-handshake status maps to `Handshake`, never `Client`/`Server`.
    #[test]
    fn from_transport_err_http_401_yields_handshake_error() {
        use livekit_net::TransportError;
        let err = SignalError::from(TransportError::Http { status: 401 });
        match err {
            SignalError::Handshake { status } => {
                assert_eq!(status.as_u16(), 401);
            }
            other => panic!("expected Handshake, got {:?}", other),
        }
    }

    #[test]
    fn from_transport_err_http_503_yields_handshake_error() {
        use livekit_net::TransportError;
        let err = SignalError::from(TransportError::Http { status: 503 });
        match err {
            SignalError::Handshake { status } => {
                assert_eq!(status.as_u16(), 503);
            }
            other => panic!("expected Handshake, got {:?}", other),
        }
    }

    #[test]
    fn from_transport_err_timeout_yields_timeout() {
        use livekit_net::TransportError;
        let err = SignalError::from(TransportError::Timeout);
        assert!(matches!(err, SignalError::Timeout(_)), "expected Timeout, got {:?}", err);
    }

    #[test]
    fn from_transport_err_connection_yields_connection() {
        use livekit_net::TransportError;
        let err = SignalError::from(TransportError::Connection("conn failed".into()));
        assert!(
            matches!(&err, SignalError::Connection(m) if m == "conn failed"),
            "expected Connection, got {:?}",
            err
        );
    }

    #[test]
    fn from_transport_err_other_yields_connection() {
        use livekit_net::TransportError;
        let err = SignalError::from(TransportError::Other("something went wrong".into()));
        assert!(
            matches!(&err, SignalError::Connection(m) if m == "something went wrong"),
            "expected Connection, got {:?}",
            err
        );
    }

    #[test]
    fn from_transport_err_closed_yields_closed() {
        use livekit_net::TransportError;
        let err = SignalError::from(TransportError::Closed);
        assert!(matches!(err, SignalError::Closed), "expected Closed, got {:?}", err);
    }

    // Region + validate + stream behaviour, driven by the shared mock transport.

    #[tokio::test]
    async fn region_fetch_via_mock_transport_parses_urls() {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();

        // fetch_from_endpoint bypasses the is_cloud gate; the mock serves canned
        // region JSON for URLs containing /settings/regions.
        let (urls, _max_age) = region_url_provider::fetch_from_endpoint(
            "https://mock.livekit.cloud/settings/regions",
            "test-tok",
        )
        .await
        .expect("fetch_from_endpoint should succeed via mock");
        assert_eq!(urls, vec!["wss://us-mock.livekit.cloud".to_string()]);
    }

    /// Regression test for https://github.com/livekit/rust-sdks/issues/1042.
    ///
    /// The mock returns HTTP 401 when the `Authorization: Bearer <token>` header
    /// is absent; `validate()` maps 401 to `SignalError::Client`, so `is_ok()`
    /// passes only when `validate()` forwarded a valid Bearer token.
    #[tokio::test]
    async fn validate_via_mock_transport_succeeds() {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();

        let ws_url = url::Url::parse("ws://mock.livekit.cloud/rtc").unwrap();
        let result = SignalInner::validate(ws_url, "test-tok").await;
        assert!(
            result.is_ok(),
            "validate() must forward Bearer token; mock returned 401 without it — got: {:?}",
            result
        );
    }

    /// A token that can't be encoded as an HTTP header value must surface as the
    /// non-retryable `TokenFormat`, not a generic connection error. Guards against
    /// the transport seam swallowing malformed tokens (which had made `TokenFormat`
    /// dead code and driven a pointless reconnect loop on an unusable token).
    #[test]
    fn token_with_invalid_header_chars_yields_token_format() {
        assert!(matches!(super::check_token_format("bad\ntoken"), Err(SignalError::TokenFormat)));
        assert!(super::check_token_format("eyJhbGciOi.valid.token").is_ok());
    }

    /// `validate()` is best-effort enrichment: when its own HTTP GET fails at the
    /// transport layer it must return `Ok(())` so the caller surfaces the original
    /// connection error, never masking it. The mock returns a `Connection` error
    /// for URLs marked `connrefused`.
    #[tokio::test]
    async fn validate_swallows_transport_error_to_avoid_masking() {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();

        let ws_url = url::Url::parse("wss://connrefused.livekit.cloud/rtc").unwrap();
        let result = SignalInner::validate(ws_url, "test-tok").await;
        assert!(
            result.is_ok(),
            "validate() must swallow its own transport error so the caller's \
             original error survives — got: {:?}",
            result
        );
    }

    /// SignalStream delivers the first protobuf frame from the transport to the
    /// events channel. The mock returns one canned Pong frame then closes.
    #[tokio::test]
    async fn stream_delivers_first_frame() {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();

        let (_stream, mut events) = SignalStream::connect(
            url::Url::parse("ws://mock/rtc").unwrap(),
            "tok",
            Duration::from_secs(1),
        )
        .await
        .unwrap();
        let msg = events.recv().await.expect("expected a frame");
        assert!(matches!(*msg, proto::signal_response::Message::PongResp(_)));
    }

    /// A transport `Connection` error is surfaced through `error_with_chain` into
    /// `SignalError::RegionError`. The mock returns
    /// `TransportError::Connection(..connection refused..)` for URLs marked
    /// `connrefused`.
    #[tokio::test]
    async fn region_fetch_connection_refused_includes_error_chain() {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();

        let endpoint = "http://mock.test/connrefused/settings/regions";
        let result = region_url_provider::fetch_from_endpoint(endpoint, "test-tok").await;

        let err = result.expect_err("expected Err from connrefused endpoint");
        let SignalError::RegionError(msg) = err else {
            panic!("expected RegionError, got: {:?}", err);
        };
        assert!(
            msg.contains("connection refused"),
            "error_with_chain must include 'connection refused' in the message, got: {}",
            msg
        );
    }

    /// A non-JSON region body yields a descriptive `RegionError`. The mock
    /// returns a 200 with a non-JSON body for URLs marked `badjson`.
    #[tokio::test]
    async fn region_fetch_invalid_json_includes_error_chain() {
        use crate::test_transport::install_mock_transport;
        install_mock_transport();

        let endpoint = "http://mock.test/badjson";
        let result = region_url_provider::fetch_from_endpoint(endpoint, "test-tok").await;

        let err = result.expect_err("expected Err from badjson endpoint");
        assert!(
            matches!(err, SignalError::RegionError(_)),
            "expected RegionError from serde parse failure, got: {:?}",
            err
        );
    }

    #[test]
    fn signal_message_variant_name_extracts_variant() {
        let msg = proto::signal_response::Message::Update(proto::ParticipantUpdate::default());
        assert_eq!(signal_message_variant_name(&msg), "Update");
        let msg = proto::signal_response::Message::Leave(proto::LeaveRequest::default());
        assert_eq!(signal_message_variant_name(&msg), "Leave");
    }
}
